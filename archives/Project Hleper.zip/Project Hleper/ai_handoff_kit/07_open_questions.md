# 07 — Open Questions

Things that were **unclear, missing, or contradictory** while assembling this kit. These are
flagged for the project owner to confirm — an AI picking up the project should **ask rather than
guess** on any of these. Each notes where the tension is and a suggested default where one seems safe.

---

### 1. Test count: docs say "192", direct count found 133 test functions
- **What I found:** every living doc says **192 tests pass**. Counting `def test_` directly gives
  **133 functions across 33 files** in `backend/tests/`.
- **Likely explanation (inferred):** pytest **parametrization** expands some functions into multiple
  test cases (192 collected). Not verified — I did not run the suite.
- **Ask:** confirm `pytest backend/tests/` still reports 192 passing. If it drifts, update the docs.

### 2. Port mismatch: `INSTALL.md` says 8000, everything else says 8001
- `INSTALL.md` uses `--port 8000`; `.claude/launch.json`, `agent_docs/human_live_run_guide.md`,
  `agent_docs/current_task.md`, and `CLAUDE.md` all use **8001**.
- **Suggested default:** treat **8001** as canonical (it's what the tooling and guides expect) and
  update `INSTALL.md`. Please confirm.

### 3. Two env-example files — is one meant to replace the other?
- `backend/.env.example` (full, current — includes the OTP block) and `backend/.envnew.example`
  (shorter, framed around key rotation, no OTP block). They overlap and could drift apart.
- **Ask:** should `.envnew.example` be merged into / deleted in favor of `.env.example`, or does it
  serve a distinct purpose (post-dev key rotation) worth keeping and labeling as such?

### 4. "Planned architecture" references files/folders that don't exist on disk
- `agent_docs/architecture.md` and the "Planned structure" in `agent_docs/codebase_map.md` describe
  `backend/app/pipeline/orchestrator.py`, `core/security.py`, a `repository/` package, separate
  `extraction.py`/`summary.py`/`missing_info.py`/`xai.py` service files, and a `docker/` folder.
  **None are on disk.** In reality the pipeline is orchestrated across the route/service layer, and
  M3/M4/M6 live in `intake.py` while M10/M11 live in `risk.py`.
- **Not a bug** (plan vs. current reality), but a newcomer could waste time looking for them.
- **Ask:** is a single `pipeline/orchestrator.py` still the intended end-state, or has that plan been
  superseded by the current in-route orchestration?

### 5. Canonical module count is ambiguous (15 vs. 16 vs. "15 + M16 + M10C")
- Described as a **"15-module system"** with **Module 5 retired** (number kept as a gap), then
  **Module 16** was added, plus an internal **M10C** sub-step. The `milestone_log.md` status table
  still lists only modules 1–15.
- **Ask:** what's the canonical phrasing for reports/thesis — "15 modules (M5 retired) + M16"? And
  should the milestone table gain rows for M16 / M10C?

### 6. `.gitignore` says it ignores `*.bak` but DB backups ARE tracked in git
- `.gitignore` lists `*.db`, `*.db.*.bak`, `*.bak`, yet `git ls-files` shows
  `backend/prescreener.db.pre-0003.bak` … `pre-0010.bak` **are tracked**. The live
  `backend/prescreener.db` is correctly untracked.
- **Inferred:** the `.bak` files were committed before the ignore rule existed (or the pattern
  doesn't retroactively untrack). They may contain synthetic data only, but a DB file in git is worth
  a look.
- **Ask:** should these `.bak` files be `git rm --cached`-ed? (Confirm they hold no real patient data
  first.)

### 7. A root `README.md` is referenced but appears absent
- `agent_docs/architecture.md` and `codebase_map.md` list `README.md` at the repo root, but it isn't
  in `git ls-files` and wasn't found on disk. `INSTALL.md` and `CLAUDE.md` cover install/overview.
- **Ask:** is a root `README.md` wanted (e.g. for GitHub), or do `CLAUDE.md` + `INSTALL.md` + this
  kit suffice?

### 8. Is a *fresh* full live-mic run still outstanding, or was Session 9's enough?
- Session 9 ran a "Part-2 real-mic test" whose findings became a build spec. `current_task.md` still
  lists **the human live real-mic run** as the single next step (now against the finished 2.0 build).
- **Ask:** confirm the outstanding task is a *new* end-to-end live run on the completed system (to
  record WER/latency/red-flag numbers in `test_log.md`), which is how this kit reads it.

### 9. Deployment/hosting target is undecided
- Today "deploy" = the local `uvicorn` command. The docs mention an *optional* single Docker
  container / free PaaS "later" but name no specific host, and the `docker/` folder isn't present.
- **Ask:** is there an intended deployment target (which PaaS? a clinic machine? kept local for the
  capstone demo)? This affects whether Postgres, Docker, and real auth get prioritized.

### 10. Free-tier provider limits and model aliases will drift
- ADRs note free-tier numbers change and use moving aliases (`gemini-flash-latest`). Not an owner
  decision so much as a maintenance caveat: **verify current limits/model names in each provider
  console** before relying on throughput, and pin a model if reproducibility matters.

---

> If you (the AI reading this) hit something not covered here **or** in `agent_docs/`, add it to this
> list and ask the owner — do not invent an answer. The project's explicit rule is: *"Do NOT assume
> anything. If anything is unclear, ASK."*
