# 03 — Current State & Roadmap

> Snapshot date: **2026-07-12**. Sources: `agent_docs/current_task.md`, `agent_docs/milestone_log.md`,
> `agent_docs/changelog.md`, `CLAUDE.md`. **Always re-read `agent_docs/current_task.md` before
> starting — it is overwritten every session and is the most current statement of "what next".**

## Headline status

**Both planned build cycles are COMPLETE.** There is **no open build tracker.** What remains is
**human work, not build work.**

- The original **20-step build** (spec: `agent_docs/context_fixed_problem.md`) — done.
- The **"Context Fixed Problem 2.0"** cycle (teal redesign, bilingual portals, background-assessed
  submit, Dhaka-time display, the M16 drug-info assistant, and **real OTP**) — done.
- Database: Alembic head **0012**, **17 tables**.
- Tests: **192 pass** (per project docs). *(Directly counted: 133 `def test_` functions across 33
  files; the higher 192 reflects pytest parametrization — verify by running `pytest` to reconcile.)*
- Last session: **Session 24 / 24b** (2026-07-11).

## What's built and working right now

**Backend + three web portals run end-to-end offline (with stubbed/synthetic data).**

- **Full patient pipeline M1→M12** wired and offline-tested: raw capture → correction →
  extraction/summary/gaps → follow-up loop (min ~4, cap 5 questions) → background risk +
  red-flag rule → XAI → possible-condition suggestion → local report.
- **Real OTP** (ADR-0045, Session 24): hashed (salted SHA-256), 5-min expiry, single-use codes
  behind a pluggable sender seam. `OTP_CHANNEL=dev` prints the code to the server log (and
  `000000` still works as a dev-only bypass); `OTP_CHANNEL=textbee` sends real SMS via a
  TextBee.dev Android-SIM gateway (the `000000` bypass is structurally impossible there).
  5-attempt lockout (429), 60s resend throttle.
- **Medic portal:** queue, verbatim (read-only) panel, 10 editable derived-field cards, vitals
  editing, risk override (cannot downgrade a red-flag Critical), condition card, "Submit & Forward"
  → post-referral summary + `.docx` download.
- **Doctor portal:** queue, risk/red-flags/XAI panel, override/accept, patient-details card,
  prescription form → saved row + local `.docx` render (Diagnosis is doctor-authored, never AI),
  and the **M16 drug-info assistant** slide-in panel.
- **Bilingual EN/বাংলা** throughout the portals; values (not just labels) follow the toggle.
- **Storage + accountability:** all 17 tables; `audit_log` on every state change; `module_events`
  per module run (provider + latency).
- **Document export:** per-visit `.docx` for raw transcript, summary report, and prescription
  (regenerated fresh at download so staff edits are never stale).
- **Quota-aware LLM switching** (ADR-0041): per-attempt logging + cooldown, multi-provider fallback.
- **Legacy Phase-0 transcript demo** still works, isolated at `/legacy/`.

## What's half-built, pending, or known-fragile

These are **honest gaps**, not bugs — mostly things that gate on real-world testing or were
deliberately deferred. From `agent_docs/milestone_log.md` (module table) and ADRs:

- **The whole 15-module table is still marked 🟨 "in progress", NOT ✅ "done".** Reason: the
  modules are *built and offline-tested* but their "done" definitions require **real numbers from a
  live run** (WER, latency, red-flag recall, extraction precision/recall) that only a human can
  produce. See "What's next".
- **Module 1 (STT):** browser Web Speech API works, but the **live real-mic test + ~50 sample
  utterances + WER/latency numbers are still pending.** The robust local path (faster-whisper, CPU
  int8, over WebSocket) is **planned for Phase 1, not built.**
- **Bangla TTS voice** is host-dependent: on the Windows dev box **no Bangla voice is installed**,
  so questions show as text (the safety fallback) but aren't spoken until a voice is added. Arch
  needs `speech-dispatcher` + `espeak-ng` (documented, verified working there). See
  `agent_docs/human_live_run_guide.md`.
- **PDF export** — deferred behind the format seam; only `.docx` exists today.
- **Encryption at rest**, **real authentication** (login is stubbed; a `users` table exists), and
  **multi-clinic tenancy** — seams exist (`clinic_id`, config-driven DB URL) but the features are
  future.
- **Postgres** — supported by config (`DATABASE_URL`) but SQLite is what's in use.
- **Retrain / continuous-learning pipeline (Module 15)** — feedback is *captured*, but the
  retrain/regression loop is future.
- **TextBee real SMS** is coded but not activated (needs a physical Android phone + BD SIM +
  API key/device id in `.env`).
- **API keys were shared in chat during development** and are considered "burned" — they must be
  rotated before any public demo (see `agent_docs/human_live_run_guide.md` PART 3).
- **Minor doc drift:** `INSTALL.md` says port **8000**; everything current (launch.json, the run
  guide, CLAUDE.md) uses **8001**. See `07_open_questions.md`.

## What's planned next, in priority order

1. **The human live real-microphone run (THE current next step).** Follow
   `agent_docs/human_live_run_guide.md` end to end — walk the full patient journey with a real
   mic, hitting test cases TC-V1 (raw transcript), TC-V2 (TTS + text), TC-V3 (voice-only reply),
   TC-F2 (smart follow-up loop), TC-R1 (red-flag → Critical). Jot rough accuracy/latency numbers
   into `agent_docs/test_log.md`. Install a Bangla voice first (guide PART 1 / 1B).
2. **Rotate the three API keys** (Gemini / Groq / OpenRouter) before showing anyone (guide PART 3).
3. **Triage manual-testing findings into the next cycle.** Any bug/UX friction from the live run
   goes into `agent_docs/context fixed problem 3.0.md` (its inbox is currently **empty**). The
   established workflow: human pastes raw notes → Claude turns them into a numbered, checkable
   tracker (like the 2.0 cycle) → one item per "go", **functional fixes before polish**.
4. **(Research track, not scheduled) Faculty future features** — `agent_docs/faculty_future_features.md`:
   (a) replace the LLM API for medical summaries with a **locally-deployed quantized Moshi model**;
   (b) replace browser STT/TTS with a **quantized on-device speech model** (Bangla → Banglish).
   Both map onto existing seams; both need the human's "go" and their own plan.

**Roadmap phases (from `agent_docs/milestone_log.md`):** Phase 0 = quick working demo (browser STT
+ one LLM) — done. Phase 1 = robust local core (FastAPI + WebSocket streaming to faster-whisper) —
future. Phase 2 = Bangla accuracy (fine-tuned Whisper, transliteration, measured WER) — future.
Phase 3 = stretch/thesis (medical-Bangla fine-tuning, mobile API hardening, speaker separation) — future.

## The definition of "done" the project holds itself to

> "Nothing is 'done' until its testable definition [in `milestone_log.md`] is met **and** the
> result is written in `test_log.md`." — `agent_docs/milestone_log.md`

For ML/NLP modules, **"it runs" is explicitly NOT success** — success is measured with numbers
(WER, precision/recall, accuracy, latency). This is why the module table stays 🟨 until the live run.
