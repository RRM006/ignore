# reference_docs/ — drop-box for extra material

Drop any extra files here — specs, screenshots, API docs, design files, exported reports, sample
transcripts, meeting notes, anything.

**Re-read this folder before starting new work**, since it may contain material added *after* this
kit was generated. If something here contradicts the numbered files (`01`–`07`) or the project's
`agent_docs/`, treat the newest, most specific source as correct and flag the conflict to the owner
in `07_open_questions.md`.

Suggested (optional) way to keep it tidy:
- name files with a date + short topic, e.g. `2026-08-01_live-run-notes.md`,
  `2026-08-03_kiosk-screenshot.png`;
- add a one-line note here for anything non-obvious so the next AI knows what it is.

_(Empty for now.)_
