# 02 — Architecture & Stack

> Everything here traces to files that were read directly. Where a detail is inferred, it is
> marked `(inferred)`. Primary sources: `agent_docs/architecture.md`, `agent_docs/codebase_map.md`,
> `agent_docs/decisions.md`, `CLAUDE.md`, `requirements.txt`, and the backend source itself.

## Full tech stack

| Layer | Choice | Notes |
|---|---|---|
| Language | **Python 3.14** (runs on 3.11+) | 3.14 on the Windows dev box; SQLAlchemy pinned ≥2.0.51 for 3.14 compatibility (ADR-0012). |
| Web framework | **FastAPI 0.115.6** + **Uvicorn 0.34.0** | REST now; native WebSocket "reserved for Phase 1" streaming (not built yet). |
| Config | **pydantic-settings 2.7.1** | Loads everything from `backend/.env`; nothing hardcoded. See `backend/app/core/config.py`. |
| Database | **SQLite** via **SQLAlchemy 2.0.51** + **Alembic 1.14.0** | Config-driven URL → Postgres later with no code change. Alembic head **0012**, **17 tables**. |
| Live STT (speech-in) | **Browser Web Speech API** (`webkitSpeechRecognition`, `lang='bn-BD'`) | Client-side, Chrome/Edge, sends audio to Google's cloud. No server ML. Robust path (faster-whisper, CPU int8) is planned for Phase 1, **not built**. |
| TTS (speech-out) | **Browser Web Speech API** (`speechSynthesis`, `bn-BD`) | Reads follow-up questions aloud; on-screen text is always the fallback. No server, no key. |
| AI / LLM tasks | **Swappable OpenAI-compatible client** (`openai` SDK 1.59.6) | One client, provider chosen per module. Gemini Flash / Flash-Lite, Groq, OpenRouter `:free`, optional Cerebras/Mistral. All via `base_url`+model+key from `.env`. |
| Web search (M16) | **ddgs 9.14.4** (DuckDuckGo, no key) | For the doctor drug-info assistant. |
| HTTP client | **httpx 0.28.1** | Direct dep for the TextBee SMS OTP sender. |
| Document export | **python-docx 1.1.2** | `.docx` now; PDF planned "behind the format seam", **not built**. |
| Frontend | **Plain HTML / CSS / vanilla JS** | Shared "Teal Medical" design system in `frontend_shared/`. React is "later, not now". |
| Tests | **pytest 8.3.4** | Offline; no network. See `04_setup_and_run.md`. |
| Deployment | Local: one `uvicorn` command | Optional single Docker container / free PaaS later (`docker/` folder is planned, not present). No microservices. |

**Everything is pure-Python wheels, one cross-platform `requirements.txt`, one venv.** Must run
identically on **Windows and Arch Linux**, CPU-only, no NVIDIA GPU (a hard project constraint).

### AI provider strategy (why there are several)

To stretch **free tiers**, LLM work is spread across independent daily-quota buckets (ADR-0026),
selected per module in `backend/app/core/llm_providers.py` (`MODULE_PROVIDERS`):

- **Gemini Flash** → quality tasks: M2 correction, M4 summary, M10 base risk, M10C condition, M11 XAI, M12, M16.
- **Gemini Flash-Lite** → cheap structured extraction: M3, M8.
- **Groq (Llama 3.3 70B)** → live-loop tasks: M6, M7.
- **OpenRouter `:free`** → universal last-resort fallback. Optional **Cerebras** / **Mistral** buckets in between (skipped automatically when their key is blank).
- **Local / no-API:** M1 STT, M9 completion check, M13/M14/M15 storage/dashboard/feedback, and the red-flag rule.

A quota-aware fallback chain with per-attempt logging + cooldowns lives in
`backend/app/services/llm_client.py` (`call_module()`), fallback order in `llm_providers.FALLBACK_ORDER`
(assigned bucket → Groq → Cerebras → Mistral → OpenRouter). ADR-0041.

> ⚠ Free tiers may train on inputs → **synthetic / consented data only** during development
> (non-negotiable rule #4).

## Folder & file map

Repo root is `voice-medical-prescreener/`. One-line description per key path.

```
voice-medical-prescreener/
├── CLAUDE.md                     # Project guide auto-loaded by Claude Code each session (rules + stack + status)
├── INSTALL.md                    # Short install/run guide (note: mentions port 8000; current standard is 8001)
├── DESIGN-mintlify.md            # OLD design analysis — SUPERSEDED (banner at top); kept as history only
├── Conext_for_CSE499_capston_Project.md   # The original capstone brief (module-by-module goals)
├── Real-Time Bangla- ... Practical Build Plan.md   # The practical build plan doc
├── requirements.txt              # Single cross-platform dependency list (all pure-Python wheels)
├── .gitignore                    # Ignores .env, .venv/, *.db, *.bak, data/, audio/, models/
├── .claude/launch.json           # Preview dev-server configs (uvicorn on port 8001; Windows + Linux variants)
│
├── agent_docs/                   # THE PROJECT'S LIVING BRAIN — read these; they are the owner's own notes
│   ├── session_protocol.md       #   How to start/end each work session
│   ├── current_task.md           #   What to do RIGHT NOW + the single next step (overwritten each session)
│   ├── changelog.md              #   Session-by-session history, newest first
│   ├── milestone_log.md          #   Status board for all modules + roadmap phases
│   ├── constitution.md           #   Stable core rules + the 15-module table (changes rarely)
│   ├── decisions.md              #   ADR-style decision log (ADR-0001 … ADR-0045) — the "why" of every choice
│   ├── codebase_map.md           #   Where everything lives in the repo (living map)
│   ├── architecture.md           #   Data layer + DB schema + REST API design (Module 13 spec)
│   ├── test_log.md               #   What was tested + results (WER/accuracy/latency) + planned test cases
│   ├── reconciliation.md         #   How the UI mockups were reconciled with the schema
│   ├── update_system_flowchart.md#   TikZ source of the Patient Journey flowchart
│   ├── context_fixed_problem.md  #   The ORIGINAL 20-step fix cycle spec (all items done)
│   ├── context fixed problem 2.0.md   # The 2.0 fix cycle tracker (teal redesign, OTP, M16 …) — all done
│   ├── context fixed problem 3.0.md   # The NEXT cycle — EMPTY inbox; owner pastes manual-testing findings here
│   ├── faculty_future_features.md#   Faculty future asks (quantized on-device models) — research track, not built
│   ├── human_live_run_guide.md   #   Human step-by-step for the live mic run + Bangla voice install + key rotation
│   └── mockups-redesign.html     #   The three-portal UI mockup used for the redesign
│
├── backend/
│   ├── .env.example              # Env template (key NAMES only; committed). Copy to backend/.env (gitignored)
│   ├── .envnew.example           # A second env template geared toward the post-dev KEY-ROTATION step
│   ├── alembic.ini               # Alembic config (script_location points at migrations/)
│   ├── prescreener.db            # SQLite DB (gitignored). NEVER delete it — migrations run at startup
│   ├── prescreener.db.pre-00NN.bak  # Per-migration DB backups (gitignored)
│   ├── migrations/
│   │   ├── env.py                # Alembic env; render_as_batch for SQLite; disable_existing_loggers=False (S24 fix)
│   │   └── versions/0001…0012    # Hand-authored migrations; 0012_otp_codes is the head
│   ├── app/
│   │   ├── main.py               # FastAPI app factory: lifespan (init_db + seed letterhead + log entry points),
│   │   │                         #   registers all routers, mounts static portals. START HERE to read the wiring.
│   │   ├── core/
│   │   │   ├── config.py         # pydantic-settings: DB URL, per-bucket models, OTP knobs, followup floors, etc.
│   │   │   └── llm_providers.py  # Provider registry + MODULE_PROVIDERS map + FALLBACK_ORDER
│   │   ├── api/                  # Thin routers → services (one file per resource area):
│   │   │   ├── routes_transcripts.py      #   Legacy M1/M2: raw utterance + /api/correct + docs
│   │   │   ├── routes_documents.py        #   List + download generated docs
│   │   │   ├── routes_visits.py           #   Patient lookup + REAL OTP issue/verify; visits CRUD; utterances; intake; profile
│   │   │   ├── routes_visit_documents.py  #   Visit-grain .docx: transcript + summary_report
│   │   │   ├── routes_followup.py         #   M7 next question · M8+M9 answer; ?scope=fields = kiosk resume loop
│   │   │   ├── routes_risk.py             #   M10 assess (+ local red-flag rule) · latest risk+XAI · staff override
│   │   │   ├── routes_dashboard.py        #   Staff: users, submit→auto-assess, queues, field-edit PATCH, assign, vitals, condition
│   │   │   ├── routes_report.py           #   M12 report · M14 review · M15 feedback
│   │   │   ├── routes_prescription.py     #   Prescription letterhead prefill (GET) + save+render .docx (POST)
│   │   │   └── routes_assistant.py        #   M16 doctor drug-info assistant (visit-scoped)
│   │   ├── schemas/              # Pydantic request/response models per resource (visit, patient, profile, followup,
│   │   │                         #   risk, dashboard, prescription [no diagnosis field], assistant [disclaimer required], …)
│   │   ├── services/            # ONE small file per module (business logic). LLM calls go through llm_client.
│   │   │   ├── correction/       #   M2 corrector (Corrector ABC + OpenAICompatibleCorrector) — the original seam
│   │   │   ├── intake.py         #   M3 extract (10-field bilingual summary_fields) → M4 summary → M6 gaps
│   │   │   ├── followup.py       #   M7 question generation (+ missing-field helpers for the resume loop)
│   │   │   ├── profile_update.py #   M8 re-extract + merge (human-edited fields are never overwritten)
│   │   │   ├── completion.py     #   M9 completeness score + loop decision (LOCAL, no API)
│   │   │   ├── risk.py           #   M10 classify + M11 XAI; rule forces Critical; deterministic fallback reason
│   │   │   ├── red_flags.py      #   M10 red-flag rule list (5 categories, bn/banglish/en) — LOCAL, no API
│   │   │   ├── suggestion.py     #   M10C "possible condition (AI suggestion – NOT a diagnosis)" with embedded disclaimer
│   │   │   ├── assistant.py      #   M16 web search (ddgs) + one Flash call + server-attached disclaimer
│   │   │   ├── report.py         #   M12 local report assembly (Red Flags section + no-diagnosis disclaimer)
│   │   │   ├── llm_client.py     #   call_module(): assigned bucket → fallback chain, per-attempt logging, cooldowns
│   │   │   ├── audit.py          #   audit() one-line append writer
│   │   │   ├── documents/        #   DocxWriter + storage seam + visit_docx (transcript/summary_report/prescription writers)
│   │   │   └── otp/              #   REAL OTP: OtpSender ABC, DevLogSender (code→server log), TextBeeSender (SMS),
│   │   │                         #     service.py (hash/expiry/single-use/lockout/throttle + get_sender() factory)
│   │   └── db/
│   │       ├── database.py       #   Engine/session, run_migrations() (auto at startup), get_db()
│   │       ├── models.py         #   ALL SQLAlchemy models (17 tables)
│   │       ├── repository.py     #   Utterance/document writers (NO raw mutator — enforces rule #1)
│   │       ├── repository_visits.py  # normalize_phone, get/create patient+visit, add_utterance, set_visit_status
│   │       └── seed.py           #   seed_demo_letterhead() — idempotent, fills NULL letterhead columns at startup
│   └── tests/                    # pytest suite (33 files / 133 test functions; 192 collected tests per docs)
│
├── frontend/                     # Patient side, served at /
│   ├── index.html                #   Landing page linking the 4 entry points
│   └── kiosk.html · kiosk.js     #   Patient kiosk: phone→OTP→voice chat→summary→submit→auto-logout
├── frontend_shared/              # Shared portal assets, mounted at /shared
│   ├── shared.css                #   "Teal Medical" design tokens + Noto Sans Bengali
│   ├── shared.js                 #   TIER_LABELS (only place codes→labels), tierBand, fieldValue(), EN/BN helper, api()
│   ├── staff.js                  #   Queue render, verbatim panel, 10 editable field cards, condition card
│   └── tts.js                    #   speak() via speechSynthesis bn-BD (text stays the fallback)
├── frontend_medic/index.html     # Medic portal at /medic/: login→queue→verbatim+fields→Assign & Forward→summary+.docx
├── frontend_doctor/index.html    # Doctor portal at /doctor/: login→queue→risk/red-flag/XAI→override/accept→prescription→drug-info
├── frontend_legacy/              # OLD Module-1 transcript demo, isolated at /legacy/ (unchanged behavior)
│   └── index.html · app.js · styles.css
└── ui-ux/old/                    # Archived earlier UI mockups + design-spec drafts (reference only)
```

> The `docker/` folder, a `pipeline/orchestrator.py`, and a separate `security.py` appear in
> `agent_docs/architecture.md`'s *planned* layout but **are not on disk** — the pipeline is
> currently orchestrated inside the route/service layer, not a single orchestrator file. `(inferred
> from the file listing vs. the planned layout.)`

## How data / requests flow through the system

**Patient journey (the happy path), by module:**

```
Patient speaks (mic)
  → [M1] browser Web Speech API → RAW utterance text  → stored UNCHANGED (utterances.raw_text)
  → [M2] correction (Gemini Flash)                    → separate corrected_text field
  → [M3] extraction (Flash-Lite)  → 10-field bilingual summary_fields (value_en / value_bn)
  → [M4] chief-complaint summary (Flash)
  → [M6] gap analysis → present-vs-missing checklist
  → LOOP: [M7] next question (Groq) — shown on screen AND spoken (TTS)
          → patient answers by voice → [M8] re-extract + merge → [M9] completeness score (LOCAL)
          → repeat until complete OR max questions (min ~4, cap 5)
  → Patient reviews summary → Confirm & Submit
  → [M10] risk tier (Flash base) + LOCAL red-flag rule (can force Critical)   ← assessed in a background task
  → [M11] XAI plain-language reason
  → [M10C] possible-condition AI suggestion (separate call; embedded "not a diagnosis" disclaimer)
  → [M12] structured report assembled locally (Red Flags section, no diagnosis)
  → [M13] everything persisted; audit_log + module_events rows written
```

**Staff/doctor side:**
```
Visit enters `awaiting_review` → shows in MEDIC queue
  → medic verifies 10 fields, records vitals, (optionally overrides risk) → "Submit & Forward" → `awaiting_doctor`
  → DOCTOR queue → doctor reviews risk/red-flags/XAI → override/accept → writes prescription (.docx) → feedback
  → [M16] doctor can ask the drug-info assistant at any time (visit-scoped, server-attached disclaimer)
```

**Architectural backbone (from `agent_docs/architecture.md`):**

- **The `visit` is the aggregate root.** One pre-screening encounter = one `visit`; every output
  (utterances, profile, follow-up questions, risk assessments, reports, reviews, feedback,
  documents) hangs off it. Adding a new output type later = a new child table, nothing else changes.
- **Append-only for anything clinical/accountability:** raw utterances, risk assessments, reviews,
  feedback, and the audit log are never overwritten — new state is a new row.
- **`module_events` keyed by `module_code`** logs every module run (provider, latency, status). A
  new module = a new code value, **no schema change**. This is how "add features without major
  changes" is achieved (`M16` needed no migration).
- **JSON columns for evolving structured data** (`entities`, `gaps`, `red_flags`, report `sections`,
  prescription `payload`) — new fields are a data change, not a migration.
- **DB is source of truth; `.docx`/PDF are regenerable derived exports** (`documents` table).
- **Layering:** `api (routers) → services (one per module) → repository → db`. LLM calls funnel
  through `services/llm_client.py` so provider/fallback config lives in one place.

**The 17 database tables** (Alembic head 0012): `clinics`, `users`, `patients`, `visits`,
`utterances`, `case_profiles`, `followup_questions`, `risk_assessments`, `xai_explanations`,
`reports`, `documents`, `doctor_reviews`, `feedback`, `audit_log`, `module_events`, `prescriptions`,
`otp_codes`. Full schema + ER diagram in `agent_docs/architecture.md`.

**Entry points served by the one Uvicorn process** (from `backend/app/main.py`):
`/` (landing) · `/kiosk.html` (patient) · `/medic/` · `/doctor/` · `/legacy/` · `/health` · `/docs` (FastAPI).
