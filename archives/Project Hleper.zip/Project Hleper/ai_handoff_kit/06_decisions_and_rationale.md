# 06 — Decisions & Rationale

> Distilled from `agent_docs/decisions.md` (the full ADR log, ADR-0001 … ADR-0045) plus
> `agent_docs/constitution.md`, `agent_docs/reconciliation.md`, and `agent_docs/architecture.md`.
> **For the authoritative, dated record with full "rejected alternatives", read
> `agent_docs/decisions.md` directly** — this is a readable summary of the choices that most shape
> how you should work, not a replacement for it.

## The biggest, most load-bearing decisions

### Stack & foundation
- **Confirm the existing stack; don't rewrite (ADR-0025).** FastAPI + Uvicorn (REST now, WebSocket
  reserved), SQLite via SQLAlchemy + Alembic (config-driven → Postgres later), one OpenAI-compatible
  LLM client behind a `Corrector`/provider ABC, browser Web Speech API for STT **and** TTS,
  python-docx for export, plain HTML/JS frontend, local `uvicorn` deploy. **No microservices, no
  React yet, no Postgres yet.** Rejected: rewriting in React/Postgres now (discards working code).
- **Build the real app structure from day one, not a throwaway demo (ADR-0009).** One FastAPI server
  serves both the API and the static frontend (one run command, no CORS).
- **One cross-platform `requirements.txt` + venv (ADR-0007);** isolate hard-to-install packages as
  optional extras. **CPU-only; defer AMD-GPU acceleration (ADR-0006)** — AMD ML on these cards is
  unreliable.
- **SQLAlchemy pinned ≥2.0.51 (ADR-0012)** because 2.0.36 crashes on Python 3.14 with
  `Mapped[str | None]` columns.

### The safety / ethics core (these *are* the project)
- **Raw transcript is immutable, enforced in code (ADR-0005, ADR-0010).** Two-stage capture →
  normalize; the repository has no raw-mutating function and a test guards it. This is constitution
  rule #1 made structural, not just prose.
- **Retire the standalone Emergency module; fold a red-flag check into Module 10 (ADR-0024).** The
  safety *principle* is preserved (never falsely reassure), but the dedicated emergency module + its
  auto-escalation alert were removed from the flow. Module numbering keeps a **permanent gap at M5**
  so M6–M15 cross-references across nine docs stay valid. Rejected: deleting the emergency capability
  entirely (unsafe); renumbering (breaks the whole decision/test trail).
- **The system never diagnoses — made structural.** The AI "possible condition" is a **separate**
  call (M10C, ADR-0036) with the "not a diagnosis" disclaimer **embedded in the stored object**, and
  it structurally cannot pre-fill the doctor's Diagnosis field (ADR-0038/0039). The M16 assistant's
  disclaimer is attached **server-side** and required in the Pydantic contract (ADR-0044) — never
  trusted to the model.
- **Risk override is an appended human row; staff can't downgrade a red-flag Critical (ADR-0035).**
  Append-only history; the deterministic red-flag rule stays un-silenceable below the doctor role.

### The free-tier AI strategy
- **Per-module provider assignment across independent free buckets (ADR-0003 → ADR-0026).** Gemini
  Flash for quality tasks, Flash-Lite for cheap extraction, Groq for the live loop, OpenRouter
  `:free` as universal fallback. All OpenAI-compatible → one client + a config swap covers everything.
- **Quota-aware cooldown + wider fallback chain (ADR-0041).** After a live run showed a summary step
  failing invisibly (Gemini 429s unlogged, OpenRouter hammered while Groq sat unused), every attempt
  is now logged to `module_events`, rate-limited providers go on a short cooldown, and the chain is
  assigned → Groq → Cerebras → Mistral → OpenRouter (blank keys auto-skipped), **fail-open**.

### Voice interaction
- **Live STT is browser-side; the backend is hit only for downstream steps (ADR-0014).** Phase 0
  keeps the server stateless during speech. **STT = `webkitSpeechRecognition` bn-BD, continuous**
  (ADR-0020/0027). Multi-provider STT was built then **removed** to keep Module 1 simple (ADR-0019),
  leaving a clean `stt_provider` seam for later.
- **Follow-up questions are shown as text AND spoken simultaneously (ADR-0028);** the patient
  answers by voice; on-screen text is the built-in fallback when no Bangla voice exists.
- **Linux TTS = speech-dispatcher + espeak-ng, stay on Chromium (ADR-0040)** — a host-setup step,
  not a code bug.

### Data model & workflow
- **The `visit` is the aggregate root; `module_events` (keyed by `module_code`) is the
  extensibility keystone (architecture.md §0).** New outputs = new child tables; new modules = new
  code values — neither disturbs what ships. JSON columns for evolving structured data; promote to
  real columns only when a SQL query needs to filter/sort on them.
- **Alembic from the start; auto-run at startup; never edit an applied revision or delete the DB
  (ADR-0022).** Introduced to fix a real `no column named stt_provider` crash in place.
- **Mockup reconciliation (ADR-0030):** added a real **`medic`** triage role, a
  `visits.assigned_doctor_id`, an `awaiting_doctor` status, phone-number identification with a (then)
  stubbed OTP, and the 10-field summary as a Pydantic-enforced JSON shape (not promoted columns).
- **Bilingual values in one extraction call (ADR-0033):** each field returns `{en, bn}`; bilingual
  display costs zero extra LLM calls; staff edits fill all slots untranslated (staff text is authoritative).
- **Design system evolved to "Teal Medical" (ADR-0043),** superseding the earlier clinical-blue
  (ADR-0029), which itself superseded the original Mintlify rule. Token-only change; layouts kept.
- **Real OTP (ADR-0045):** hashed/expiring/single-use codes behind a pluggable `OtpSender` seam;
  `dev` log sender default; `textbee` real-SMS demo channel; the `000000` bypass is structurally
  confined to the dev channel. Research established that **no truly free SMS-OTP to arbitrary BD
  numbers exists** — production later would use a BTRC-approved aggregator as one new sender subclass.

## Notable alternatives that were considered and rejected (documented)

- **A free, reliable OTP-to-any-phone channel** — rejected because it doesn't exist (Twilio BD
  ~$0.60/SMS, WhatsApp auth ~$0.0113/msg + Meta verification, Firebase phone auth is Blaze-only,
  Telegram needs a prior `/start`). Hence the pluggable seam + dev bypass. (ADR-0042, ADR-0045)
- **Rewriting the frontend in React / moving to Postgres now** — rejected as premature; both are
  "later" and the seams already exist. (ADR-0025)
- **Multi-provider offline STT for Module 1** — built, then deliberately removed to reduce
  complexity/heavy deps; may return in a later module. (ADR-0019, supersedes ADR-0015/0017)
- **Numeric AI risk scores stored in the DB** — rejected; risk "bands" are a display-only
  tier→band mapping in the frontend, nothing stored. (decision C2)
- **Piggybacking condition-naming onto the M10 risk call** — rejected to avoid contaminating the
  safety-critical classifier the red-flag rule guards; M10C is a separate call. (ADR-0036)
- **Docker-compose multi-service / microservices** — rejected; single container at most. (ADR-0025)

## The faculty future-features direction (documented, not yet built)

`agent_docs/faculty_future_features.md` records two faculty requirements deliberately kept **out of
scope** for the current build (ADR-0042): (1) replace the LLM API for medical-summary generation
with a **locally-deployed quantized Moshi model** (slots in as one more OpenAI-compatible provider —
zero pipeline change); (2) replace browser STT/TTS with a **quantized on-device speech model**
(Bangla → Banglish) via the reserved Phase-1 WebSocket + the `stt_provider` and `tts.js` seams. Both
are a research track needing their own plan and the owner's "go".
