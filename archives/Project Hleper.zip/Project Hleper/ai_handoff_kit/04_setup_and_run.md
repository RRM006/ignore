# 04 — Setup & Run

> Sources: `INSTALL.md`, `CLAUDE.md`, `backend/.env.example`, `backend/.envnew.example`,
> `.claude/launch.json`, `agent_docs/human_live_run_guide.md`, `requirements.txt`,
> `backend/app/core/config.py`. Works **identically on Windows and Arch Linux**. Python 3.11+
> (3.14 is what the owner uses).

## 1. Install

From the project root (`voice-medical-prescreener/`):

```bash
# Create a virtual environment
python -m venv .venv

# Activate it
#   Windows (PowerShell): if blocked, first run:
#     Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
.venv\Scripts\activate
#   Arch Linux:
source .venv/bin/activate

# Install dependencies (all pure-Python wheels; no ML/GPU deps)
pip install -r requirements.txt

# Create your local env file from the template (then add your key)
cp backend/.env.example backend/.env      # Windows: copy backend\.env.example backend\.env
```

Then open `backend/.env` and set at least `GEMINI_API_KEY` (free key:
https://aistudio.google.com/apikey). See the env-var table below for the rest.

> The DB is created/migrated **automatically at startup** — you do not run migrations by hand and
> you must **never delete `backend/prescreener.db`.**

## 2. Run the app

**Current standard port is 8001** (used by `.claude/launch.json`, the run guide, and CLAUDE.md).
`INSTALL.md` still shows 8000 — either works; 8001 is what the tooling expects.

```bash
# Windows
.venv\Scripts\python.exe -m uvicorn backend.app.main:app --reload --port 8001

# Arch Linux
.venv/bin/python -m uvicorn backend.app.main:app --reload --port 8001
```

Open in **Google Chrome** (the mic + voice work best there; Edge also supports Web Speech API):

| Page | URL |
|---|---|
| Landing (links to all) | http://localhost:8001/ |
| Patient kiosk | http://localhost:8001/kiosk.html |
| Medic desk | http://localhost:8001/medic/ |
| Doctor | http://localhost:8001/doctor/ |
| Legacy Phase-0 demo | http://localhost:8001/legacy/ |
| Health check | http://localhost:8001/health |
| API docs (Swagger) | http://localhost:8001/docs |

> **`.env` and migration changes require a full restart.** Uvicorn's `--reload` only watches `.py`
> files — it does NOT re-run startup migrations or re-read `.env`. Stop the process and start it again.

For a **kiosk OTP** in development: enter any phone number, then the code `000000` (works because
`OTP_CHANNEL=dev` and `OTP_DEV_BYPASS=true`), OR the real code printed in the server log.

## 3. Run the tests

Offline; no network needed.

```bash
pytest backend/tests/
```

Expected: **192 passing** (per project docs). On **Windows**, if you hit Unicode/encoding errors
(Bangla text in tests), set `PYTHONIOENCODING=utf-8` first:

```bash
# Windows PowerShell
$env:PYTHONIOENCODING = "utf-8"; pytest backend/tests/
```

There is a pytest fixture (`conftest.py`) that resets in-process LLM cooldowns between tests.

## 4. Environment variables / keys

Every setting is loaded from `backend/.env` via pydantic-settings (`backend/app/core/config.py`).
**Use placeholders only in any committed file — never paste real keys.** `backend/.env` is
gitignored; only `backend/.env.example` (and `.envnew.example`) — with blank values — are committed.

| Variable | Purpose | Placeholder / default |
|---|---|---|
| `CORRECTION_PROVIDER` | Active correction provider (`gemini`\|`groq`\|`openrouter`) | `gemini` |
| `CORRECTION_MODEL` | Model for correction | `gemini-flash-latest` |
| `GEMINI_API_KEY` | Google AI Studio key (main quality bucket) | `<your-gemini-key>` |
| `GEMINI_BASE_URL` | Gemini OpenAI-compatible endpoint | `https://generativelanguage.googleapis.com/v1beta/openai/` |
| `GROQ_API_KEY` | Groq key (live-loop bucket: M6, M7) | `<your-groq-key>` (optional) |
| `OPENROUTER_API_KEY` | OpenRouter key (universal `:free` fallback) | `<your-openrouter-key>` (optional) |
| `CEREBRAS_API_KEY` | Optional extra free fallback bucket | blank = skipped |
| `MISTRAL_API_KEY` | Optional free bucket — **trains on inputs; synthetic data only** | blank = skipped |
| `STT_PROVIDER` | Label/seam for future STT engines | `browser_webspeech` |
| `OTP_CHANNEL` | OTP delivery: `dev` (code→server log) or `textbee` (real SMS) | `dev` |
| `OTP_DEV_BYPASS` | Allow the `000000` bypass — **only honored when `OTP_CHANNEL=dev`** | `true` |
| `DEV_OTP` | The universal dev bypass code | `000000` |
| `OTP_TTL_SECONDS` | Code lifetime | `300` |
| `OTP_MAX_ATTEMPTS` | Wrong-code lockout threshold (→ HTTP 429) | `5` |
| `OTP_RESEND_COOLDOWN_SECONDS` | Resend throttle | `60` |
| `TEXTBEE_API_KEY` / `TEXTBEE_DEVICE_ID` / `TEXTBEE_BASE_URL` | TextBee SMS gateway (only for `OTP_CHANNEL=textbee`) | `<...>` / `<...>` / `https://api.textbee.dev/api/v1` |
| `DATABASE_URL` | Full SQLAlchemy URL; blank = local SQLite | blank → `sqlite:///backend/prescreener.db` |
| `DOCUMENT_OUTPUT_PATH` | Where `.docx` files are written (legacy alias `DOCUMENTS_DIR`) | blank → `backend/data/documents/` |

Per-module model names (`gemini_flash_model`, `gemini_flash_lite_model`, `groq_model`,
`openrouter_model`) and follow-up loop knobs (`followup_min_questions=4`, `followup_max_questions=5`,
`completeness_threshold=0.7`) also exist in `config.py` and can be overridden via `.env`.

## 5. Bangla voice (for the spoken follow-up questions)

Speech-out (TTS) needs a system Bangla voice; if none is installed the kiosk shows the question as
text (safe fallback) but won't speak it. From `agent_docs/human_live_run_guide.md`:

- **Windows:** Settings → Time & Language → Speech → Manage voices → Add voices → search "Bengali"
  → add Bengali (Bangladesh). **Fully restart Chrome** (voices load only on a fresh start).
- **Arch Linux:** `sudo pacman -S speech-dispatcher espeak-ng`, ensure the speech-dispatcher
  service/socket is running, then fully restart Chromium with `--enable-speech-dispatcher`
  (ADR-0040). The espeak-ng Bengali voice is robotic but fine for a demo.
- **Quick check (either OS):** Chrome F12 → Console →
  `speechSynthesis.getVoices().filter(v=>v.lang.startsWith('bn'))` — non-empty means it's available.

## 6. Build / deploy

- **Local:** the single `uvicorn` command above is the whole "deploy" today.
- **Optional (future, not present):** a single Docker container / free PaaS. A `docker/` folder is
  described in the planned architecture but **is not on disk**. No microservices (deliberate).
- **Postgres later:** set `DATABASE_URL` to a `postgresql+psycopg://…` URL — no code change needed
  (Alembic migrations are portable).

## 7. Key rotation (before any public demo)

The dev API keys are considered compromised (they were typed into chat). For each provider: create
a new key, revoke the old one, paste the new value into `backend/.env`, then **restart the server**.
`backend/.envnew.example` is a template oriented toward this step. Providers + links:

- Gemini → https://aistudio.google.com/apikey
- Groq → https://console.groq.com/keys
- OpenRouter → https://openrouter.ai/keys
