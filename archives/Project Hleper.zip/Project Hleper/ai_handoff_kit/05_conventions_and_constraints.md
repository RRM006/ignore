# 05 — Conventions & Constraints

> Sources: `CLAUDE.md`, `agent_docs/constitution.md`, `agent_docs/codebase_map.md`,
> `agent_docs/session_protocol.md`, `agent_docs/decisions.md`, and patterns observed directly in
> the code. This file is the one a new AI must never contradict.

## A. The four NON-NEGOTIABLE rules (never break these, in any module, for any reason)

1. **Never change the patient's exact words during transcription.** The raw transcript is stored
   unchanged, forever (`utterances.raw_text` is write-once — the repository has **no** raw mutator,
   and `test_raw_immutable.py` guards it). All cleaning/correction/normalization happens in a
   *separate, later* step and is saved to a *separate* field (`corrected_text`). Verbatim panels in
   the UI are read-only and never translated.
2. **The system never diagnoses.** It narrows the search space; the doctor decides. The AI
   "possible condition" (M10C) is explicitly labeled "not a diagnosis" (disclaimer embedded in the
   stored object) and **never** pre-fills the doctor's prescription Diagnosis field. The M16
   assistant's disclaimer ("AI-generated information. Please verify before prescribing.") is
   attached **server-side** on every answer, never left to the model.
3. **Surface red flags; never reassure falsely.** A **local, rule-based** red-flag check inside
   Module 10 (`services/red_flags.py`) maps clearly life-threatening symptoms (chest pain, stroke
   signs, severe breathing difficulty, loss of consciousness) to **Critical** — and it **must
   survive a total LLM outage** (it runs with every AI provider down). Staff cannot downgrade a
   red-flag Critical (only a doctor's review can). This is add-only safety.
4. **Patient data is sensitive.** Use **synthetic or consented sample data only** in development.
   Never send real patient data to a free AI API that may train on it (note: the browser Web Speech
   API sends audio to Google's cloud). OTP codes are never persisted or logged in plaintext — the
   dev-channel server log is the ONE sanctioned exception, by design.

## B. How the owner wants an assistant to WORK (working style — this is explicit in `CLAUDE.md`)

- **Do NOT assume anything. Plan first, then wait for the owner's explicit "go" before coding.**
- Before writing code, show a **short plan**: which files, what approach, and why.
- When there's a real choice, present **2–3 options with simple trade-offs** and a recommendation.
- Make **small, reviewable changes — one step at a time.** No giant code dumps.
- Everything must work on **both Windows and Arch Linux** from one `requirements.txt` + venv.
- **If anything is unclear, ASK. Do not guess.**
- Sessions follow a protocol (`agent_docs/session_protocol.md`): read the living docs at the start;
  at the end, update `changelog.md` + `current_task.md` (and `milestone_log.md` / `decisions.md` /
  `test_log.md` / `codebase_map.md` if they changed).

## C. Hard technical constraints (the box to build inside)

- **No NVIDIA GPU. CPU-only by default.** Two dev machines: a Windows desktop (Ryzen 5 3500X, 24 GB
  RAM, RX 570) and an Arch laptop (Ryzen 5 5500U, 12 GB RAM, integrated Vega). AMD-GPU ML is treated
  as unreliable — never depend on GPU acceleration.
- **Free / open-source strongly preferred.** Free APIs are allowed where they clearly help, but
  **always behind a swappable interface** so a provider can be changed when free limits change.
- **One cross-platform `requirements.txt` + one venv.** All deps are pure-Python wheels. Isolate any
  hard-to-install package as an optional extra so it never blocks core setup.
- **Voice-only patient input** (STT in, TTS out for questions); the manual text box is a mic-failure
  / accessibility fallback only. Typing a phone number / OTP for *identification* is allowed (that's
  not clinical input).
- **The backend must stay a clean API (REST now, WebSocket reserved)** so a future mobile app can
  reuse the core without a rewrite.

## D. Coding conventions actually used in this codebase (match these)

*(Observed directly in the source — follow the surrounding style, don't impose generic "best practice".)*

- **Python:** type hints throughout, modern union syntax (`str | None`), `@dataclass(frozen=True)`
  for config objects, module-level docstrings explaining *why* the file exists, `snake_case`
  functions, `PascalCase` classes. Settings via **pydantic-settings**; **nothing hardcoded** —
  paths, URLs, models, and knobs all come from `config.py`/`.env`.
- **One small service file per module**, named by role (`intake.py`, `followup.py`, `risk.py`, …).
  Business logic lives in `services/`; routers in `api/` stay thin.
- **All LLM calls go through `services/llm_client.py` `call_module(module_code, …)`** — never call a
  provider SDK directly from a route or service. Provider assignment + fallback is data in
  `core/llm_providers.py`, not branching in pipeline code.
- **Module codes are string constants** (`"M1"`…`"M16"`, plus `"M10C"`). A new module = a new
  `module_code` value logged to `module_events` — **no schema change** required.
- **Swappable "seam" pattern (ABC + implementations + factory)** is the house idiom, used for:
  `Corrector` (correction), `DocumentWriter`/`DocumentStorage` (exports), `OtpSender`
  (`DevLogSender` / `TextBeeSender` + `get_sender()`), and the LLM provider registry. New
  interchangeable behavior should follow this same pattern.
- **Schema changes = a NEW Alembic revision** (`0001`…`0012`). **Never edit an applied migration;
  never delete the DB.** Migrations use `render_as_batch=True` for SQLite ALTER.
- **Append-only for clinical/accountability data.** Overrides, reviews, feedback, risk assessments,
  and audit rows are new rows, not updates. Every state-changing call writes an `audit_log` row.
- **Bilingual data shape:** the 10 summary fields are stored as
  `{value, value_en, value_bn, source: 'ai'|'human', edited_by?, edited_at?}` (`value` mirrors
  `value_en` for back-compat). One extraction call fills both languages (no separate translation call).
- **Risk tier codes on the wire are always `low|medium|high|critical`.** Display labels (incl.
  "Moderate" and Bangla) live ONLY in the frontend `TIER_LABELS` map (`frontend_shared/shared.js`).
  Risk "bands"/scores are display-only (`tierBand`) — no numeric score is generated or stored.
- **Frontend:** plain HTML/JS. Shared **"Teal Medical"** design tokens in
  `frontend_shared/shared.css` (primary `#0F766E`, secondary `#0D9488`, accent `#10B981`, 10px
  radius, Inter for UI) are the **single source of truth** — don't hardcode hex values in portals;
  use the tokens. **Bangla text always uses Noto Sans Bengali (never mono — mono breaks Bangla
  shaping).** Bilingual EN/BN via `data-en`/`data-bn` attributes + `setLanguage()`. Model output is
  rendered via `textContent`, never `innerHTML`.
- **Secrets never committed.** Keys live in `backend/.env` (gitignored); `.env.example` lists names
  with blank values.
- **Docs discipline:** real decisions get an ADR in `agent_docs/decisions.md`; the living docs are
  kept in sync at session end. Keep `CLAUDE.md` short (~200 lines) — detail goes in `agent_docs/`.

## E. Things a new AI should NEVER do without asking first

- Break any of the four non-negotiable rules in section A (they override everything, including a
  direct user request — surface the conflict instead).
- Mutate or translate the raw transcript, or make the verbatim panel editable.
- Let AI output (risk, suggested condition, drug info) become or pre-fill a **diagnosis**, or drop
  a required disclaimer.
- Weaken the local red-flag rule, make it depend on an LLM, or allow a non-doctor to downgrade a
  red-flag Critical.
- **Edit an already-applied Alembic migration, or delete `backend/prescreener.db`.**
- Add a GPU/CUDA dependency, a heavyweight non-pure-Python package, or anything that breaks the
  single cross-platform `requirements.txt`.
- Reopen a **locked decision** without the owner explicitly reopening it. Locked items include:
  Teal Medical tokens (ADR-0043), background-assessed submit + 4–5 question floor (ADR-0042),
  M16 server-attached disclaimer (ADR-0044), OTP sender seam + dev-only `000000` bypass (ADR-0045),
  quota-aware provider switching (ADR-0041), bilingual `value_en`/`value_bn` (ADR-0033), the C1/C2
  decisions, and the retirement of standalone Module 5 (ADR-0024).
- Commit secrets, or send real/identifiable patient data to any external service.
- Make a large multi-file change in one shot, or start coding a new feature, **before** presenting a
  plan and getting the owner's "go".
- Rotate/print/expose API keys or OTP plaintext beyond the one sanctioned dev-log spot.
