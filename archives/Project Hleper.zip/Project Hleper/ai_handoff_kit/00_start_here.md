# 00 — Start Here

**Read `MASTER_PROMPT.md` first, then the numbered files for detail.**

---

## What this folder is

This is a **self-contained handoff kit** for the *Voice Medical Pre-Screener* project.
It exists so that any AI assistant (or human) with **zero prior context** can open this
folder, understand the whole project, and start working — including "vibe coding" — without
having to ask the project owner basic questions first.

Everything here was written by reading the actual codebase and the project's own notes in
`agent_docs/`. Where a fact was **inferred** rather than read directly, it is marked
`(inferred)`. Anything unclear, missing, or contradictory is collected in
`07_open_questions.md` instead of being guessed.

> This kit is a **snapshot** taken on 2026-07-12. The project's own living docs in
> `agent_docs/` are the continuously-updated source of truth. If this kit and `agent_docs/`
> ever disagree, trust `agent_docs/` and treat the difference as drift to reconcile.

---

## Read order

1. **`MASTER_PROMPT.md`** — the single message to paste into a fresh AI to start working. Start here.
2. **`01_project_overview.md`** — what the project is, the problem it solves, who it's for, core features.
3. **`02_architecture_and_stack.md`** — full tech stack, folder/file map, how data flows.
4. **`03_current_state_and_roadmap.md`** — what's built, what's half-built, what's next.
5. **`04_setup_and_run.md`** — install, env vars, run locally, run tests, deploy.
6. **`05_conventions_and_constraints.md`** — the coding conventions actually used + hard rules + "never do without asking".
7. **`06_decisions_and_rationale.md`** — the key design decisions and why (distilled from the project's ADR log).
8. **`07_open_questions.md`** — everything uncertain, missing, or contradictory — flagged for the owner.
9. **`reference_docs/`** — drop-box for extra material (specs, screenshots, API docs). **Re-read it before starting new work.**

---

## The 30-second version

- **What:** An AI, voice-based **medical pre-screening** system for Bangladesh. A patient
  speaks (Bangla / Banglish / dialect) *before* seeing the doctor; the system transcribes,
  cleans, extracts clinical info, asks spoken follow-up questions, assesses risk, and hands
  the doctor a structured report. **It never diagnoses.**
- **Status:** Both planned build cycles are **complete**. Backend + three web portals work
  end-to-end offline. **192 tests pass** (per project docs). The only remaining work is a
  **human live real-microphone run** and rotating the API keys — plus whatever bugs that
  manual testing turns up (which go into `agent_docs/context fixed problem 3.0.md`).
- **Stack:** Python 3.14 + FastAPI + Uvicorn; SQLite via SQLAlchemy + Alembic; plain HTML/JS
  portals; browser Web Speech API for speech in/out; swappable OpenAI-compatible LLM client
  (Gemini / Groq / OpenRouter free tiers) for the AI steps.
- **Context:** This is a **university capstone** (CSE499) with a strict "plan before you code,
  one small step at a time, wait for my go" working style. See `05_conventions_and_constraints.md`.
