# 01 — Project Overview

## What it is, in plain language

The **Voice Medical Pre-Screener** is an AI-powered, voice-based **medical pre-screening**
system built for Bangladesh. Before a patient sees the doctor, they sit at a tablet/kiosk in
the waiting area and **speak naturally** — in standard Bangla, in *Banglish* (Bangla + English
code-switching), or in a regional dialect — to describe their symptoms and history.

The system then, step by step:

1. **transcribes** their speech live into text,
2. **cleans/corrects** that text in a *separate* step (the original words are kept untouched),
3. **extracts** structured clinical information (symptoms, duration, severity, medications, history),
4. **finds gaps** and **asks follow-up questions** — each shown on screen *and* spoken aloud;
   the patient answers by voice,
5. **assesses risk** (Low / Medium / High / Critical) and surfaces **red flags**,
6. produces a **structured pre-screening report** for the doctor, and
7. stores everything in an EHR-style database with an audit trail; the doctor can review,
   override, annotate, write a prescription, and leave feedback.

The full project title (from the project brief) is: *"AI-Powered Voice-Based Medical
Pre-Screening System with Intelligent symptom capture and clinical documentation for Bangladesh."*

> Source: `Conext_for_CSE499_capston_Project.md`, `agent_docs/constitution.md`, `CLAUDE.md`.

## The problem it solves

- Doctors in Bangladesh spend a lot of consultation time on **documentation** and history-taking.
- Patients often can't type and may not read/write comfortably — but they **can speak**, in
  Bangla or Banglish.
- Off-the-shelf speech-to-text handles Bangla poorly (word error rates of ~25–45% out of the
  box, worse with dialects, code-switching, and medical terms — per `agent_docs/constitution.md`).

So the system captures the patient's story **by voice, before the consultation**, structures
it, and gives the doctor a ready-to-review report the moment the patient walks in — reducing
documentation burden, cutting consultation time, and helping ensure critical information isn't
missed. It **narrows the search space for the doctor; the doctor decides.**

## Who it's for

- **Primary users — patients:** people in Bangladeshi clinics who speak Bangla/Banglish/dialect,
  interacting voice-only via a kiosk/tablet (a manual text box exists only as a mic-failure fallback).
- **Staff — "medic" (triage desk):** verifies the extracted fields, records vitals, and assigns
  a doctor ("Submit & Forward").
- **Doctors:** review the structured report, risk tier, red flags, and explanation; override the
  risk; write and export a prescription; give feedback.
- **The project owner / builder:** a university student building this as a **CSE499 capstone**
  (also feeding a thesis with measurable results). This shapes the working style — see
  `05_conventions_and_constraints.md`.
- **(inferred) Future:** a deployable small-clinic product and, later, a mobile app reusing the
  same backend API. *(Stated as a goal in the brief; not built yet.)*

## Core features, in priority order

Ordered by how the project itself sequences and emphasizes them (build plan starts at Module 1
because everything downstream depends on accurate text — `agent_docs/constitution.md` §3).

1. **Speech-to-Text (Module 1) — the foundation.** Live mic → raw Bangla/Banglish text on
   screen; the **raw transcript is stored unchanged, forever**. Manual text fallback for mic failure.
2. **Text correction / normalization (Module 2).** A *separate* cleaned field — raw is never
   modified.
3. **Information extraction + summary + gap analysis (Modules 3, 4, 6).** Structured 10-field
   clinical summary, a short chief-complaint summary, and a present-vs-missing checklist.
4. **Follow-up loop (Modules 7, 8, 9).** Generates targeted questions (spoken + on screen),
   captures voice answers, merges them, and re-scores completeness — looping until "complete"
   or a max number of questions.
5. **Risk assessment + red-flag safety check (Module 10).** Classifies Low/Medium/High/Critical;
   a **local rule-based red-flag check forces Critical** for clearly life-threatening symptoms
   even if every AI provider is down.
6. **Explainable AI (Module 11).** Plain-language reason for the risk level.
7. **Structured clinical report + export (Module 12) + EHR storage (Module 13).** No-diagnosis
   report with a Red-Flags section; `.docx` export; everything stored with an audit log.
8. **Doctor dashboard + feedback (Modules 14, 15).** Review queue, override/annotate, write
   prescription, feedback capture.
9. **Doctor drug-info assistant (Module 16).** A doctor-side AI chatbot that does a free web
   search and answers drug questions, always with a server-attached "verify before prescribing"
   disclaimer.

> The system is described as a **"15-module" system** where **Module 5 (Emergency Detection) is
> retired** (its number kept as a permanent gap) and its safety job folded into Module 10.
> **Module 16** was added later (doctor drug-info assistant). There is also an internal
> **"M10C"** sub-step for an AI "possible condition" suggestion (explicitly *not* a diagnosis).
> Sources: `CLAUDE.md`, `agent_docs/constitution.md`, `agent_docs/decisions.md` (ADR-0024, 0036, 0044).

## The one-paragraph purpose (from the project's own constitution)

> "Before a patient meets the doctor, they speak naturally in Bangla, Banglish, or a regional
> dialect to describe their symptoms and history. The system transcribes that speech, cleans
> and structures it, finds gaps and asks follow-up questions (spoken aloud and shown on screen),
> assesses risk, surfaces red flags, and hands the doctor a clear, structured pre-screening
> report — so the doctor spends less time on documentation and misses less critical information.
> **The system assists the doctor. It never replaces the doctor and never diagnoses.**"
> — `agent_docs/constitution.md` §1
