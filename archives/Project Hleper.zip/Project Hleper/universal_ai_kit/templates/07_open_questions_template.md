# 07 — Open Questions

<!-- HOW TO USE THIS TEMPLATE
This is where EVERYTHING you were unsure about, couldn't find, or found contradictory goes — instead
of guessing in files 01–06. One entry per issue. Be specific: say what the tension is, where you saw
it, why it matters, and (if safe) a suggested default. The goal is that the owner can skim this list
and resolve each item quickly. Delete guidance comments before saving. -->

Things that were **unclear, missing, or contradictory** while assembling this kit. Flagged for the
owner to confirm. An AI picking up the project should **ask rather than guess** on any of these.

---

### 1. [[short title of the issue]]
- **What I found:** [[the specific gap / contradiction, and where — file paths, doc names]]
- **Why it matters:** [[what could go wrong if someone guesses]]
- **Suggested default (if any):** [[a safe assumption to use until the owner confirms — or "none; must ask"]]
- **Ask:** [[the precise question for the owner]]

### 2. [[...]]
- **What I found:** [[...]]
- **Why it matters:** [[...]]
- **Suggested default (if any):** [[...]]
- **Ask:** [[...]]

<!-- Add as many as needed. Common things that end up here: version/count mismatches between docs and
code; config/port/name inconsistencies; referenced files that don't exist; undecided deployment
targets; unclear ownership of secrets/data; ambiguous scope or "done" definition; TODO/FIXME clusters
with no context; anything the intake material contradicts. If you genuinely found nothing unclear,
say so explicitly — but that is rare; look harder before claiming it. -->

---

> If you (the AI reading the finished kit) hit something not covered here or in the project's own
> notes, add it to this list and ask the owner — do not invent an answer.
