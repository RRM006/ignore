# 06 — Decisions & Rationale

<!-- HOW TO USE THIS TEMPLATE
Capture the key design/technical decisions and WHY they were made — pulled from any decision log
(ADRs), design notes, commit history, or clearly inferred from the code. Prefer the project's own
recorded reasons over your interpretation. Delete guidance comments before saving.
Mark inferences "(inferred)". If a decision's rationale is unknown, note that (and consider 07). -->

> If the project keeps its own decision record (ADRs / design docs), point to it here as the
> authoritative source; this file is a readable summary of the choices that most shape how to work,
> not a replacement for it.

## The biggest, most load-bearing decisions

<!-- Group by theme if helpful (stack, data model, security/safety, workflow, UI, etc.). For each,
state the decision, the reason, and — if recorded — the alternative that was rejected and why.
Cite the source (ADR id, doc, commit) where possible. Focus on decisions a newcomer could
accidentally violate or re-litigate. -->

### [[theme, e.g. Stack & foundation]]
- **[[decision]]** — [[why]]. [[Rejected alternative + why, if documented.]] ([[source]])
- [[...]]

### [[theme]]
- [[...]]

## Notable alternatives considered and rejected (documented)

<!-- A short list of "we deliberately did NOT do X, because Y" — this prevents the next AI from
proposing something already ruled out. Only include ones that are actually documented or clearly
evidenced. -->

- [[rejected option — the reason]] ([[source]])
- [[...]]

## Decisions that are explicitly LOCKED (don't reopen without the owner's go)

<!-- If the project marks certain decisions as final/locked, list them so the next AI doesn't
reopen them. If none are marked, omit this section or note it's "(inferred)". -->

- [[locked decision + reference]]
- [[...]]
