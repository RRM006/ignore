# codebase_map.md — Where Everything Lives

<!-- HOW TO USE THIS TEMPLATE
A living map of the repo so an AI (and you) can find things without re-exploring the whole project
each session. Update it whenever a folder/file is added or moved. Keep each note to ONE line. For a
brand-new project, fill the "Planned structure" first and grow the "Current structure" as files land.
Delete guidance comments before saving. -->

**Last updated:** [[YYYY-MM-DD]]

---

## Current structure (real, today)

<!-- The tree as it ACTUALLY exists right now, with a one-line note per key folder/file. Start small
and honest — only what's on disk. -->

```
[[project-root]]/
├── [[path]]      # [[one-line description]]
├── [[path]]      # [[one-line description]]
└── [[path]]      # [[one-line description]]
```

---

## Planned structure (where we're growing toward)

<!-- The target layout the roadmap grows the repo into — so a session knows where a new file SHOULD
go. Mark anything not yet on disk as planned/TBD. -->

```
[[project-root]]/
├── [[path]]      # [[planned — one-line description]]
└── [[path]]      # [[planned — one-line description]]
```

---

## Important file rules
[[Project-specific rules about where things live and what must not move — e.g. "secrets only in
.env (gitignored)", "one module per file", "schema changes = a new migration", "generated artifacts
are derived, DB is source of truth". Fill from decisions.md / constitution.md as they solidify.]]
