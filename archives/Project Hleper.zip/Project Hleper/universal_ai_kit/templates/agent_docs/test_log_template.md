# test_log.md — What Was Tested + Results

<!-- HOW TO USE THIS TEMPLATE
"It runs" is NOT success. This file records what was tested, how, and the RESULT — including failed
runs — so progress is verifiable. For projects with measurable quality (accuracy, latency, load,
coverage, etc.), record the numbers. For simpler projects, record what was checked and the outcome.
Delete guidance comments before saving. -->

> Records what we tested, how, and the result — including failures. This makes progress verifiable.
>
> Template for each entry:
> ```
> ## YYYY-MM-DD — <area/module> — <what was tested>
> - Setup: <how it was tested; tools/versions; environment; data used>
> - Metric(s) / checks: <what was measured or verified>
> - Result: <the numbers / pass-fail / observations>
> - Notes: <what helped or hurt; errors; next idea>
> ```

---

## What we care about (per area)
[[List the things worth measuring/verifying for THIS project and the metric or check for each — e.g.
correctness, accuracy/precision/recall, latency, throughput, error rate, coverage, cross-platform,
security checks. Keep it honest to what the project actually needs.]]

## Planned test cases
[[The checks that define "done" for the current/next work, so a future session can fill in real
results. Give each a short id and a clear pass condition. Omit until there's something to plan.]]

---

<!-- Real results get appended below as work is tested, newest first or grouped by date. -->
