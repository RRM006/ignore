# changelog.md — Session-by-Session History

<!-- HOW TO USE THIS TEMPLATE
The running memory of the project. NEWEST ENTRY AT THE TOP. One short entry per session — this is
what a new session reads to remember "what happened recently and why", so nothing gets re-explained
or re-litigated. Delete guidance comments before saving. For a brand-new project, seed it with the
"Session 0" bootstrap entry shown below and edit to fit. -->

> The running memory of the project. **Newest entry at the top.** One short entry per session.
>
> Template for each entry:
> ```
> ## Session N — YYYY-MM-DD — <short title>
> - Did: <what we actually built or changed>
> - Decided: <any decision; also add it to decisions.md>
> - Broke / problem: <anything that failed or is fragile>
> - Deferred: <what we chose NOT to do yet, and why>
> - Next: <the one thing to do next — also update current_task.md>
> ```

---

## Session 0 — [[YYYY-MM-DD]] — Project bootstrap
- Did: [[created the working scaffold — CLAUDE.md + agent_docs/ (constitution, milestone_log,
  current_task, changelog, decisions, codebase_map, session_protocol, test_log) — from the project
  idea/intake.]]
- Decided: [[any founding decisions already made; add each to decisions.md]]
- Broke / problem: [[none yet, or note anything already unclear]]
- Deferred: [[what's intentionally out of scope for now]]
- Next: [[the first real build step — mirror it in current_task.md]]
