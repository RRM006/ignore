# current_task.md — What We Are Doing RIGHT NOW

<!-- HOW TO USE THIS TEMPLATE
This is a small, throwaway snapshot that gets OVERWRITTEN every session. It is NOT a history log
(that's changelog.md). It answers only: "If I open a brand-new session, what do I need to know to
continue?" Keep it short. For a brand-new project, seed it with the very first step. Delete guidance
comments before saving. -->

**Date:** [[YYYY-MM-DD]]
**Phase:** [[one line: what phase/cycle the project is in right now]]

## Where we are right now
[[2–5 bullet points: the current state in just enough detail to continue. What just happened, what's
in place, what's the immediate context. Convert relative dates to absolute.]]

## The one thing we are doing next
👉 **[[The single, concrete next step. Be specific enough that a fresh session could start it.]]**

## Locked decisions this cycle — do NOT re-open
[[List any decisions that are settled so they aren't re-litigated. Reference the ADR ids in
decisions.md. Omit if none yet.]]

## Important environment / gotchas
[[Anything a fresh session must know to avoid breaking things: how to run it, "restart after X",
"never delete Y", ports, credentials-in-.env, platform quirks. Omit if none yet.]]

## Reminders (the non-negotiables)
[[Restate the 2–4 rules that must never be broken, so they're in front of the next session. Pull from
constitution.md / CLAUDE.md.]]
