# milestone_log.md — Big-Picture Status Board

<!-- HOW TO USE THIS TEMPLATE
This answers one question: "Where are we in the whole project right now?" Update a status when it
changes. Keep every "Done means" line honest and TESTABLE — not "works well" but a real, checkable
definition. Fill the milestone/module rows from the project's planned scope (constitution.md §3).
Delete guidance comments before saving. -->

> This answers one question: **"Where are we in the whole project right now?"**

**Status keys:** ⬜ Not started · 🟨 In progress · 🟦 Blocked · ✅ Done · ⛔ Retired

**Last updated:** [[YYYY-MM-DD]]
**Current phase:** [[one line: the phase and the single most important status fact]]

---

## Milestones / modules

<!-- One row per major piece of the project. The "Done means" column must be a concrete, checkable
definition of done (something you could verify or test), not a vibe. -->

| # | Milestone / Module | Status | "Done" means (testable) |
|---|--------------------|:------:|--------------------------|
| 1 | [[name]] | ⬜ | [[a concrete, checkable definition of done]] |
| 2 | [[name]] | ⬜ | [[...]] |
| … | [[...]] | ⬜ | [[...]] |

---

## Roadmap phases

<!-- The bigger arcs and the gate to move from one to the next. Each phase: goal + "move on when". -->

### Phase 0 — [[name]]
**Goal:** [[...]]
**Move on when:** [[the concrete gate that ends this phase]]

### Phase 1 — [[name]]
**Goal:** [[...]]
**Move on when:** [[...]]

---

## Notes
- Nothing is "done" until its testable definition above is met **and** the result is recorded
  (in `test_log.md` where measurement applies).
- Before starting a later milestone early, check its dependencies in `constitution.md`.
