# decisions.md — Decision Record (ADR style)

<!-- HOW TO USE THIS TEMPLATE
A short, dated record of real design choices: what was chosen, why, and what was rejected. This stops
the same decision being silently re-opened later and gives the project a trail of justified choices.
Add a new ADR whenever a real decision is made. Number them sequentially and never renumber. Delete
guidance comments before saving. Seed it with the founding decisions already known from the intake. -->

> A dated record of real design choices: what we chose, why, and what we rejected — so decisions
> aren't silently re-opened later.
>
> Template:
> ```
> ## ADR-NNNN — YYYY-MM-DD — <title>
> - Decision: <what we will do>
> - Why: <the reason>
> - Rejected: <the main alternative(s) and why not>
> - Status: Accepted | Superseded by ADR-XXXX
> ```

---

## ADR-0001 — [[YYYY-MM-DD]] — [[Use a markdown project-memory system / first founding decision]]
- Decision: [[what was decided]]
- Why: [[the reason]]
- Rejected: [[the main alternative(s) and why not]]
- Status: Accepted

<!-- Add ADR-0002, ADR-0003, … as real decisions are made. Keep the numbering stable; when a decision
changes, add a NEW ADR that supersedes the old one (and mark the old one "Superseded by ADR-XXXX")
rather than editing history. -->
