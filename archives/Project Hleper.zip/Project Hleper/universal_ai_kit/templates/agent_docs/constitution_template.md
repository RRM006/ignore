# constitution.md — The Project Constitution

<!-- HOW TO USE THIS TEMPLATE
This is the STABLE core of the project — it changes rarely. When it must change, treat it as a big
decision and record it in decisions.md. Fill every [[...]] from the intake/idea. Delete guidance
comments before saving. Everything else in the project must obey this file. -->

> This is the stable core of the project. It changes very rarely. If something here needs to change,
> record it as a decision in `decisions.md`. Everything else must obey this file.

---

## 1. Purpose (one paragraph)

[[One paragraph: what the project is for, who it serves, and the single sentence that captures what
it must always do (and never do). This is the north star.]]

## 2. Non-negotiable rules

<!-- The rules the whole system is built around — must never be broken, anywhere, for any reason.
These should match the NON-NEGOTIABLE RULES in CLAUDE.md (CLAUDE.md is the short pointer; this is the
full statement with the "why"). -->

1. **[[rule name]].** [[Full statement + why it exists + how it's enforced, if applicable.]]
2. **[[...]]** [[...]]

## 3. Scope & major pieces (how it fits together)

<!-- The big building blocks (modules/services/features) and how they connect — the mental model a
newcomer needs. A numbered list or a small table works. Note dependencies/build order if it matters.
For a brand-new project, this is the PLANNED shape; mark it as planned. -->

[[List or table of the main pieces + one line each + how they depend on each other.]]

**Build order:** [[which piece is built first and why — usually the one everything else depends on.]]

## 4. Hard constraints (the box we build inside)

[[Platforms, hardware, cost, performance, compliance, dependencies-to-avoid — the immovable limits.
Match CLAUDE.md's TECH CONSTRAINTS but with reasons.]]

## 5. Realistic expectations (so we don't fool ourselves)

[[Honest statements about what's genuinely hard, where the risks are, and what "good enough" means.
For a project with measurable quality (accuracy, latency, uptime, etc.), say how success is measured
here — "it runs" is not success. Omit only if truly not applicable.]]
