# 03 — Current State & Roadmap

<!-- HOW TO USE THIS TEMPLATE
This is the file the next AI reads FIRST before doing anything. Keep it current and honest.
Fill from the project's status notes, changelog, issue tracker, TODOs, and the code itself.
Delete guidance comments before saving. Mark inferences "(inferred)". Unknowns go in 07. -->

> Snapshot date: [[YYYY-MM-DD]]. Most-current source of truth for "what next": [[point to the
> project's own live status doc/board if one exists, e.g. a current_task/changelog/issues link]].
> Re-read that before starting.

## Headline status

[[2–4 sentences: where the project is overall. Is it pre-alpha / actively built / feature-complete /
maintained / stalled? What's the single most important thing to know about its state right now?
Include a concrete anchor if available (version, release, test count, last commit/session date).]]

## What's built and working right now

<!-- Only list things you have EVIDENCE for (code exists, tests pass, docs say so). Group logically.
Be specific enough to be useful; avoid vague "the backend works". -->

- [[working capability — with where it lives / how you know]]
- [[...]]

## What's half-built, broken, or known-fragile

<!-- Honest gaps: partially-implemented features, known bugs, deferred pieces, flaky areas, TODO/
FIXME clusters, things that "work" but aren't verified. Distinguish "deferred on purpose" from
"broken". Cite evidence. This section protects the next AI from stepping on a landmine. -->

- [[gap / known issue — status and why, with evidence]]
- [[...]]

## What's planned next, in priority order

<!-- Pull from the roadmap/backlog/notes. Put the SINGLE immediate next step first and make it
unambiguous. Then the rest in priority order. Separate "scheduled/next" from "someday/research". -->

1. [[the immediate next step — as concrete as possible]]
2. [[next priority]]
3. [[...]]

[[Longer-term / research-track items, clearly marked as not-yet-scheduled.]]

## Definition of "done" the project holds itself to (if any)

[[If the project has an explicit bar for "done" (e.g. tests + measured metrics, a checklist, a
review gate), state it and cite it. If none is documented, say so and mark "(inferred)" or move to 07.]]
