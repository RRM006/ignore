# 01 — Project Overview

<!-- HOW TO USE THIS TEMPLATE
Replace every [[placeholder]] with real content read from the project or the intake material.
Delete these HTML comment blocks and any guidance lines before saving the final file.
Mark anything you infer rather than read directly with "(inferred)". Put unknowns in 07, not here.
Write so a person with zero prior context can follow it. Cite source files where it helps. -->

## What it is, in plain language

[[2–4 sentences: what this project is, in everyday language, no jargon. What does it actually do for
someone using it? Include the official project name/title if one exists (cite where you found it).]]

## The problem it solves

[[What real problem or need does this exist for? Who feels the pain today and how does this address
it? Keep it concrete — cite the intake/notes or code where the problem is described.]]

## Who it's for

[[List the intended users / audiences and roles. For each, one line on how they interact with it.
Include the builder/owner and their context (e.g. company, side project, capstone, client work) if
that shapes how the work should be done. Mark inferred audiences "(inferred)".]]

## Core features, in priority order

[[Ordered list of the main features/capabilities, most important or most foundational first. Base the
ordering on how the PROJECT itself prioritizes or sequences them (build order, roadmap, emphasis in
the notes) — not your own opinion. One or two lines each. Note which are central vs. nice-to-have.]]

1. [[feature — one line]]
2. [[feature — one line]]
3. [[...]]

## One-paragraph purpose (in the project's own words, if available)

[[If the project has a mission/purpose statement in its docs or intake, quote or closely paraphrase
it here and cite the source. If none exists, write a faithful one-paragraph summary and mark it
"(inferred)".]]
