# GENERATE_KIT_PROMPT

> **This is Flow B — document/hand off an EXISTING project** (produces a static `ai_handoff_kit/`
> snapshot). If instead you're **starting a new project** and want the living `CLAUDE.md` +
> `agent_docs/` working scaffold, use `BOOTSTRAP_PROJECT_PROMPT.md` (Flow A). The two are
> complementary — see `README.md`.
>
> This is the ready-to-paste prompt. Copy everything inside the fenced block below and give it to an
> AI (Claude Code or any capable coding assistant) that is running **inside the target project's
> repository**, with `universal_ai_kit/` present at (or copied into) that repo. It will produce a
> complete `ai_handoff_kit/` for that project.

---

```
You are creating a self-contained AI-handoff kit for THIS project so that any AI or human with zero
prior context can open one folder, understand the whole project, and start working (vibe coding
included) without asking basic questions first. Follow these steps exactly.

STEP 1 — UNDERSTAND THE PROJECT FIRST
- Read the entire codebase and file structure of the project you are sitting in.
- Read EVERYTHING in `universal_ai_kit/new_project_intake/` (and follow any pointers it gives you to
  the project's own notes, e.g. an agent_docs/, docs/, README, wiki, or design folder). Treat the
  intake material and the project's own notes as the owner's authoritative context.
- Build a full picture: what the project is, the problem it solves and who it's for, the tech stack,
  how the pieces fit together, how data/requests flow, what's finished, what's in progress, what's
  missing, the key decisions and why, and the conventions and hard constraints actually in use.
- GROUNDING RULE: every fact you write must trace to something you actually read — in the code or in
  the intake/notes. If you are inferring rather than reading it directly, mark it "(inferred)". If
  something is unclear, undocumented, or contradictory, DO NOT guess or fill the gap — record it in
  07_open_questions.md instead.

STEP 2 — CREATE THE HANDOFF FOLDER
- Create a new folder named `ai_handoff_kit/` at the project root. (If the project strongly suggests
  a better label, you may rename it — and state clearly what you named it and why.)
- Using the templates in `universal_ai_kit/templates/`, create one filled-in file per template,
  DROPPING the `_template` suffix, so the folder contains:
    ai_handoff_kit/00_start_here.md          (write this yourself: what the folder is + the read
                                              order + a one-line "Read MASTER_PROMPT.md first, then
                                              the numbered files for detail" + a 30-second summary)
    ai_handoff_kit/01_project_overview.md            (from 01_project_overview_template.md)
    ai_handoff_kit/02_architecture_and_stack.md      (from 02_architecture_and_stack_template.md)
    ai_handoff_kit/03_current_state_and_roadmap.md   (from 03_current_state_and_roadmap_template.md)
    ai_handoff_kit/04_setup_and_run.md               (from 04_setup_and_run_template.md)
    ai_handoff_kit/05_conventions_and_constraints.md (from 05_conventions_and_constraints_template.md)
    ai_handoff_kit/06_decisions_and_rationale.md     (from 06_decisions_and_rationale_template.md)
    ai_handoff_kit/07_open_questions.md              (from 07_open_questions_template.md)
- Fill each file with REAL content read from the project. Replace every [[placeholder]] and remove
  the template's own instruction/guidance lines from the final files. Keep each file readable by
  someone with zero prior context. Preserve the "(inferred)" marks where they apply. Cite where a
  fact came from (file path) when it helps a newcomer verify it.

STEP 3 — GROUND EVERYTHING / HANDLE GAPS
- Re-confirm STEP 1's grounding rule as you write: read → state; infer → mark "(inferred)"; unknown
  → 07_open_questions.md. Never invent project history, versions, or decisions.
- 07_open_questions.md must capture every contradiction, missing piece, or thing you were unsure
  about — with enough context that the owner can resolve it, and a suggested default where one is safe.

STEP 4 — BUILD THE MASTER PROMPT
- Fill in `universal_ai_kit/templates/MASTER_PROMPT_TEMPLATE.md` with real content pulled from the
  files you just wrote (no placeholders left, no invented facts), and save it as
  `ai_handoff_kit/MASTER_PROMPT.md`. It is the single message the owner will paste into a fresh AI to
  start working on the project cold. Pull <CONSTRAINTS> directly from 05_conventions_and_constraints.md
  and <EXAMPLES> from real files/functions in the code.

STEP 5 — CREATE THE REFERENCE DROP-BOX
- Create `ai_handoff_kit/reference_docs/` with a `README.md` inside that says: "Drop any extra files
  here — specs, screenshots, API docs, design files. Re-read this folder before starting new work,
  since it may contain material added after this kit was generated."

STEP 6 — REPORT BACK
- Finish by printing the full file tree of the `ai_handoff_kit/` folder you created, and a list of
  every item you flagged in 07_open_questions.md, so the owner knows exactly what to clarify.

HARD RULES WHILE DOING THIS
- Never modify anything OUTSIDE the new `ai_handoff_kit/` folder. Do not touch the project's code,
  its existing docs, or the universal_ai_kit/ templates. (Read them freely; write only inside
  ai_handoff_kit/.)
- Ground every fact (code or intake). Mark inferences "(inferred)". Put unknowns in
  07_open_questions.md — never guess.
- Match the project's real conventions and constraints; do not impose generic best practices that
  the project doesn't actually follow.
- If the project's own working style says "plan before acting / wait for a go", respect it: you may
  produce the kit directly (it's a documentation task the owner requested), but do not start changing
  project CODE as part of this.
```
