# universal_ai_kit — reusable AI project-onboarding system

A **project-agnostic** toolkit for two things, using the same intake material:

- **Flow A — Bootstrap a NEW project you want to build:** generate the "living project brain" —
  a `CLAUDE.md` at the root plus an `agent_docs/` folder of continuously-updated working docs
  (constitution, milestone log, current task, changelog, decisions, codebase map, session protocol,
  test log) — tailored to your idea. This is the scaffold you *maintain as you build*.
- **Flow B — Hand off / document an EXISTING project:** generate a static, self-contained
  `ai_handoff_kit/` (files `01`–`07` + a `MASTER_PROMPT.md`) so any AI or human can pick the project
  up cold. This is a *point-in-time snapshot*.

Nothing about any specific project is baked in here — the templates and prompts work unchanged on a
completely different codebase, in any language or stack.

> **Which do I want?**
> Starting something new, or a repo that has no working docs yet → **Flow A** (`BOOTSTRAP_PROJECT_PROMPT.md`).
> Handing off / onboarding an existing, already-built project → **Flow B** (`GENERATE_KIT_PROMPT.md`).
> They're complementary — you can run Flow A to start, then Flow B anytime you need a handoff snapshot.

---

## How to use it — three steps (either flow)

1. **Drop everything you have about the project into `new_project_intake/`.**
   For a NEW project that's your idea/spec/goals; for an EXISTING project it's whatever notes exist
   (or just a pointer to the repo's own docs). Any format, no polish needed.

2. **Give any AI (Claude Code or otherwise) the contents of the right prompt**, running it from
   inside the project's repo:
   - Flow A → `BOOTSTRAP_PROJECT_PROMPT.md`
   - Flow B → `GENERATE_KIT_PROMPT.md`

3. **It reads the project + the intake and writes the output** at the project root:
   - Flow A → `CLAUDE.md` + `agent_docs/…`
   - Flow B → `ai_handoff_kit/…`
   Then it lists the file tree it created and everything it flagged as open/undecided.

---

## What's in here

```
universal_ai_kit/
├── README.md                     # this file
├── BOOTSTRAP_PROJECT_PROMPT.md   # Flow A: paste this to scaffold CLAUDE.md + agent_docs/ for a new project
├── GENERATE_KIT_PROMPT.md        # Flow B: paste this to generate an ai_handoff_kit/ for an existing project
├── templates/                    # generic, placeholder-only templates (no real project content)
│   ├── CLAUDE_TEMPLATE.md                     # → CLAUDE.md (Flow A)
│   ├── agent_docs/                            # the living "project brain" set (Flow A)
│   │   ├── constitution_template.md
│   │   ├── session_protocol_template.md
│   │   ├── current_task_template.md
│   │   ├── changelog_template.md
│   │   ├── milestone_log_template.md
│   │   ├── decisions_template.md
│   │   ├── codebase_map_template.md
│   │   └── test_log_template.md
│   ├── 01_project_overview_template.md        # the handoff-kit set (Flow B) ↓
│   ├── 02_architecture_and_stack_template.md
│   ├── 03_current_state_and_roadmap_template.md
│   ├── 04_setup_and_run_template.md
│   ├── 05_conventions_and_constraints_template.md
│   ├── 06_decisions_and_rationale_template.md
│   ├── 07_open_questions_template.md
│   └── MASTER_PROMPT_TEMPLATE.md
└── new_project_intake/
    └── README.md                 # where to drop everything about the project
```

---

## The rules this system runs on (why the output is trustworthy)

- **Ground every fact** in something actually read — the code or the intake. Inferred facts are
  marked `(inferred)`; for a new project, unknowns are marked `(TBD — decide with owner)`.
- **Never guess.** Anything unclear, missing, or contradictory is surfaced (into `07_open_questions.md`
  for Flow B, or the report-back list for Flow A) — never buried in a confident sentence.
- **Templates tell the next AI what to write, not what to think.** They are scaffolding with
  `[[placeholders]]` and guidance — the AI fills them from the real project.
- **Each prompt only writes its own output folder/files** — never the project's other code, and never
  the `universal_ai_kit/` templates themselves.

---

## Reusing it on the next project

Copy `universal_ai_kit/` into (or alongside) the new project, drop intake material into
`new_project_intake/`, open an AI in that repo, and paste the prompt for the flow you want. The
templates and prompts are the same every time; only the project they read changes.
