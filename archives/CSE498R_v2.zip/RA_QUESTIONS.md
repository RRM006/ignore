# Questions for the RA — send this now, don't wait for the data

The five starred ones change the architecture. If you only get one reply, make it
cover those. Everything else can wait.

---

## ⭐ The five that decide the project

1. **⭐ Is the head visible in the data?** Our whole approach tracks hands *and*
   head together. If the clips are cropped to the hands only, the design cannot
   work and we need to know now, not in week six. *(I will verify this myself with
   a detection probe the moment I have the files — but your answer saves a week.)*

2. **⭐ Is it video or images?** Video ⇒ dynamic signs (sequence model). Images ⇒
   static signs only, and no head motion at all.

3. **⭐ Isolated signs, or continuous sentences?** One sign per clip is a
   classification problem. Full sentences require segmentation and
   sequence-to-sequence translation — a substantially bigger project. Which are we
   expected to deliver?

4. **⭐ Is there signer metadata?** We need to know which signer produced each clip
   so that no signer appears in both training and test. Without it our reported
   accuracy would be inflated, and we would rather report an honest number.

5. **⭐ Is a landmark-based pipeline acceptable?** We plan to convert video to
   MediaPipe hand + face landmarks and train on those, rather than on raw pixels.
   It is far more efficient (we have no NVIDIA GPU) and generalises better across
   signers. Any objection?

---

## The dataset itself

6. What is the dataset called, and is there a paper or README?
7. How many classes (signs/words), and can we see the label list?
8. How many samples per class? Is it balanced?
9. Resolution, frame rate, typical clip length?
10. What is the file/folder naming convention? What encodes the label and the signer?
11. Are the labels glosses, Bangla words, English words, or IDs?
12. Is there an official train/val/test split we should use? If yes, is it
    signer-independent?
13. Is the data public or restricted? Can it appear in our report and demo video?

## Scope and evaluation

14. **What counts as success?** A target accuracy? A working live demo? A paper?
15. Should the spoken output be **Bangla or English**?
16. Does the demo need to run in real time on a laptop CPU, or is offline
    inference on recorded video acceptable?
17. Is prior work on this dataset available to compare against?

## Practical

18. **⭐ May we preprocess the videos into small landmark files (~1000× smaller) and
    train on those?** This is what makes ~50 GB feasible on free Colab. It is the
    single most important logistical question after the five above.
19. Is there any GPU we can use (lab machine, university cluster), or should we
    assume free Colab/Kaggle only?
20. How should we transfer 50 GB — external drive, network share, cloud link?
21. When is the data actually available, and what is the project deadline?
22. How often can we meet or send progress updates?

## After we have looked at it

23. We will send you: dataset type, class count, samples per class, signer count,
    and the **MediaPipe hand/face detection coverage**. Which of these would you
    like us to check first?
