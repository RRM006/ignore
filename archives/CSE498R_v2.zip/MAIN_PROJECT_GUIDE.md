# MAIN PROJECT GUIDE — what to do the day your RA hands you the dataset

You do not yet know whether the data is video or images. **That is fine.** This
guide is written so that you do not need to know in advance: Phase 0 finds out
for you, and every later phase branches on the answer.

Read the whole thing once before you touch the data. It is short.

---

## The one-paragraph version

Run `inspect_dataset.py` to learn what the data actually is and — crucially —
**whether the head is even visible in it**. If it is, run `preprocess_dataset.py`
once on your desktop to turn 50 GB of video into a few hundred MB of landmark
`.npy` files. Everything after that (training, ablation, live demo) happens on
those tiny files, on free compute, in minutes per experiment. The result your
project lives or dies by is a single number: **how much accuracy the head adds on
top of the hands.**

---

## Phase 0 — Understand the dataset (half a day)

```bash
python src/inspect_dataset.py --root /path/to/the/dataset
```

It tells you, without you guessing:

| Question | Where the answer comes from |
|---|---|
| Video or images? | file-extension census |
| How many samples, how big? | file walk |
| What are the classes? | folder names + counts per class |
| Isolated words or full sentences? | median clip duration (>8 s ⇒ continuous) |
| Are there multiple signers? | signer IDs parsed from filenames |
| Is it class-balanced? | min/max samples per class |
| **Can MediaPipe see the hands?** | runs real detection on sampled frames |
| **Can MediaPipe see the head?** | runs real detection on sampled frames |

### The decision gate — read this before anything else

The report prints **FACE coverage**. This is the number that decides your project.

* **Face coverage ≥ 80%** → the head is in frame. Your "hands **and** head" design
  works. Continue to Phase 1.
* **Face coverage ≈ 0%** → the data is cropped hands with no head. **Stop.** Your
  entire premise is impossible with this data. Message your RA the same day:
  *"The dataset is hand-only crops — face coverage is 0%. Our approach needs the
  upper body in frame. Can we get a dataset with the signer's head visible, or
  should we change scope?"* Finding this out in week 1 is a normal engineering
  result. Finding it out in week 6 is a disaster.
* **Hand coverage < 50%** → MediaPipe is struggling (low resolution, motion blur).
  Try upscaling frames; if it stays low, raise it with your RA — a landmark
  pipeline has a hard ceiling on data it cannot see.

Also check the median clip duration. If clips are long, you may have been given
**continuous/sentence-level** signing, which is a substantially harder problem
(segmentation + sequence-to-sequence) than **isolated word** recognition. Confirm
with your RA which one you are expected to solve, and get it in writing.

---

## Phase 1 — Turn 50 GB into something you can actually train on (1 night)

This is the single most important engineering decision in the project.

**Do not upload 50 GB to Colab.** You would spend days uploading and still not fit
it in RAM. Instead, convert each clip into landmarks **once**, locally:

```
a 3-second 1080p clip   ~30 MB
      ↓  MediaPipe
(32 frames × 199 floats) ~25 KB      ← about 1000× smaller
```

50 GB of video becomes a few hundred MB of `.npy`. That fits in Colab memory, and
every training run afterwards takes minutes instead of days.

```bash
# 1. TIME IT FIRST on a small slice — never launch a 30-hour job blind
python src/preprocess_dataset.py --root /path/to/dataset --out data/landmarks \
    --frames 32 --workers 6 --limit 50

# 2. read the "clips/s" it prints, multiply out, then run the full job overnight
python src/preprocess_dataset.py --root /path/to/dataset --out data/landmarks \
    --frames 32 --workers 6
```

Run this on the **Windows desktop** (6 cores, 24 GB RAM). MediaPipe is CPU-bound,
so cores matter and your missing NVIDIA GPU does not. The job is **resumable** —
if it crashes or you close the lid, just run it again and it skips what is done.

It writes `manifest.csv` with per-clip hand and face coverage. **Drop clips below
~50% hand coverage before training.** Training on frames where MediaPipe saw
nothing teaches the model noise.

> If face coverage is high but hand coverage is mediocre, consider also enabling
> the pose landmarker (arms/shoulders) — `pose_landmarker_lite.task` is already
> downloaded. Arm position is a strong cue when the hands themselves blur.

---

## Phase 2 — A baseline you can trust (2–3 days)

Open `notebooks/05_main_project_baseline.ipynb` in Colab. Upload the landmark
folder to Drive (few hundred MB — fine), and train.

Two things in that notebook are not optional:

**1. Signer-independent split.** If signer #7 appears in both train and test, your
model can recognise *the person* instead of *the sign*, and your accuracy is a
lie. The notebook uses `GroupShuffleSplit` on signer ID so the test signers are
never seen in training. This is the first thing an examiner will probe. If the
filenames carry no signer IDs, **ask the RA for the signer metadata** — it exists;
datasets are recorded per-person.

**2. Start small.** Take 10–20 classes first, not all 400. Get the pipeline
working end-to-end on a subset in one afternoon, then scale up. A working small
thing beats a broken big thing.

Model progression, in order — do not skip to the fancy one:

| step | model | why |
|---|---|---|
| 1 | RandomForest on flattened sequence | a sanity floor. If this is at chance, your data or labels are broken, not your model. |
| 2 | BiGRU / BiLSTM | the honest baseline. Fast, strong on landmarks. |
| 3 | Conv1D + BiGRU | the notebook's default. Conv1D picks up short motion patterns first. |
| 4 | Transformer encoder, or ST-GCN | the "beat the baseline" upgrade if you have time. ST-GCN treats the skeleton as a graph and is the standard strong approach for skeleton-based sign recognition. |

Cheap augmentation that genuinely helps on landmarks: mirror left↔right, small
rotation/scale jitter, temporal jitter (drop or duplicate frames), Gaussian noise.

---

## Phase 3 — The experiment your project actually exists to run (2 days)

Everyone builds a hand-only sign recogniser. **Your contribution is the head.**
So measure it:

```bash
python src/train_sequence_model.py --arch gru              # hands + head  (199 features)
python src/train_sequence_model.py --arch gru --no-face    # hands only    (128 features)
```

Same split, same seed, same architecture — only the features change. Report:

| model | features | dim | signer-independent accuracy |
|---|---|---|---|
| BiGRU | hands only | 128 | … |
| BiGRU | hands + head | 199 | … |
| | | **Δ from the head** | **… ← your headline number** |

Then go further, because this is what turns a project into a *contribution*:

* **Which signs did the head fix?** Diff the two confusion matrices. Signs that
  differ only by facial expression or head movement (question forms, negation,
  intensity) should improve most. Name them in your report.
* **Which head feature carried the weight?** The 199-vector separates them
  cleanly, so you can ablate each block on its own: blendshapes (expression)
  `[132:184]`, head rotation `[184:193]`, hand-position-relative-to-face
  `[126:132]`. My prediction: the hand-relative-to-face block does the most work,
  because *place of articulation* (forehead vs chin vs chest) is a core linguistic
  parameter of sign, and hand-only models throw it away entirely. If that turns
  out to be true, it is a clean, defensible finding.

If the head adds nothing, **report that honestly** — a well-run negative result
with a good explanation is a real result, and examiners respect it far more than a
number that quietly came from a leaky split.

---

## Phase 4 — Sign → voice (2–3 days)

```bash
python src/live_demo.py --model models/sequence_main.keras
```

The demo already does the full chain: webcam → hands + head → 199-vector →
model → on-screen text → **spoken audio**. Three things to get right:

* **Latency.** `live_demo.py` prints average FPS on exit. Below ~10 FPS the demo
  feels broken. Fixes, in order: raise `--predict-every`, shrink the model, drop
  the webcam resolution.
* **Don't speak garbage.** The TTS is already debounced: it speaks only when a
  prediction has been stable for several frames *and* differs from the last thing
  spoken. Tune `--threshold` so uncertain frames stay silent.
* **Bangla output**, if the dataset is BdSL: `ESPEAK_VOICE=bn python src/live_demo.py …`
  (espeak-ng ships a Bengali voice), or a Piper Bangla voice for something that
  sounds human. Confirm with your RA whether output should be Bangla or English.

---

## Phase 5 — Report and defence (ongoing — start writing in week 1)

What actually earns marks:

1. **A dataset section with real numbers** from `reports/dataset_report.json` —
   classes, signers, clip length, and the MediaPipe coverage figures. Almost no
   student reports the coverage. It shows you understood your data's limits.
2. **The ablation table.** Your headline.
3. **The signer-independent protocol**, stated explicitly. Say why you did it.
4. **Honest failure analysis.** Where does MediaPipe drop the hands? (Fast motion,
   motion blur, hand crossing the face.) What percent of frames? What did you do —
   interpolate, presence flags, drop clips? Naming your system's failure modes is
   a strength, not a weakness.
5. **A recorded demo video.** Do this before the deadline week, not during it.

---

## Timeline (adjust to your real deadline)

| week | what |
|---|---|
| 1 | Phase 0 + 1. Inspect, decide, preprocess overnight. **Send the RA the coverage numbers.** |
| 2 | Phase 2 on a 10-class subset. Get end-to-end working, badly. |
| 3 | Scale to all classes. Signer-independent split. Tune. |
| 4 | Phase 3 ablation. This is your contribution — give it real time. |
| 5 | Phase 4 live demo + voice. Measure latency. |
| 6 | Phase 5 writing, failure analysis, demo video. |

---

## The mistakes that sink this kind of project

1. **Uploading 50 GB to Colab.** Preprocess to landmarks locally. Once.
2. **Signer leakage.** 95% accuracy that collapses in the live demo. Split by signer.
3. **Training on frames MediaPipe never saw.** Use the coverage columns in
   `manifest.csv`. Drop the bad clips.
4. **Train/inference feature mismatch.** Everything goes through `src/features.py`.
   Never build a vector by hand anywhere else. The saved `meta.json` makes the
   demo verify this for you.
5. **Discovering in week 6 that the head isn't in the data.** Phase 0, day one.
6. **Copying YouTube tutorials.** They use `mp.solutions.hands`, which no longer
   exists in current MediaPipe. The code in this repo uses the Tasks API and is
   verified against MediaPipe 0.10.35.
7. **Building the fancy model first.** RandomForest floor → BiGRU → then fancy.
