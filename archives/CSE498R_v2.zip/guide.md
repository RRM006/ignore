# guide.md — the 3-day sprint, step by step

Goal: in three days, go from nothing to a **live webcam demo that tracks your
hands and head together and speaks the sign out loud** — and to understand every
piece well enough to rebuild it on the real dataset.

Everything here is free. Training happens on Colab (or locally — the sprint data
is tiny). The webcam parts must run **locally**; Colab cannot reach your camera.

---

## Step 0 — Environment (30 min, do this once)

**MediaPipe needs Python 3.9–3.12.** Arch ships 3.13+, which will not work. The
easiest fix is `uv`, which fetches its own Python:

```bash
sudo pacman -S uv espeak-ng
cd ~/projects/slr2
uv venv --python 3.12 .venv
source .venv/bin/activate
uv pip install -r requirements.txt
```

<details>
<summary>Alternatives if you'd rather not use uv</summary>

```bash
# pyenv (compiles from source — needs the build deps)
sudo pacman -S base-devel openssl zlib xz tk libffi bzip2 readline sqlite
pyenv install 3.12.8 && pyenv local 3.12.8
python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
```
On Windows, install Python 3.12 from python.org and use the same `requirements.txt`.
</details>

Then get the models and **verify everything before you write a line of code**:

```bash
bash scripts/download_models.sh
python src/check_env.py
```

`check_env.py` checks the Python version, the MediaPipe version, that the legacy
API really is gone, that the `.task` files downloaded properly, that your webcam
opens, that TTS works, and that the feature module is sane. **Fix every FAIL
before continuing.** Ten minutes here saves a day later.

```bash
python src/tts.py --probe     # confirm you can hear something
```

---

## Day 1 — See the landmarks, understand the vector

**Morning — `notebooks/01_mediapipe_fundamentals.ipynb`**
Upload a photo of yourself signing (hand **and** face in frame). Detect both.
Print the 52 blendshapes and the head-rotation matrix. This is where you learn
what "tracking the head" actually returns — not a picture, but expression scores
and an orientation matrix.

**Afternoon — `notebooks/02_static_cnn_pixels.ipynb`**
Train a CNN on Sign Language MNIST. You will get ~95%. It is a **trap**, and you
should feel why: it memorised pixels. Point a webcam at it and it dies.

**Then read `src/features.py`.** It is the single source of truth for the whole
project — every script builds features through it, which is what makes
train/inference mismatch impossible. Know these blocks:

```
[  0: 63] left hand shape      [132:184] face blendshapes (expression)
[ 63:126] right hand shape     [184:193] head rotation (nod / tilt / shake)
[126:129] left wrist  ── relative to the FACE   ← place of articulation
[129:132] right wrist ── relative to the FACE   ← the hand↔head link
[193:196] head position + size  [196:199] presence flags
                                                       total = 199
```

That hand-relative-to-face block is the heart of the project. In sign language,
*where* the hand is with respect to the head (forehead, cheek, chin, chest) is a
core linguistic parameter. A hands-only model throws it away. Yours does not.

---

## Day 2 — Landmarks, then your own data

**Morning — `notebooks/03_landmarks_vs_pixels.ipynb`**
Images → hand landmarks → 63 numbers → RandomForest. No pixels reach the model.
Note the **detection-failure rate** it prints: that is the hard ceiling of any
landmark pipeline. Note also the lesson at the end about domain shift — it is why
the next step matters.

**Midday — record your own signs (45 min, the most valuable hour of the sprint)**

```bash
python src/collect_sequences.py --signs hello thanks yes no sorry
```

SPACE records, R redoes, Q quits. 30 sequences per sign. It prints hand/face
coverage after each sign — **if hand coverage is under 80%, re-record it.**

Vary yourself deliberately: move around the frame, change distance, sign a little
faster and slower. That variety is what makes the model survive contact with
reality.

This is a rehearsal for the main project. Every frame is stored as the same
199-vector that `live_demo.py` will build at inference time — that is *why* the
demo works. And it is the same pipeline `preprocess_dataset.py` will run over the
RA's 50 GB.

**Afternoon — train**

```bash
cd data && zip -r sequences.zip sequences && cd ..
```
Upload to `notebooks/04_dynamic_hands_head.ipynb` (Colab, GPU) — it trains a GRU
**and runs the with/without-head ablation**, printing how much the head adds.

Or skip Colab entirely; the data is tiny:

```bash
python src/train_sequence_model.py --arch gru      # needs tensorflow
python src/train_sequence_model.py --arch rf       # no tensorflow at all
```

> If a Colab-trained `.keras` refuses to load on your laptop, it is a TensorFlow
> version mismatch. Don't fight it — just retrain locally with the command above.
> `--arch rf` sidesteps TensorFlow completely and is a perfectly good demo model
> for five signs.

---

## Day 3 — Voice, and make it real

```bash
python src/live_demo.py --model models/sequence_gru.keras
# or: --model models/sequence_rf.joblib
```

Webcam → hands + head → 199-vector → model → text on screen → **spoken aloud**.
The HUD shows `hands:N head:Y/N` so you can see both being tracked simultaneously,
and a buffer bar showing the 30-frame window filling.

Tuning:
* jumpy/wrong predictions → raise `--threshold`
* laggy → raise `--predict-every`, or use `--arch rf`
* too chatty → the speaker debounces on 8 stable frames; raise it in `tts.py`
* Bangla → `ESPEAK_VOICE=bn python src/live_demo.py --model ...`

Then run the ablation and **write the number down**:

```bash
python src/train_sequence_model.py --arch gru --no-face
```

Hands+head accuracy minus hands-only accuracy. That single number is the
experiment your whole project is built to run, and now you have run it once, on a
small scale, before the real data even arrives.

---

## Then

Read `MAIN_PROJECT_GUIDE.md` and send `RA_QUESTIONS.md` to your RA. Everything you
just built is the template: `collect_sequences.py` becomes `preprocess_dataset.py`,
`train_sequence_model.py` scales up in `notebooks/05_main_project_baseline.ipynb`,
and `live_demo.py` barely changes at all.

---

## Troubleshooting

| symptom | fix |
|---|---|
| `AttributeError: module 'mediapipe' has no attribute 'solutions'` | Expected. That API is gone. Use the Tasks API — this repo already does. |
| `ValueError: timestamp must be monotonically increasing` | Use `features.Timestamper`. Never pass raw wall-clock ms. |
| Webcam won't open | `v4l2-ctl --list-devices`, then `--camera 1` |
| OpenCV window won't appear on Wayland | `QT_QPA_PLATFORM=xcb python src/live_demo.py ...` |
| No sound | `python src/tts.py --probe`; install `espeak-ng` and `alsa-utils` |
| `.keras` won't load locally | TF version mismatch — retrain locally, or use `--arch rf` |
| Model predicts one sign always | Too little data variety, or hand coverage was low. Check `data/sequences/meta.json` and re-record. |
