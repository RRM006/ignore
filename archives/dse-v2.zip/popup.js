/**
 * DSE Live Price Checker — popup.js  (v2 — robust parser)
 * ------------------------------------------------------------
 * What changed from v1:
 *  - parseQuotes() now tries ALL common delimiters (tab, pipe, comma, space)
 *  - Scans EVERY column for the matching symbol (not just col[0])
 *  - Detects the LTP column by looking for numeric values
 *  - Skips header rows intelligently
 *  - Raw data is logged to DevTools console for easy debugging
 *  - Falls back to dse_close_price scrape if quotes.txt fails
 * ------------------------------------------------------------
 */

'use strict';

/* ── Storage keys ─────────────────────────────────────────── */
const KEY_SYMBOL = 'dse_last_symbol';
const KEY_BUY    = 'dse_last_buy';
const KEY_QTY    = 'dse_last_qty';

/* ── DSE URLs (primary + fallbacks) ──────────────────────── */
const QUOTES_URL   = 'https://www.dsebd.org/datafile/quotes.txt';
const CBUL_URL     = 'https://www.dsebd.org/cbul.php';

/* ── DOM refs ─────────────────────────────────────────────── */
const inputSymbol   = document.getElementById('input-symbol');
const inputBuy      = document.getElementById('input-buy');
const inputQty      = document.getElementById('input-qty');
const btnCheck      = document.getElementById('btn-check');
const btnRefresh    = document.getElementById('btn-refresh');
const stateLoading  = document.getElementById('state-loading');
const stateError    = document.getElementById('state-error');
const stateEmpty    = document.getElementById('state-empty');
const resultCard    = document.getElementById('result-card');
const errorTitle    = document.getElementById('error-title');
const errorSub      = document.getElementById('error-sub');
const resSymbol     = document.getElementById('res-symbol');
const resLtp        = document.getElementById('res-ltp');
const resBuy        = document.getElementById('res-buy');
const resChangePill = document.getElementById('res-change-pill');
const resPlBdt      = document.getElementById('res-pl-bdt');
const resPlPct      = document.getElementById('res-pl-pct');
const resPlTotal    = document.getElementById('res-pl-total');
const plBanner      = document.getElementById('pl-banner');
const plTotal       = document.getElementById('pl-total');
const resQtyLabel   = document.getElementById('res-qty-label');
const footerUpdated = document.getElementById('footer-updated');

/* ══════════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════════ */
(function init() {
  inputSymbol.value = localStorage.getItem(KEY_SYMBOL) || '';
  inputBuy.value    = localStorage.getItem(KEY_BUY)    || '';
  inputQty.value    = localStorage.getItem(KEY_QTY)    || '';

  if (inputSymbol.value && inputBuy.value) {
    handleCheck();
  }
})();

/* ══════════════════════════════════════════════════════════
   EVENTS
═══════════════════════════════════════════════════════════ */
inputSymbol.addEventListener('input', () => {
  const pos = inputSymbol.selectionStart;
  inputSymbol.value = inputSymbol.value.toUpperCase();
  inputSymbol.setSelectionRange(pos, pos);
});

btnCheck.addEventListener('click', handleCheck);

[inputSymbol, inputBuy, inputQty].forEach(el => {
  el.addEventListener('keydown', e => { if (e.key === 'Enter') handleCheck(); });
});

btnRefresh.addEventListener('click', () => {
  btnRefresh.classList.add('spinning');
  handleCheck().finally(() => {
    setTimeout(() => btnRefresh.classList.remove('spinning'), 700);
  });
});

/* ══════════════════════════════════════════════════════════
   MAIN HANDLER
═══════════════════════════════════════════════════════════ */
async function handleCheck() {
  const symbol   = inputSymbol.value.trim().toUpperCase();
  const buyPrice = parseFloat(inputBuy.value);
  const qty      = parseInt(inputQty.value, 10) || null;

  if (!symbol) {
    showError('Symbol required', 'Enter a stock symbol e.g. GP, BEXIMCO, SQURPHARMA.');
    return;
  }
  if (!inputBuy.value || isNaN(buyPrice) || buyPrice <= 0) {
    showError('Invalid buy price', 'Enter a valid positive buy price in BDT.');
    return;
  }

  localStorage.setItem(KEY_SYMBOL, symbol);
  localStorage.setItem(KEY_BUY, inputBuy.value);
  localStorage.setItem(KEY_QTY, inputQty.value);

  showLoading();

  try {
    /* ── Try primary source: quotes.txt ───────────────── */
    let result = await tryQuotesTxt(symbol);

    /* ── Fallback: scrape cbul.php HTML ──────────────── */
    if (result === null) {
      console.warn('[DSE] quotes.txt miss — trying cbul.php fallback');
      result = await tryCbulPage(symbol);
    }

    if (result === null) {
      showError(
        `"${symbol}" not found`,
        'Check the symbol spelling. Open DevTools (F12 → Console) to see the raw data format.'
      );
      return;
    }

    renderResult({ symbol, ltp: result.ltp, buyPrice, qty });

  } catch (err) {
    console.error('[DSE Tracker] Error:', err);
    if (err.name === 'AbortError') {
      showError('Request timed out', 'DSE server is slow. Try again in a moment.');
    } else if (!navigator.onLine) {
      showError('No internet connection', 'Check your network and retry.');
    } else {
      showError('Fetch failed', `${err.message}. Check DevTools console for details.`);
    }
  }
}

/* ══════════════════════════════════════════════════════════
   SOURCE 1 — quotes.txt  (raw text file)
═══════════════════════════════════════════════════════════ */
async function tryQuotesTxt(symbol) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  const res = await fetch(QUOTES_URL, {
    signal: controller.signal,
    cache: 'no-store'
  });
  clearTimeout(timer);

  if (!res.ok) throw new Error(`quotes.txt HTTP ${res.status}`);

  const text = await res.text();

  // Log first 5 lines to console so you can see the real format
  const preview = text.split('\n').slice(0, 5).join('\n');
  console.log('[DSE] quotes.txt preview (first 5 lines):\n', preview);

  return parseQuotes(text, symbol);
}

/* ══════════════════════════════════════════════════════════
   PARSER — handles any delimiter, any column layout
═══════════════════════════════════════════════════════════ */
/**
 * Strategy:
 *  1. Split into lines, skip blanks and obvious header lines.
 *  2. Auto-detect the delimiter by counting occurrences.
 *  3. For each data line, find the column whose value exactly
 *     matches the symbol (case-insensitive).
 *  4. From the remaining columns on that row, pick the first
 *     plausible numeric price (>0, not a huge integer like volume).
 *
 * This handles DSE formats including:
 *   GP,315.10,316.00,...        (comma, symbol in col 0)
 *   GP|315.10|316.00|...        (pipe,  symbol in col 0)
 *   GP\t315.10\t316.00\t...     (tab,   symbol in col 0)
 *   1\tGP\t315.10\t...          (tab,   symbol in col 1)
 */
function parseQuotes(text, symbol) {
  const lines = text.replace(/\r/g, '').split('\n');

  // Filter to non-empty, non-comment lines
  const dataLines = lines.filter(l => {
    const t = l.trim();
    return t.length > 0 && !t.startsWith('#') && !t.startsWith('//');
  });

  if (dataLines.length === 0) {
    console.warn('[DSE] quotes.txt is empty or all comments');
    return null;
  }

  // ── Detect delimiter ───────────────────────────────────
  // Use the most frequent delimiter found in the sample lines
  const sample = dataLines.slice(0, 10).join('\n');
  const counts = {
    '\t': (sample.match(/\t/g)  || []).length,
    '|':  (sample.match(/\|/g)  || []).length,
    ',':  (sample.match(/,/g)   || []).length,
    ';':  (sample.match(/;/g)   || []).length,
  };
  const delim = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
  console.log('[DSE] Detected delimiter:', JSON.stringify(delim), 'counts:', counts);

  // ── Skip header row if present ─────────────────────────
  // A header row has mostly non-numeric tokens; a data row has numeric ones.
  // Simple heuristic: if col[0] of the first line parses as NaN and
  // doesn't look like a stock symbol (all alpha ≤12 chars), treat as header.
  let startIdx = 0;
  const firstCols = dataLines[0].split(delim).map(c => c.trim());
  const firstIsHeader = firstCols.every(c => isNaN(parseFloat(c.replace(/,/g, ''))));
  if (firstIsHeader) {
    console.log('[DSE] Skipping header row:', dataLines[0]);
    startIdx = 1;
  }

  // ── Scan rows ──────────────────────────────────────────
  for (let i = startIdx; i < dataLines.length; i++) {
    const cols = dataLines[i].split(delim).map(c => c.trim().replace(/^"|"$/g, ''));

    // Find which column holds our symbol
    const symIdx = cols.findIndex(c => c.toUpperCase() === symbol);
    if (symIdx === -1) continue;

    console.log(`[DSE] Found "${symbol}" on line ${i}, col ${symIdx}:`, cols);

    // Extract LTP — look at the columns right after the symbol column first,
    // then scan all numeric columns. DSE convention: LTP is usually col symIdx+1.
    const ltp = extractLTP(cols, symIdx);
    if (ltp !== null) {
      console.log('[DSE] LTP resolved to:', ltp);
      return { ltp };
    }

    console.warn('[DSE] Symbol found but could not parse LTP from row:', cols);
    return null;
  }

  // ── Partial-match fallback ─────────────────────────────
  // Some DSE files pad symbols with spaces: "GP       " — try startsWith
  for (let i = startIdx; i < dataLines.length; i++) {
    const cols = dataLines[i].split(delim).map(c => c.trim().replace(/^"|"$/g, ''));
    const symIdx = cols.findIndex(c => c.toUpperCase().startsWith(symbol));
    if (symIdx === -1) continue;
    console.log(`[DSE] Partial match on line ${i}:`, cols);
    const ltp = extractLTP(cols, symIdx);
    if (ltp !== null) return { ltp };
  }

  console.warn('[DSE] Symbol not found in quotes.txt:', symbol);
  return null;
}

/**
 * From a row of column strings, find the most likely LTP value.
 * Preference order: col right after symIdx, then first plausible price col.
 * "Plausible price" = numeric, > 0, < 100,000 (filters out volume/value fields).
 */
function extractLTP(cols, symIdx) {
  const toNum = str => parseFloat(str.replace(/,/g, '').replace(/[^0-9.-]/g, ''));

  // Prefer the column immediately after the symbol
  if (symIdx + 1 < cols.length) {
    const n = toNum(cols[symIdx + 1]);
    if (!isNaN(n) && n > 0 && n < 1_000_000) return n;
  }

  // Otherwise scan all columns for first plausible price
  for (let j = 0; j < cols.length; j++) {
    if (j === symIdx) continue;
    const n = toNum(cols[j]);
    if (!isNaN(n) && n > 0.01 && n < 100_000) return n;
  }

  return null;
}

/* ══════════════════════════════════════════════════════════
   SOURCE 2 — cbul.php  (HTML scrape fallback)
═══════════════════════════════════════════════════════════ */
async function tryCbulPage(symbol) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);

  const res = await fetch(CBUL_URL, {
    signal: controller.signal,
    cache: 'no-store'
  });
  clearTimeout(timer);

  if (!res.ok) {
    console.warn('[DSE] cbul.php HTTP', res.status);
    return null;
  }

  const html = await res.text();

  // DSE cbul.php renders a table; find a <td> matching the symbol
  // then grab the next numeric <td> as LTP.
  // We parse with DOMParser since we're in a browser context.
  const parser = new DOMParser();
  const doc    = parser.parseFromString(html, 'text/html');

  // Log all table text so user can see structure in DevTools
  const tables = doc.querySelectorAll('table');
  console.log('[DSE] cbul.php tables found:', tables.length);

  for (const table of tables) {
    const rows = table.querySelectorAll('tr');
    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll('td, th'))
                         .map(td => td.textContent.trim());

      const symIdx = cells.findIndex(c => c.toUpperCase() === symbol);
      if (symIdx === -1) continue;

      console.log('[DSE] cbul.php match, row cells:', cells);
      const ltp = extractLTP(cells, symIdx);
      if (ltp !== null) return { ltp };
    }
  }

  return null;
}

/* ══════════════════════════════════════════════════════════
   RESULT RENDERING
═══════════════════════════════════════════════════════════ */
function renderResult({ symbol, ltp, buyPrice, qty }) {
  const pl       = ltp - buyPrice;
  const plPct    = (pl / buyPrice) * 100;
  const isProfit = pl >= 0;
  const sign     = isProfit ? '+' : '';

  resSymbol.textContent     = symbol;
  resLtp.textContent        = fmt(ltp);
  resBuy.textContent        = fmt(buyPrice);
  resPlBdt.textContent      = `${sign}${fmt(pl)} BDT`;
  resPlPct.textContent      = `${sign}${plPct.toFixed(2)}%`;
  resChangePill.textContent = `${sign}${plPct.toFixed(2)}%`;
  resChangePill.className   = 'result-card__change-pill ' + (isProfit ? 'pill--profit' : 'pill--loss');
  plBanner.className        = 'pl-banner ' + (isProfit ? 'pl-banner--profit' : 'pl-banner--loss');

  if (qty && qty > 0) {
    const totalPl = pl * qty;
    resPlTotal.textContent  = `${sign}${fmt(totalPl)} BDT`;
    resPlTotal.style.color  = isProfit ? 'var(--clr-profit)' : 'var(--clr-loss)';
    resQtyLabel.textContent = `× ${qty} shares`;
    plTotal.hidden = false;
  } else {
    plTotal.hidden = true;
  }

  footerUpdated.textContent = 'Updated: ' + new Date().toLocaleTimeString('en-GB', {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });

  showResult();
}

/* ══════════════════════════════════════════════════════════
   UI STATE HELPERS
═══════════════════════════════════════════════════════════ */
function hideAll() {
  stateLoading.hidden = true;
  stateError.hidden   = true;
  stateEmpty.hidden   = true;
  resultCard.hidden   = true;
}
function showLoading() { hideAll(); stateLoading.hidden = false; }
function showError(title, sub) {
  hideAll();
  errorTitle.textContent = title;
  errorSub.textContent   = sub || '';
  stateError.hidden      = false;
}
function showResult() { hideAll(); resultCard.hidden = false; }

/* ══════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════ */
function fmt(n) {
  return Math.abs(n).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
