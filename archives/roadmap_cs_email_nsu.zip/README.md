# 🚀 My Dev Journey Kit
**Your complete system for going from CS student → job-ready developer in 6 months.**

---

## 📁 What's in This Kit

| File | What It Is | When to Use |
|------|-----------|-------------|
| `context_prompt.md` | System prompt for any AI | Paste at start of EVERY coding session |
| `plan.md` | Your 6-month roadmap | Read at start of each week |
| `skill.md` | Skills tracker | Update every Thursday |
| `chatlog.md` | Full session logs | Fill at end of every session |
| `historychat.md` | Short history of all sessions | Add 1 row at end of every session |

---

## ⚡ Day 1 Checklist

- [ ] Install VS Code: https://code.visualstudio.com
- [ ] Install Node.js: https://nodejs.org (LTS version)
- [ ] Install Git: https://git-scm.com
- [ ] Create GitHub account: https://github.com
- [ ] Create a folder called `my-dev-journey` on your computer
- [ ] Copy all 5 files from this kit into `my-dev-journey/_meta/`
- [ ] Open terminal in that folder and run:
  ```
  git init
  git add .
  git commit -m "init: start my dev journey"
  ```
- [ ] Create a new GitHub repo called `my-dev-journey` and push it
- [ ] Open `plan.md` and read Phase 1

---

## 🔄 Daily Workflow

```
1. Open your project folder
2. Paste context_prompt.md into your AI (Claude/ChatGPT/Cursor)
3. Update "MY CURRENT PROJECT" section in the prompt
4. Tell the AI your goal for today
5. Work for 2-3 hours (small steps, understand everything)
6. git add . && git commit -m "..." && git push
7. Fill in today's session in chatlog.md
8. Add 1 row to historychat.md
```

---

## ❓ Most Important Rule

**If you don't understand a line of code — stop. Ask. Don't move on.**

The goal is not to finish fast. The goal is to understand deeply.

---

## 🎯 6-Month Target

By the end of 6 months, you will have:
- 5 real projects live on the internet
- An active GitHub with daily commits
- At least 1 open-source contribution
- The skills to apply for junior full-stack developer roles

**You got this. Start today.**
