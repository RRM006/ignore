# 🛠️ Skill Tracker
**Purpose:** Track what you know, what you're learning, and what's next.
**Update:** Every Thursday (per your weekly routine) and at the end of each project.

---

## Why This File Exists

When you go for interviews, this file shows you exactly what you know and what you can honestly claim. It also shows you how far you've come when you're feeling stuck.

---

## How to Update

Tell your AI at the end of the week:
> "Based on what we worked on this week, update my skill.md file. For each skill we touched, tell me whether I should mark it as Learning, Comfortable, or Confident."

---

## Status Key

| Icon | Meaning |
|------|---------|
| ⬜ | Not started |
| 🔵 | Aware (I've heard of it) |
| 🟡 | Learning (I've touched it, still confused) |
| 🟠 | Comfortable (I can do it with some help) |
| 🟢 | Confident (I can do it without help) |

---

## 💻 Core Programming

| Skill | Status | Notes |
|-------|--------|-------|
| JavaScript basics (variables, functions, loops) | ⬜ | |
| Arrays and Objects in JS | ⬜ | |
| Async/Await and Promises | ⬜ | |
| Fetch API / HTTP requests | ⬜ | |
| DOM manipulation | ⬜ | |
| Error handling (try/catch) | ⬜ | |
| Modules (import/export) | ⬜ | |

---

## 🌐 Frontend

| Skill | Status | Notes |
|-------|--------|-------|
| HTML structure | ⬜ | |
| CSS styling | ⬜ | |
| Responsive design (mobile-friendly) | ⬜ | |
| Tailwind CSS | ⬜ | |
| React: components | ⬜ | |
| React: props and state | ⬜ | |
| React: useEffect hook | ⬜ | |
| React: forms and inputs | ⬜ | |
| Next.js: pages and routing | ⬜ | |
| Next.js: API routes | ⬜ | |

---

## ⚙️ Backend

| Skill | Status | Notes |
|-------|--------|-------|
| What a server is and how it works | ⬜ | |
| Node.js basics | ⬜ | |
| Express.js: creating routes | ⬜ | |
| REST API design (GET, POST, PUT, DELETE) | ⬜ | |
| Middleware (what it is, why it's used) | ⬜ | |
| Environment variables (.env files) | ⬜ | |
| Authentication (JWT, sessions) | ⬜ | |
| OAuth (Login with Google/GitHub) | ⬜ | |

---

## 🗄️ Database

| Skill | Status | Notes |
|-------|--------|-------|
| What a database is | ⬜ | |
| SQL basics (SELECT, INSERT, UPDATE, DELETE) | ⬜ | |
| Database relationships (1-to-many, many-to-many) | ⬜ | |
| PostgreSQL basics | ⬜ | |
| Supabase (hosted PostgreSQL + auth) | ⬜ | |
| ORM basics (Prisma or Drizzle) | ⬜ | |

---

## 🔧 Tools & Workflow

| Skill | Status | Notes |
|-------|--------|-------|
| VS Code: basic usage | ⬜ | |
| VS Code: extensions, shortcuts | ⬜ | |
| Git: init, add, commit, push, pull | ⬜ | |
| Git: branching and merging | ⬜ | |
| GitHub: creating repos | ⬜ | |
| GitHub: pull requests | ⬜ | |
| GitHub: issues and labels | ⬜ | |
| GitHub: code review | ⬜ | |
| .gitignore | ⬜ | |
| README writing | ⬜ | |

---

## ☁️ Deployment

| Skill | Status | Notes |
|-------|--------|-------|
| Vercel (deploy frontend) | ⬜ | |
| Railway (deploy backend) | ⬜ | |
| Environment variables in production | ⬜ | |
| Custom domain basics | ⬜ | |

---

## 🤖 AI / Vibe Coding

| Skill | Status | Notes |
|-------|--------|-------|
| Using AI to understand code | ⬜ | |
| Writing good prompts for AI | ⬜ | |
| Using Cursor or Copilot in VS Code | ⬜ | |
| Reviewing AI-generated code critically | ⬜ | |
| Knowing when NOT to use AI | ⬜ | |

---

## 🔓 Open Source

| Skill | Status | Notes |
|-------|--------|-------|
| Forking a repository | ⬜ | |
| Reading an unfamiliar codebase | ⬜ | |
| Finding a good first issue | ⬜ | |
| Submitting a pull request | ⬜ | |
| Responding to code review | ⬜ | |

---

## 📈 Progress Snapshot

| Month | Skills Comfortable+ | Projects Done | PRs Merged |
|-------|---------------------|---------------|------------|
| Month 1 | 0 | 0 | 0 |
| Month 2 | | | |
| Month 3 | | | |
| Month 4 | | | |
| Month 5 | | | |
| Month 6 | | | |

---

## 🎓 Skills to Mention in Interviews (after 6 months)

Once you reach 🟠 or 🟢 on these, you can honestly list them on your resume:

- [ ] React.js
- [ ] Next.js
- [ ] Node.js / Express
- [ ] REST API development
- [ ] PostgreSQL / Supabase
- [ ] Git & GitHub
- [ ] Vercel / Railway deployment
- [ ] Tailwind CSS
- [ ] AI-assisted development
