# 📋 My Developer Learning Plan
**Goal:** Become a job-ready full-stack developer in 6 months by building real projects.
**Daily Time:** 2–3 hours
**Method:** Vibe Coding (AI-assisted) + Understanding every line + Git always

---

## 🗂️ Folder Structure (Set this up on Day 1)

```
my-dev-journey/
├── _meta/                     ← All tracking files live here
│   ├── context_prompt.md      ← Paste into AI every session
│   ├── plan.md                ← This file
│   ├── skill.md               ← What you know / are learning
│   ├── chatlog.md             ← Full session logs
│   └── historychat.md         ← Short history of all sessions
│
├── projects/
│   ├── 01-task-manager/       ← Project 1
│   ├── 02-expense-tracker/    ← Project 2
│   ├── 03-link-shortener/     ← Project 3
│   └── ...                    ← More projects
│
└── learnings/
    └── notes/                 ← Random notes, snippets, things you learn
```

---

## 🗓️ 6-Month Roadmap Overview

| Phase | Months | Focus |
|-------|--------|-------|
| Phase 1 | Month 1 | Setup + Git + First project (small) |
| Phase 2 | Month 2–3 | Full-stack basics + 2 medium projects |
| Phase 3 | Month 4 | Advanced project + Open source contribution |
| Phase 4 | Month 5–6 | Capstone project + Job prep + GitHub portfolio |

---

## 📦 PHASE 1 — Foundation (Month 1)

**Goal:** Set up your environment, learn Git properly, and build your first working project.

### Week 1–2: Environment & Git
- [ ] Install: VS Code, Node.js, Git, GitHub Desktop (optional)
- [ ] Create GitHub account, set up SSH key
- [ ] Learn these Git commands by actually using them:
  - `git init`, `git clone`, `git add`, `git commit`, `git push`, `git pull`
  - `git branch`, `git checkout`, `git merge`
- [ ] Create your GitHub profile README (this is your public face)
- [ ] Set up the `my-dev-journey` folder structure above

### Week 3–4: Project 1 — Task Manager (CLI or Web)
**What it is:** A simple to-do list where you can add, complete, and delete tasks.
**Why start here:** Every app has CRUD (Create, Read, Update, Delete). This teaches that.
**Tech:** HTML + CSS + JavaScript (no framework yet)

**Features to build:**
1. Add a task
2. Mark a task as done
3. Delete a task
4. Save tasks so they don't disappear on refresh (localStorage)

**What you learn:**
- DOM manipulation (how JavaScript talks to HTML)
- Event listeners (what happens when you click a button)
- localStorage (browser memory)
- How to structure a small project

**Git habit for this project:**
```
git commit -m "feat: add task input form"
git commit -m "feat: implement mark as done"
git commit -m "fix: tasks not saving on refresh"
```

---

## 🏗️ PHASE 2 — Full-Stack Basics (Month 2–3)

**Goal:** Learn how a frontend (what users see) talks to a backend (server) and a database.

### Month 2: Learn the Building Blocks
- [ ] JavaScript fundamentals: functions, arrays, objects, async/await, fetch
- [ ] Learn React basics: components, props, state, useEffect
- [ ] Learn Node.js + Express basics: routes, middleware, request/response

### Project 2 — Expense Tracker (Frontend + Backend)
**What it is:** Track your monthly expenses. Add income and expenses. See a summary.
**Why this:** It needs a real backend + database for the first time.
**Tech:** React (frontend) + Node.js/Express (backend) + PostgreSQL or Supabase

**Features to build:**
1. Add an expense (name, amount, category, date)
2. View all expenses in a list
3. See total spent this month
4. Delete an expense
5. Simple bar chart showing spending by category

**What you learn:**
- How a React frontend sends data to an Express backend (fetch/axios)
- How a backend saves data to a database (SQL basics)
- REST API design (GET, POST, DELETE routes)
- Environment variables (.env files — never push these to GitHub!)
- Deploying: Vercel (frontend) + Railway (backend)

### Month 3: Project 3 — Link Shortener (like bit.ly)
**What it is:** Paste a long URL, get a short URL. When someone clicks the short URL, they go to the original.
**Why this:** Real-world utility app. Used by millions of companies.
**Tech:** Next.js (fullstack) + Supabase (database)

**Features to build:**
1. Input a long URL → get a short code
2. Short URL redirects to original
3. Track how many times a link was clicked
4. User can see their links (basic auth)

**What you learn:**
- Next.js (frontend + backend in one — very common in jobs)
- URL redirects and how they work
- Basic user authentication (signing up, logging in, sessions)
- Database design (tables, foreign keys)

---

## 🚀 PHASE 3 — Going Deeper (Month 4)

**Goal:** Build something more complex and make your first open-source contribution.

### Project 4 — Job Application Tracker
**What it is:** Track every job you apply to: company, role, status, interview dates, notes.
**Why this:** You'll actually USE this during job search. Plus it's a great portfolio piece.
**Tech:** Next.js + Supabase + Tailwind CSS + GitHub OAuth

**Features to build:**
1. Dashboard showing all applications by status (Applied / Interview / Rejected / Offer)
2. Add new application with details
3. Update status as it progresses
4. Add notes after each interview
5. Export to CSV
6. Login with GitHub OAuth

**What you learn:**
- OAuth (login with Google/GitHub — used everywhere)
- Dashboard UI design with Tailwind CSS
- More complex database relationships
- File export (CSV generation)

### Open Source Contribution (Month 4, parallel)
**Goal:** Make 1 real pull request to an existing project on GitHub.

**How to find a project:**
- Go to GitHub and search: `good first issue label:beginner`
- Look for projects with tags: `hacktoberfest`, `good-first-issue`, `help-wanted`
- Start with documentation fixes or small bug fixes — these count!

**Steps for your first contribution:**
1. Fork the repository (make your own copy)
2. Read the README and CONTRIBUTING.md file
3. Find a `good first issue`
4. Clone it locally, make your change
5. Submit a Pull Request (PR)
6. Respond to reviewer comments politely

**What you learn:**
- How professional codebases are organized
- Reading others' code
- Pull Request etiquette
- Code review process

---

## 🏆 PHASE 4 — Capstone + Job Ready (Month 5–6)

### Project 5 — Your Capstone (Choose One)

Pick one that excites you most:

**Option A: SaaS Product Starter**
A simple SaaS tool (e.g., AI writing assistant, resume builder, habit tracker with AI insights)
- Includes: Auth, payments (Stripe), AI API (OpenAI/Claude), dashboard

**Option B: Developer Tool**
A CLI tool or VS Code extension that solves a real developer problem
- Example: Auto-generates boilerplate code for common patterns

**Option C: Community Platform**
A forum/community platform for a niche topic you care about
- Includes: Posts, comments, upvotes, user profiles, search

**What makes a good capstone:**
- It solves a REAL problem
- It has user authentication
- It has a real database
- It is deployed and accessible online
- It has a clean README with screenshots

### Month 6: Job Prep
- [ ] Polish all 5 projects: clean README, live demo, screenshots
- [ ] Write case studies for top 2 projects (what problem, how you solved it, what you learned)
- [ ] LinkedIn profile update
- [ ] Practice explaining your projects out loud (mock interviews)
- [ ] Apply to jobs — use Project 4 (Job Tracker) to track it!

---

## 📊 Weekly Routine (2–3 hours/day)

| Day | Focus |
|-----|-------|
| Monday | Learn something new (tutorial, concept) |
| Tuesday | Build — apply what you learned |
| Wednesday | Build — continue + debug |
| Thursday | Git cleanup, review code, update skill.md |
| Friday | Open source OR polish current project |
| Saturday | Free / catch up / explore something fun |
| Sunday | Plan next week, update chatlog/historychat |

---

## 🎯 Skills You Will Have After 6 Months

- Build full-stack web apps from scratch
- Write clean, readable code
- Use Git and GitHub like a professional
- Contribute to real open-source projects
- Deploy apps to the internet
- Use AI tools to accelerate coding (vibe coding)
- Understand how real companies build software
- Have 5 real projects to show in interviews

---

## 📌 Important Rules

1. **Small steps every day beat big steps once a week.** 1 hour daily > 7 hours on Sunday.
2. **Push to GitHub every day** — even tiny changes.
3. **Understand before you move on.** If a line confuses you, ask.
4. **Build things you actually care about** — passion makes you push through stuck moments.
5. **Stuck for more than 30 minutes?** Ask AI. But ask it to explain, not just fix.
