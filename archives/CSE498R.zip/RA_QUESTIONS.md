# RA_QUESTIONS.md — Questions to Ask the RA BEFORE Starting the Main Project

Get written answers (Messenger/email is fine) so decisions are on record.
The ones marked ⭐ change the architecture — get those first.

## A. The dataset (most important — the 50 GB decides everything)

1. ⭐ **What exactly is the dataset?** Name, source/link, and paper if any.
   (BdSL40? BdSLW60? BdSLW401? Ishara-Lipi? ASL — WLASL? Something custom?)
2. ⭐ **Videos or images?** If videos: word-level (one sign per clip) or
   sentence-level (continuous signing)? Average clip length? FPS? Resolution?
3. ⭐ **How many classes (signs/words) and how many samples per class?**
4. **How many different signers?** Will we be evaluated signer-independent
   (test signers never seen in training — much harder) or signer-dependent?
5. **Is it labeled per clip, or do labels need alignment/annotation work?**
6. **Which sign language?** BdSL, ASL, or other? (Affects TTS language too.)
7. **How do I get it?** Drive link, hard disk, lab server? Can I keep a copy
   on my Google Drive for Colab access, or are there usage restrictions?
8. **Is there an official train/val/test split we must follow for comparability?**

## B. Scope and evaluation (what "done" means)

9. ⭐ **What is the minimum deliverable?** Isolated word recognition → speech?
   Or continuous sentence translation? (Continuous is a research-level jump —
   confirm we are NOT expected to do that in one semester.)
10. ⭐ **Is real-time/live webcam demo required, or is offline
    video-file → speech acceptable?** (Live constrains model size heavily.)
11. **What accuracy / how many signs would count as a successful project?**
    Is there a baseline paper we should beat or match?
12. **Voice output: is pre-recorded/neural TTS (Piper/gTTS) acceptable, or
    does "output voice" mean something more (e.g., Bangla TTS specifically)?**
13. **How will it be graded/demoed?** Live demo day? Report + video?
    Do faculty expect a comparison table against existing methods?

## C. Technical direction (so I don't build the wrong thing)

14. ⭐ **Is a landmark-based pipeline (MediaPipe → sequence model) acceptable,
    or do they expect end-to-end deep learning on raw video (3D-CNN,
    Video Transformer)?** (Landmark pipeline = feasible on free compute;
    raw-video training on 50 GB = likely NOT feasible on Colab free.)
15. **Head/face tracking is our differentiator — does the RA expect the face
    features to measurably improve accuracy (ablation study: with vs without
    face), or is including them enough?**
16. **Any required framework?** TensorFlow vs PyTorch vs no preference?
17. **Compute: does the lab have any GPU/server we can use, or is free
    Colab/Kaggle the assumption?** (50 GB won't fit Colab's disk trivially —
    can we preprocess to landmarks once and train on the small landmark files?)
18. **Can we preprocess the whole dataset to landmark files (shrinks 50 GB of
    video to a few hundred MB of .npy) and archive the raw videos, or must
    raw video stay in the loop?**

## D. Team and logistics

19. **Team members confirmed? Who is responsible for what?** (Suggest: one on
    data/preprocessing, one on modeling, one on live demo/TTS/report.)
20. **Timeline: proposal, mid-progress demo, final defense dates for the
    semester?** What must be shown at each checkpoint?
21. **Report format:** same template as other capstones? IEEE style?
    Is a GitHub repo submission expected?
22. **Can we reuse/cite existing open-source sign-language code as a baseline
    (with attribution), or must everything be written from scratch?**

## E. One smart follow-up after the dataset answer

23. Once the dataset is known, ask: **"Given this dataset, which 20–50 signs
    should we target first for the demo?"** — starting with a subset the RA
    picks avoids wasting weeks on the full class set before the pipeline works.
