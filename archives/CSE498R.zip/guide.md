# guide.md — Step-by-Step Guide for the 3-Day MediaPipe Sprint

This is YOUR checklist. Follow it top to bottom. Everything is free.
Colab = training. Arch laptop = webcam only. Claude Code = your coding partner
(always plan-first — see agent_docs/session_protocol.md).

---

## STEP 0 — One-time setup (30 min, tonight)

1. Google account ready → open https://colab.research.google.com and confirm
   you can create a notebook and set Runtime → Change runtime type → **T4 GPU**.
2. Kaggle account → verify phone number (needed for downloads) → Settings →
   API → **Create New Token** → save `kaggle.json` somewhere safe.
3. Put this repo on GitHub (private is fine) or Google Drive so both laptop
   and Colab can reach the notebooks:
   ```bash
   cd slr-voice
   git init && git add -A && git commit -m "scaffold"
   # optional: create a private GitHub repo and push
   ```

---

## STEP 1 — Day 1 morning: Arch Linux venv (~1.5 h)

Run these on the **Arch laptop**, one block at a time:

```bash
# 1. System packages (MediaPipe needs Python 3.9–3.12; Arch default is 3.13+)
sudo pacman -S --needed base-devel espeak-ng ffmpeg alsa-utils git wget unzip

# 2. Get Python 3.12 — easiest reliable way on Arch is pyenv:
sudo pacman -S --needed pyenv
# add to ~/.bashrc (or ~/.zshrc) if not already:
#   export PYENV_ROOT="$HOME/.pyenv"
#   command -v pyenv >/dev/null && eval "$(pyenv init -)"
exec $SHELL
pyenv install 3.12
pyenv shell 3.12
python --version          # MUST print Python 3.12.x

# 3. Create the venv
python -m venv ~/venvs/slr
source ~/venvs/slr/bin/activate
python --version          # still 3.12.x

# 4. Install the stack (CPU only)
pip install --upgrade pip wheel
pip install mediapipe==0.10.35 opencv-python numpy scikit-learn joblib
pip install pyttsx3 piper-tts
pip install tensorflow-cpu

# 5. Sanity checks — ALL must pass before continuing
python -c "import mediapipe as mp; print('mediapipe', mp.__version__)"
python -c "import mediapipe as mp; print('legacy solutions?', hasattr(mp,'solutions'))"  # False = correct
python -c "import cv2, sklearn, numpy, tensorflow; print('stack ok')"
espeak-ng "hello world"                     # you should HEAR it
python src/tts.py --test                    # from the repo root; you should hear it

# 6. Download MediaPipe .task models into models/
cd ~/path/to/slr-voice
wget -O models/hand_landmarker.task https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
wget -O models/face_landmarker.task https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
python src/extract_landmarks.py             # prints VECTOR_LEN — write it down
```

**If something fails:**
- `no matching distribution for mediapipe==0.10.35` → your venv is NOT 3.12. Recreate it.
- pyttsx3 silent → `espeak-ng` missing → `sudo pacman -S espeak-ng`.
- No audio at all → try `paplay /usr/share/sounds/alsa/Front_Center.wav` to debug PipeWire/ALSA first.

**Tick the first two boxes in `agent_docs/current_task.md`. Update `test_log.md`.**

---

## STEP 2 — Day 1 late morning: MediaPipe fundamentals in Colab (~2 h)

1. Upload `notebooks/01_mediapipe_fundamentals.ipynb` to Colab
   (File → Upload notebook), or open from Drive/GitHub.
2. Run every cell top to bottom. Read the printed landmark counts and the
   coordinate-format cell **carefully** — this is the core knowledge.
3. In your own notebook/notes, write from memory:
   - How many landmarks: hand = ___, face = ___, pose = ___
   - What does x=0.5, y=0.5 mean? What is z relative to?
   - Which landmark index is the wrist? The index fingertip?
4. Try your own photo (upload with the folder icon, change `test.jpg`).

---

## STEP 3 — Day 1 afternoon: static CNN quick win (~2.5 h)

1. Open `notebooks/02_static_cnn.ipynb` in Colab.
2. **Runtime → Change runtime type → T4 GPU** (do this FIRST).
3. Run all cells: mounts Drive, downloads Sign Language MNIST via your
   kaggle.json, trains the CNN (a few minutes), saves to Drive.
4. Target: **>90% test accuracy** (typically 95%+).
5. End-of-day: update `changelog.md`, `test_log.md`, tick Day-1 boxes,
   set Day 2 as Active in `current_task.md`. Commit.

**What you learned today:** raw pixels work on clean data but are fragile;
J and Z are missing from the dataset because they require MOTION — foreshadowing Day 2.

---

## STEP 4 — Day 2 morning: landmark classifier (~2.5 h)

1. Open `notebooks/03_landmark_classifier.ipynb` in Colab (no GPU needed).
2. Run all cells: downloads a 5-letter subset of ASL Alphabet, extracts
   63-value landmark vectors, trains RandomForest, shows confusion matrix,
   saves `landmark_rf.joblib` to Drive.
3. **Download `landmark_rf.joblib` from Drive → laptop `models/`** (needed Day 3).
4. Note the two normalizations (wrist-relative, scale) and WHY they matter.

---

## STEP 5 — Day 2 midday: record dynamic sequences LOCALLY (~1.5 h)

On the **Arch laptop** (webcam needed):

```bash
source ~/venvs/slr/bin/activate
cd ~/path/to/slr-voice
python src/collect_sequences.py --signs hello thanks iloveyou
```

- For each sign: press SPACE, perform the sign during the 30 recorded frames
  (~1–2 s), repeat 30 times. Use hand + face/head naturally (nod for "hello",
  smile for "thanks" — face data is part of the vector!).
- Keep the same seat position and lighting for all recordings.
- Then zip and upload:
```bash
cd data && zip -r sequences.zip sequences && cd ..
# upload data/sequences.zip to Google Drive → MyDrive/slr-voice/sequences.zip
```

---

## STEP 6 — Day 2 afternoon: train the LSTM in Colab (~2 h)

1. Open `notebooks/04_dynamic_lstm.ipynb`, set **T4 GPU**, run all cells.
2. Target: **>80% val accuracy** on your 3 signs. If lower: re-record more
   consistently, exaggerate motions, or reduce to 3 very distinct signs.
3. **Download `lstm_signs.keras` AND `lstm_labels.txt` from Drive → laptop `models/`.**
4. End-of-day ritual: changelog, test_log, current_task → Day 3. Commit.

---

## STEP 7 — Day 3 morning: Piper voice on the laptop (~1 h)

```bash
source ~/venvs/slr/bin/activate
cd ~/path/to/slr-voice

# English voice (small, fast)
wget -O models/en_US-amy-medium.onnx "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_US/amy/medium/en_US-amy-medium.onnx?download=true"
wget -O models/en_US-amy-medium.onnx.json "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_US/amy/medium/en_US-amy-medium.onnx.json?download=true"

# Test
echo "sign language recognized" | piper -m models/en_US-amy-medium.onnx --output_file /tmp/t.wav && aplay /tmp/t.wav
python src/tts.py --test        # should now say "[tts] backend: piper"
```

Bangla voice (optional): browse https://huggingface.co/rhasspy/piper-voices
→ `bn` folder → download the .onnx + .onnx.json into models/, then
`export PIPER_VOICE=models/<bangla-voice>.onnx` before running the demo.

---

## STEP 8 — Day 3 midday: THE live demo (~3 h)

Everything comes together. On the laptop:

```bash
source ~/venvs/slr/bin/activate
cd ~/path/to/slr-voice

# Sanity check files exist:
ls models/   # hand_landmarker.task face_landmarker.task landmark_rf.joblib
             # lstm_signs.keras lstm_labels.txt en_US-amy-medium.onnx(+.json)

# Static mode first (simpler — per-frame letters):
python src/live_demo.py --mode static

# Then the real thing (dynamic signs → speech):
python src/live_demo.py --mode dynamic
```

What you should see/hear: webcam window, green label + confidence on top,
FPS counter, and — when you hold a sign stably — the laptop SPEAKS the word
once (debounced, no repetition). Press Q to quit; note the printed avg FPS.

**Troubleshooting:**
- FPS < 8 → in `extract_landmarks.py` reduce FACE_SUBSET, or process every
  2nd frame (ask Claude Code — plan first!).
- Wrong predictions → your seating/lighting differs from recording; re-record.
- `ValueError` about timestamps → timestamps must strictly increase; the
  provided `ts_ms()` already handles this — don't call detect twice with the
  same timestamp.

---

## STEP 9 — Day 3 afternoon: document everything (~2 h)

1. Record a 30–60 s screen/phone video of the working demo (evidence!).
2. Fill in: `milestone_log.md` (3 milestones + evidence), `test_log.md`
   (accuracy numbers, FPS), `changelog.md`.
3. Write a short "learnings.md" in agent_docs/ in your own words:
   what each approach is, when to use which, what surprised you.
4. Read `RA_QUESTIONS.md` and send the questions to your RA.
5. Final commit. Sprint complete. 🎉

---

## HOW TO USE CLAUDE CODE THROUGHOUT (vibe-code, but disciplined)

**First session ever — paste this:**
```
This project uses a plan-first, approve-before-code workflow with ADR-style
decisions. Read these files in order and confirm you understand: CLAUDE.md,
constitution.md, agent_docs/current_task.md, agent_docs/decisions.md,
agent_docs/codebase_map.md, agent_docs/session_protocol.md.
Then summarize back to me: (a) the project goal and pipeline, (b) the hard
constraints, (c) today's active task, (d) the end-of-session ritual.
Do NOT write any code yet — after your summary, wait for my instructions.
```

**Every later session:** paste the "Start of EVERY session" block from
`agent_docs/session_protocol.md`. Approve plans before code. End with the
end-of-session ritual block.

**Good vibe-code requests during the sprint (small + specific):**
- "The live demo runs at 6 FPS. Plan a change to process every 2nd frame."
- "Add a --camera N flag to live_demo.py. Plan first."
- "Notebook 03's detection rate is only 60% — plan a diagnostic cell."

**Bad requests (too big, violates workflow):**
- "Build the whole sign language system" ❌
- "Rewrite everything to use PyTorch" ❌ (needs an ADR + your approval)
