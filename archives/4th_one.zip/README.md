# 🚀 My Learning Hub — Full-Stack Developer Journey

> **Goal:** Land a Full-Stack Developer job within 6 months by building real projects.
> **Level:** Beginner | **Daily Time:** 2–3 hours | **Stack:** React + TypeScript + Node.js + PostgreSQL

---

## 📁 What's in This Folder

| File | What It Does | When to Use It |
|------|-------------|----------------|
| `context-prompt.md` | Paste this into any AI before starting work | Every new AI chat session |
| `plan.md` | Your full 6-month roadmap with projects | Check weekly to know what's next |
| `skill.md` | Track what you've learned, what to improve | Update after every session |
| `chatlog.md` | Log what you did and learned each session | Fill in AFTER each coding session |
| `historychat.md` | One-line summary of every session ever | Auto-updates from chatlog |

---

## 🖥️ Your Local Folder Setup on PC

```
D:/  (or wherever you want)
└── dev/
    ├── learning-hub/          ← This folder (push to GitHub)
    │   ├── README.md
    │   ├── context-prompt.md
    │   ├── plan.md
    │   ├── skill.md
    │   ├── chatlog.md
    │   └── historychat.md
    │
    └── projects/              ← All your code projects go here
        ├── 01-portfolio-website/
        ├── 02-task-manager/
        ├── 03-weather-dashboard/
        ├── 04-notes-app/
        └── ...
```

---

## ⚡ Your Daily Workflow (Do This Every Day)

```
1. Open terminal
2. cd into today's project folder
3. Open context-prompt.md → copy it → paste into opencode or any AI
4. Tell the AI: "Today I want to [your goal]"
5. Code with AI, understand every line
6. git add . && git commit -m "your message" → git push
7. After session: fill in chatlog.md
8. Update skill.md if you learned something new
```

---

## 📌 GitHub Repos You Need

1. **`learning-hub`** → Push this folder (plan, logs, skills)
2. **`portfolio-website`** → Project 1
3. **`task-manager`** → Project 2
4. *(one repo per project)*

---

## 🛠️ Tools You Need Installed

- [ ] Git — https://git-scm.com
- [ ] Node.js (LTS) — https://nodejs.org
- [ ] opencode — https://opencode.ai
- [ ] VS Code — https://code.visualstudio.com
- [ ] GitHub account — https://github.com

---

*Start with `plan.md` → Then set up your tools → Then open `context-prompt.md`*
