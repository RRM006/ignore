# 🛠️ Skill Tracker

> **Why this file exists:**
> When you're learning, it's easy to feel like you're not improving. This file tracks every skill you gain.
> It also helps your AI know exactly what you can and can't do — so it doesn't over-explain things you know or skip things you don't.
>
> **How to use it:**
> After each session, come here and update the skill you practiced. Move it from "Not Started" → "Learning" → "Comfortable" → "Strong".
> Also paste the "Skill Snapshot" section into your AI at the start of a session so it knows your level precisely.

---

## 🔄 Skill Levels Explained

| Level | What It Means |
|-------|--------------|
| ❌ Not Started | Haven't touched this yet |
| 🟡 Learning | I've seen it but I need to look things up constantly |
| 🟢 Comfortable | I can use it with occasional help |
| 💪 Strong | I can use it confidently and explain it to someone else |

---

## 🧰 Core Skills

### 🖥️ Developer Tools

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| Terminal / Command Line basics | ❌ | | cd, ls, mkdir, pwd |
| Git basics (add, commit, push, log) | ❌ | | |
| GitHub (repos, push, clone) | ❌ | | |
| GitHub branching + PRs | ❌ | | |
| opencode (AI terminal agent) | ❌ | | |
| VS Code basics | ❌ | | |
| Environment variables (.env) | ❌ | | |
| npm basics | ❌ | | install, run, scripts |

---

### 🌐 Frontend

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| HTML structure + semantic tags | ❌ | | |
| CSS basics (box model, selectors) | ❌ | | |
| Flexbox | ❌ | | |
| CSS Grid | ❌ | | |
| Responsive design (mobile-friendly) | ❌ | | |
| JavaScript variables + functions | ❌ | | |
| JavaScript arrays + objects | ❌ | | |
| DOM manipulation | ❌ | | |
| Event listeners | ❌ | | |
| fetch() + async/await | ❌ | | |
| JSON | ❌ | | |
| Error handling (try/catch) | ❌ | | |
| localStorage | ❌ | | |

---

### ⚛️ React

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| What React is and why it exists | ❌ | | |
| Components (functional) | ❌ | | |
| Props | ❌ | | |
| State with useState | ❌ | | |
| useEffect | ❌ | | |
| Lists + keys | ❌ | | |
| Conditional rendering | ❌ | | |
| Forms in React | ❌ | | |
| React Router (multiple pages) | ❌ | | |
| Context API (global state) | ❌ | | |
| Fetching data in React | ❌ | | |

---

### 🔷 TypeScript

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| Why TypeScript exists | ❌ | | |
| Basic types (string, number, boolean) | ❌ | | |
| Arrays + object types | ❌ | | |
| Interfaces | ❌ | | |
| Type props in React components | ❌ | | |
| Fixing TypeScript errors | ❌ | | |

---

### 🔧 Backend (Node.js + Express)

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| What a server is | ❌ | | |
| What an API is | ❌ | | |
| What REST means | ❌ | | |
| Node.js basics | ❌ | | |
| Express setup + routes | ❌ | | |
| Middleware | ❌ | | |
| Request + Response objects | ❌ | | |
| GET, POST, PUT, DELETE routes | ❌ | | |
| Error handling in Express | ❌ | | |
| Testing APIs with Postman | ❌ | | |
| JWT Authentication | ❌ | | |
| Password hashing (bcrypt) | ❌ | | |

---

### 🗄️ Database

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| What a database is and why it exists | ❌ | | |
| Basic SQL (SELECT, INSERT, UPDATE, DELETE) | ❌ | | |
| PostgreSQL setup | ❌ | | |
| What an ORM is | ❌ | | |
| Prisma schema | ❌ | | |
| Prisma migrations | ❌ | | |
| Prisma Client (queries) | ❌ | | |
| Database relationships (one-to-many) | ❌ | | |

---

### ☁️ Deployment

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| Deploy frontend to Vercel | ❌ | | |
| Deploy backend to Railway | ❌ | | |
| Environment variables in production | ❌ | | |

---

### 🤝 Open Source + Collaboration

| Skill | Level | Last Practiced | Notes |
|-------|-------|---------------|-------|
| Fork a repo | ❌ | | |
| Clone a forked repo | ❌ | | |
| Create a feature branch | ❌ | | |
| Open a Pull Request | ❌ | | |
| Write a PR description | ❌ | | |
| Respond to code review | ❌ | | |
| Open a GitHub Issue | ❌ | | |
| Read and understand someone else's codebase | ❌ | | |

---

## 🤖 Paste Into AI: My Skill Snapshot

> Copy the section below and paste it into your AI at the start of a session so it knows exactly where you are.

```
My current skill levels (be a mentor based on this):

TOOLS: Terminal[❌] Git[❌] GitHub[❌] opencode[❌]

FRONTEND: HTML[❌] CSS[❌] Flexbox[❌] JS-basics[❌]
          async/await[❌] fetch[❌]

REACT: Components[❌] useState[❌] useEffect[❌] 
       React-Router[❌] TypeScript-React[❌]

BACKEND: Express[❌] REST-APIs[❌] JWT-Auth[❌]

DATABASE: SQL-basics[❌] PostgreSQL[❌] Prisma[❌]

GITHUB: Branching[❌] Pull-Requests[❌] Open-Source-contributions[❌]
```

*(Update the ❌ to 🟡/🟢/💪 as you progress, then paste the updated version)*

---

*This file is a living document. The goal is to move every ❌ to 💪 by month 6.*
