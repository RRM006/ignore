# 📅 6-Month Full-Stack Developer Learning Plan

> **Start Date:** [Fill in your start date]
> **Target:** Land a Full-Stack Developer job
> **Stack:** React + TypeScript + Node.js + Express + PostgreSQL + Prisma
> **Daily commitment:** 2–3 hours

---

## 🗺️ Big Picture Overview

| Phase | Months | Focus | Outcome |
|-------|--------|-------|---------|
| **Phase 1** | Month 1–2 | Foundation + First Projects | Git, HTML/CSS/JS, React basics, 2 projects |
| **Phase 2** | Month 3–4 | Backend + Full-Stack | Node.js, APIs, Database, 2 full-stack projects |
| **Phase 3** | Month 5–6 | Advanced + Open Source + Job Prep | OSS contributions, big project, portfolio ready |

---

## ✅ Phase Completion Checklist

- [ ] Phase 1 complete
- [ ] Phase 2 complete
- [ ] Phase 3 complete
- [ ] Portfolio live
- [ ] Resume updated
- [ ] Applying to jobs

---

# 📗 PHASE 1 — Foundation + First Projects (Month 1–2)

**Goal by end of Phase 1:** You can build a React frontend project from scratch and push it to GitHub.

---

## 🗓️ Week 1 — Setup + Git + GitHub

**Daily time:** 2–3 hours | **Goal:** Have your tools ready and make your first commit

### What to Learn
- What is Git? What is GitHub? Why does every developer use it?
- Terminal basics: `cd`, `ls`, `mkdir`, `pwd`
- Git commands: `init`, `add`, `commit`, `push`, `status`, `log`
- GitHub: Create account, create repo, connect local to remote

### Tasks
- [ ] Install Git, Node.js, VS Code, opencode
- [ ] Create GitHub account
- [ ] Create `learning-hub` repo on GitHub
- [ ] Push this entire learning-hub folder to GitHub
- [ ] Create `dev/projects/` folder on your PC
- [ ] Practice: create a test file, commit it, push it, delete it, commit that too

### Milestone 🏁
> Make your first GitHub commit and push. Screenshot it. It's your Day 1.

### opencode Prompt to Use
```
I just set up Git and GitHub. Walk me through creating my first repo,
connecting it to GitHub, and making my first commit. Explain every
git command and what it actually does under the hood.
```

---

## 🗓️ Week 2 — HTML + CSS Basics

**Goal:** Build a simple webpage that looks good, pushed to GitHub

### What to Learn
- HTML: structure, tags, semantic HTML (`header`, `main`, `section`, `footer`)
- CSS: selectors, box model, flexbox, basic responsive design
- How browsers read HTML and CSS

### Tasks
- [ ] Build a simple personal landing page (your name, about, links)
- [ ] Use flexbox for layout
- [ ] Make it look decent on mobile too (responsive)
- [ ] Push to GitHub with meaningful commit messages

### Milestone 🏁
> A live webpage with your name on it, pushed to GitHub.

### opencode Prompt to Use
```
I'm building a simple personal webpage with HTML and CSS. I want to
understand every tag and every CSS property. Start by explaining what
HTML really is and how a browser reads it. Then we'll build step by step.
```

---

## 🗓️ Week 3 — JavaScript Fundamentals

**Goal:** Understand JS well enough to make your webpage interactive

### What to Learn
- Variables (`let`, `const`), data types, operators
- Functions (regular, arrow functions)
- Arrays and Objects — what they are, how to use them
- DOM manipulation: `querySelector`, `addEventListener`, `innerHTML`
- Events: click, input, submit
- `if/else`, loops (`for`, `forEach`, `map`)

### Tasks
- [ ] Add interactivity to your landing page (dark/light mode toggle, or a simple counter)
- [ ] Build a simple calculator (HTML + CSS + JS)
- [ ] Understand: what is the DOM? Why do we manipulate it?

### Milestone 🏁
> A working JS calculator, pushed to GitHub.

### What to Ask opencode
```
Explain to me what JavaScript really is. Why does it exist?
What does it mean that JS runs "in the browser"? Then let's
build a calculator step by step. Explain every line.
```

---

## 🗓️ Week 4 — JavaScript Continued + Async

**Goal:** Understand how JS fetches data from the internet

### What to Learn
- `fetch()` — how to get data from an API
- `async/await` — what is asynchronous? Why does it exist?
- JSON — what it is, how to parse it
- Error handling: `try/catch`

### Project: Weather Dashboard (basic version)
- Use a free weather API (OpenWeatherMap — free tier)
- User types a city name
- App shows temperature, weather condition
- Push to GitHub

### Milestone 🏁
> A working weather app that fetches real data. This is your **Project 1**.

---

## 🗓️ Week 5–6 — React Fundamentals

**Goal:** Understand why React exists and build something with it

### What to Learn
- Why React? What problem does it solve over plain HTML/JS?
- Components — what they are, why we split UI into components
- Props — passing data between components
- State with `useState` — what is "state"? Why does it matter?
- `useEffect` — when and why to use it
- Lists and keys in React
- Basic React project structure (what each file/folder does)

### How to Start a React Project
```bash
npm create vite@latest my-project -- --template react-ts
cd my-project
npm install
npm run dev
```

### Project: Task Manager App
- Add a task
- Mark task as done
- Delete a task
- Filter: All / Active / Completed
- Save to localStorage (so data doesn't disappear on refresh)
- Push to GitHub

### Milestone 🏁
> A working React Task Manager app. **This is Project 2.**

### opencode Prompt to Use
```
I'm learning React for the first time. Before we write any code,
explain to me: what problem does React solve? Why would I use it
instead of plain JavaScript? Use a real-world analogy. Then let's
set up a project step by step.
```

---

## 🗓️ Week 7–8 — TypeScript Introduction

**Goal:** Understand why TypeScript exists and start using it

### What to Learn
- What is TypeScript? Why do companies use it?
- Types: `string`, `number`, `boolean`, `array`, `object`
- Interfaces and type definitions
- How TypeScript catches bugs BEFORE you run code

### Task
- Convert your Task Manager to TypeScript
- Add types to all your components, props, and state
- Understand every TypeScript error and fix it yourself (with AI help)

### Milestone 🏁
> Your Task Manager is now in TypeScript. You understand what types are and why they matter.

---

# 📘 PHASE 2 — Backend + Full-Stack (Month 3–4)

**Goal by end of Phase 2:** You can build a complete full-stack app with a real database.

---

## 🗓️ Week 9–10 — Node.js + Express Basics

**Goal:** Build your first API (backend server)

### What to Learn
- What is a backend? What is a server? Why do we need one?
- What is Node.js? How is it different from browser JS?
- Express.js: routes, middleware, request/response
- REST API: what it is, how it works (GET, POST, PUT, DELETE)
- Tools: Postman or Thunder Client to test APIs

### Project: Simple REST API
- Routes: GET /tasks, POST /tasks, DELETE /tasks/:id
- Data stored in memory (array) for now — no database yet
- Test all routes with Postman
- Push to GitHub

### opencode Prompt to Use
```
I'm learning backend development for the first time. Explain to me:
what is a server? What is an API? What is REST? Use real-world analogies.
Then let's build a simple Express API step by step. Explain every line.
```

### Milestone 🏁
> A working REST API with 3 routes, tested with Postman.

---

## 🗓️ Week 11 — PostgreSQL + Prisma

**Goal:** Store data in a real database

### What to Learn
- What is a database? Why not just use a file?
- SQL basics: `SELECT`, `INSERT`, `UPDATE`, `DELETE`
- What is PostgreSQL? How to set it up locally
- What is Prisma ORM? Why use it instead of raw SQL?
- Prisma schema, migrations, Prisma Client

### Tasks
- [ ] Install PostgreSQL locally
- [ ] Connect your Express API to PostgreSQL using Prisma
- [ ] Replace in-memory array with real DB queries
- [ ] Learn what a migration is and why it matters

### Milestone 🏁
> Your API now reads/writes from a real database.

---

## 🗓️ Week 12–13 — Full-Stack Project: Notes App with Authentication

**Goal:** Build your first complete full-stack application

### What to Build
A notes app where users can sign up, log in, and manage their own notes.

**Features:**
- User registration and login (JWT authentication)
- Create, read, update, delete notes
- Each user only sees their own notes
- React frontend connected to Express backend

### What You'll Learn
- JWT (JSON Web Tokens) — what they are, how auth works
- Passwords: hashing with bcrypt — why you NEVER store plain text passwords
- Protected routes (frontend + backend)
- Connecting React to a Node.js API with fetch/axios
- Environment variables (`.env`) — what they are and why they matter

### Project Structure
```
notes-app/
├── frontend/    (React + TypeScript + Vite)
└── backend/     (Node.js + Express + TypeScript + Prisma + PostgreSQL)
```

### Milestone 🏁
> **Project 3** — A full-stack Notes App with real login. This is a portfolio piece.

---

## 🗓️ Week 14–15 — URL Shortener

**Goal:** Build a second full-stack project with analytics

### Features
- User pastes a long URL → gets a short URL (like bit.ly)
- Short URL redirects to original
- Click count tracked per link
- Dashboard showing all your links + click stats

### New Skills
- URL redirects in Express
- Data analytics (counting, aggregating in Prisma)
- Recharts or Chart.js for displaying stats in React

### Milestone 🏁
> **Project 4** — URL Shortener with analytics dashboard.

---

## 🗓️ Week 16 — Job Application Tracker

**Goal:** Build something personally useful + portfolio worthy

### Features
- Add job applications (company, role, date, status)
- Update status: Applied → Interview → Offer → Rejected
- Filter by status
- Notes per application

### Why This Project
- You'll actually use it during your job search
- Shows you can build practical, useful tools
- Demonstrates CRUD, filtering, state management

### Milestone 🏁
> **Project 5** — Job Application Tracker. Use this for real during your search.

---

# 📙 PHASE 3 — Advanced + Open Source + Job Prep (Month 5–6)

**Goal:** Build one big project, contribute to open source, prepare for interviews.

---

## 🗓️ Week 17–18 — Open Source Contributions

**Goal:** Make your first real open source contribution

### What is Open Source Contributing?
- Real projects on GitHub that anyone can improve
- You find a bug or small task, fix it, submit a PR (pull request)
- Maintainer reviews and merges your code
- Shows up on your GitHub profile

### Step-by-Step: Your First Contribution
1. Go to https://goodfirstissue.dev or https://github.com/explore
2. Filter by: JavaScript, TypeScript, or React
3. Look for issues labeled `good first issue` or `beginner friendly`
4. Read the issue carefully
5. Comment: "I'd like to work on this" (claim the issue)
6. Fork the repo → clone it → make changes → push → open PR

### GitHub Skills to Practice
- [ ] Fork a repo
- [ ] Clone a forked repo
- [ ] Create a branch for your change (`git checkout -b fix/issue-name`)
- [ ] Open a Pull Request with a clear description
- [ ] Respond to code review comments
- [ ] Create a GitHub Issue to report a bug you found

### Milestone 🏁
> At least 1 merged pull request to an open source project.

---

## 🗓️ Week 19–21 — Big Portfolio Project: Real-Time Chat App

**Goal:** Build your most impressive project

### Features
- User authentication (login/signup)
- Real-time messaging with WebSockets (Socket.io)
- Multiple chat rooms
- Message history stored in database
- Online/offline status

### New Skills
- WebSockets — what they are, how they differ from HTTP
- Socket.io — real-time communication library
- Event-driven programming

### Milestone 🏁
> **Project 6 (Main)** — Real-time Chat App. Your centerpiece portfolio project.

---

## 🗓️ Week 22 — Code Review Practice

**Goal:** Learn to read and review other people's code

### Tasks
- [ ] Review 3 projects from other beginners on GitHub
- [ ] Open constructive issues on their repos
- [ ] Ask for a code review on one of your projects (post in dev communities)
- [ ] Apply review feedback to your own code

---

## 🗓️ Week 23–24 — Job Preparation

**Goal:** Polish portfolio and start applying

### Portfolio Checklist
- [ ] All projects have a proper README (what it does, how to run it, tech used, screenshots)
- [ ] GitHub profile has a profile README (who you are, your stack, your projects)
- [ ] All projects are deployed (Vercel + Railway)
- [ ] At least 1 open source contribution visible on GitHub
- [ ] Consistent commit history (green squares on GitHub = proof you code daily)
- [ ] LinkedIn updated with projects

### Resume
- [ ] List your 3 best projects with links
- [ ] List your tech stack
- [ ] List your GitHub contributions
- [ ] Mention: "Built 6 full-stack projects from scratch"

### Interview Prep
- Review how your projects work end-to-end
- Practice explaining: "Walk me through how this project works"
- Practice: what is JWT, what is REST, what is a database index, what is async/await
- Do 10 JavaScript coding challenges on LeetCode (easy level only)

---

# 📦 All Projects Summary

| # | Project | Phase | Skills Covered |
|---|---------|-------|----------------|
| 1 | Personal Landing Page | Phase 1 | HTML, CSS, Flexbox |
| 2 | Task Manager | Phase 1 | React, useState, TypeScript |
| 3 | Weather Dashboard | Phase 1 | Fetch API, async/await |
| 4 | Notes App with Auth | Phase 2 | Full-stack, JWT, PostgreSQL |
| 5 | URL Shortener | Phase 2 | Backend, Analytics |
| 6 | Job Application Tracker | Phase 2 | CRUD, Filtering |
| 7 | Real-Time Chat App | Phase 3 | WebSockets, Socket.io |
| +  | Open Source Contributions | Phase 3 | Git workflow, PR, Code Review |

---

# ⚙️ GitHub Habits to Build From Day 1

| Habit | When |
|-------|------|
| Commit after every small change | Every session |
| Write meaningful commit messages | Every commit |
| Push at end of every session | Daily |
| Create a new branch for each feature | From Week 9 onward |
| Write a README for every project | Before pushing |
| Open issues for your own TODOs | From Week 5 onward |

---

*Update this file as you complete each week. Mark checkboxes. Track your progress.*
