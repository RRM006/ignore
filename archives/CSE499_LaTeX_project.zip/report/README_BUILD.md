# CSE499 Capstone Final Report — LaTeX project

**Compile with XeLaTeX**, three times (for the table of contents, the list of
figures, the list of tables and the cross-references):

```
xelatex main
xelatex main
xelatex main
```

XeLaTeX is required, not pdfLaTeX: the report contains Bangla examples in
Chapter 3 (the danger-sign trigger phrases) and Bengali conjunct shaping needs
an OpenType shaper. The font is bundled in `fonts/`.

## Layout

```
main.tex          the document; \input's everything below
preamble.tex      all BAETE formatting (page, fonts, headings, captions, folios)
frontmatter/      cover, transmittal, approval, declaration, acknowledgements, abstract
chapters/         ch1 … ch8 + references.tex
figures/          screenshots and generated charts
tikz/             the six drawn diagrams; each .tex is standalone and builds its own .pdf
fonts/            Noto Sans Bengali (SIL Open Font License, licence text included)
```

## Rebuilding a diagram

Each file in `tikz/` is a standalone document:

```
cd tikz && xelatex architecture.tex
```

## Rebuilding the per-dialect chart

`figures/wer_by_dialect.pdf` is generated from
`evaluation/baseline_models/evaluation_scores.csv` with matplotlib. It averages
Word Error Rate per (model, dialect) over the clips that carry a reference
transcript.

## Formatting, as taken from the template file

| Setting | Value |
|---|---|
| Page | US Letter 8.5 × 11 in, 1 in margins |
| Body | Times New Roman metrics (TeX Gyre Termes) 12 pt, justified, 1.5 spacing |
| Headings | Chapter 18 pt bold centred, new page; section 16 pt; subsection 14 pt |
| Folio | Arabic, centred in the footer, starting at 1 on the cover page |
| Figures | Caption below, centred, `Figure N. Caption.`, numbered through the document |
| Tables | Caption above, centred, small caps, Roman numerals |
| Citations | IEEE numeric |
