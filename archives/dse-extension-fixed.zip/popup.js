/**
 * DSE Live Price Checker — popup.js
 * ------------------------------------------------------------
 * Responsibilities:
 *  1. Restore last inputs from localStorage
 *  2. Fetch & parse dsebd.org/datafile/quotes.txt
 *  3. Calculate Profit/Loss + Percentage
 *  4. Render result card with colour coding
 *  5. Manage UI states (empty / loading / error / result)
 * ------------------------------------------------------------
 */

'use strict';

/* ── Storage keys ─────────────────────────────────────────── */
const KEY_SYMBOL = 'dse_last_symbol';
const KEY_BUY    = 'dse_last_buy';
const KEY_QTY    = 'dse_last_qty';

/* ── DSE data URL ─────────────────────────────────────────── */
const QUOTES_URL = 'https://www.dsebd.org/datafile/quotes.txt';

/* ── DOM refs ─────────────────────────────────────────────── */
const inputSymbol  = document.getElementById('input-symbol');
const inputBuy     = document.getElementById('input-buy');
const inputQty     = document.getElementById('input-qty');
const btnCheck     = document.getElementById('btn-check');
const btnRefresh   = document.getElementById('btn-refresh');

const stateLoading = document.getElementById('state-loading');
const stateError   = document.getElementById('state-error');
const stateEmpty   = document.getElementById('state-empty');
const resultCard   = document.getElementById('result-card');

const errorTitle   = document.getElementById('error-title');
const errorSub     = document.getElementById('error-sub');

const resSymbol    = document.getElementById('res-symbol');
const resLtp       = document.getElementById('res-ltp');
const resBuy       = document.getElementById('res-buy');
const resChangePill= document.getElementById('res-change-pill');
const resPlBdt     = document.getElementById('res-pl-bdt');
const resPlPct     = document.getElementById('res-pl-pct');
const resPlTotal   = document.getElementById('res-pl-total');
const plBanner     = document.getElementById('pl-banner');
const plTotal      = document.getElementById('pl-total');
const resQtyLabel  = document.getElementById('res-qty-label');
const footerUpdated= document.getElementById('footer-updated');

/* ══════════════════════════════════════════════════════════
   INIT — restore saved inputs on popup open
═══════════════════════════════════════════════════════════ */
(function init() {
  inputSymbol.value = localStorage.getItem(KEY_SYMBOL) || '';
  inputBuy.value    = localStorage.getItem(KEY_BUY)    || '';
  inputQty.value    = localStorage.getItem(KEY_QTY)    || '';

  // If we have a saved symbol + buy price, auto-run the check
  if (inputSymbol.value && inputBuy.value) {
    handleCheck();
  }
})();

/* ══════════════════════════════════════════════════════════
   EVENTS
═══════════════════════════════════════════════════════════ */

// Auto-uppercase symbol as user types
inputSymbol.addEventListener('input', () => {
  const pos = inputSymbol.selectionStart;
  inputSymbol.value = inputSymbol.value.toUpperCase();
  inputSymbol.setSelectionRange(pos, pos);
});

// Check on button click
btnCheck.addEventListener('click', handleCheck);

// Allow Enter key in any field to trigger check
[inputSymbol, inputBuy, inputQty].forEach(el => {
  el.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleCheck();
  });
});

// Refresh icon spins + re-runs last check
btnRefresh.addEventListener('click', () => {
  btnRefresh.classList.add('spinning');
  handleCheck().finally(() => {
    setTimeout(() => btnRefresh.classList.remove('spinning'), 600);
  });
});

/* ══════════════════════════════════════════════════════════
   MAIN HANDLER
═══════════════════════════════════════════════════════════ */
async function handleCheck() {
  const symbol   = inputSymbol.value.trim().toUpperCase();
  const buyPrice = parseFloat(inputBuy.value);
  const qty      = parseInt(inputQty.value, 10) || null;

  /* ── Validate inputs ──────────────────────────────────── */
  if (!symbol) {
    showError('Symbol required', 'Please enter a stock symbol (e.g. GP, BEXIMCO).');
    return;
  }
  if (!inputBuy.value || isNaN(buyPrice) || buyPrice <= 0) {
    showError('Invalid buy price', 'Enter a valid positive buy price in BDT.');
    return;
  }

  /* ── Persist inputs ───────────────────────────────────── */
  localStorage.setItem(KEY_SYMBOL, symbol);
  localStorage.setItem(KEY_BUY,    inputBuy.value);
  localStorage.setItem(KEY_QTY,    inputQty.value);

  /* ── Fetch & parse ────────────────────────────────────── */
  showLoading();

  try {
    const ltp = await fetchLTP(symbol);

    if (ltp === null) {
      showError(
        `"${symbol}" not found`,
        'Symbol not listed on DSE, or data is unavailable right now.'
      );
      return;
    }

    renderResult({ symbol, ltp, buyPrice, qty });

  } catch (err) {
    console.error('[DSE Tracker]', err);

    if (err.name === 'AbortError') {
      showError('Request timed out', 'DSE server took too long. Try again.');
    } else if (!navigator.onLine) {
      showError('No internet connection', 'Check your network and retry.');
    } else {
      showError(
        'Could not fetch data',
        'CORS or network issue. DSE may be blocking direct requests.'
      );
    }
  }
}

/* ══════════════════════════════════════════════════════════
   DATA FETCHING & PARSING
═══════════════════════════════════════════════════════════ */

/**
 * Fetch quotes.txt and return the Last Trade Price for `symbol`.
 * DSE quotes.txt format (pipe-delimited, 1 row per stock):
 *   TRADING_CODE|LTP|HIGH|LOW|OPENP|CLOSEP|YCP|CHANGE|TRADE|VALUE|VOLUME
 *
 * Falls back to comma-delimited if pipe not found.
 *
 * @param {string} symbol - Uppercase stock symbol
 * @returns {number|null} LTP or null if not found
 */
async function fetchLTP(symbol) {
  // 8-second timeout via AbortController
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);

  const response = await fetch(QUOTES_URL, {
    method: 'GET',
    signal: controller.signal,
    cache: 'no-store',          // always get fresh data
    headers: { 'Accept': 'text/plain' }
  });

  clearTimeout(timer);

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const text = await response.text();
  return parseQuotes(text, symbol);
}

/**
 * Parse the raw text from quotes.txt.
 * Attempts pipe (`|`) then comma (`,`) as delimiter.
 *
 * Expected column order (0-indexed):
 *   0  → Trading Code (SYMBOL)
 *   1  → LTP  (Last Trade Price)
 *
 * @param {string} text   - Raw file contents
 * @param {string} symbol - Symbol to find
 * @returns {number|null}
 */
function parseQuotes(text, symbol) {
  const lines = text.split('\n');

  // Detect delimiter from first non-empty data line
  const sampleLine = lines.find(l => l.trim().length > 0 && !l.startsWith('#')) || '';
  const delimiter  = sampleLine.includes('|') ? '|' : ',';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;   // skip blanks / comments

    const cols = trimmed.split(delimiter).map(c => c.trim());

    // col[0] = symbol, col[1] = LTP
    if (cols.length < 2) continue;

    const rowSymbol = cols[0].toUpperCase();
    if (rowSymbol !== symbol) continue;

    // Try col[1] as LTP; some formats have quoted numbers like "315.50"
    const ltpRaw = cols[1].replace(/[^0-9.]/g, '');
    const ltp    = parseFloat(ltpRaw);

    return isNaN(ltp) ? null : ltp;
  }

  return null;   // symbol not found in the file
}

/* ══════════════════════════════════════════════════════════
   RESULT RENDERING
═══════════════════════════════════════════════════════════ */

/**
 * Render the result card with P&L information.
 *
 * @param {{ symbol: string, ltp: number, buyPrice: number, qty: number|null }} data
 */
function renderResult({ symbol, ltp, buyPrice, qty }) {
  const pl      = ltp - buyPrice;                             // Profit/Loss per share
  const plPct   = (pl / buyPrice) * 100;                     // Percentage
  const isProfit = pl >= 0;
  const sign     = isProfit ? '+' : '';

  /* ── Populate text nodes ──────────────────────────────── */
  resSymbol.textContent = symbol;
  resLtp.textContent    = fmt(ltp);
  resBuy.textContent    = fmt(buyPrice);
  resPlBdt.textContent  = `${sign}${fmt(pl)} BDT`;
  resPlPct.textContent  = `${sign}${plPct.toFixed(2)}%`;

  /* ── Change pill (header) ─────────────────────────────── */
  resChangePill.textContent = `${sign}${plPct.toFixed(2)}%`;
  resChangePill.className   = 'result-card__change-pill ' + (isProfit ? 'pill--profit' : 'pill--loss');

  /* ── Banner color ─────────────────────────────────────── */
  plBanner.className = 'pl-banner ' + (isProfit ? 'pl-banner--profit' : 'pl-banner--loss');

  /* ── Quantity total row ───────────────────────────────── */
  if (qty && qty > 0) {
    const totalPl = pl * qty;
    resPlTotal.textContent = `${sign}${fmt(totalPl)} BDT`;
    resPlTotal.style.color = isProfit ? 'var(--clr-profit)' : 'var(--clr-loss)';
    resQtyLabel.textContent = `× ${qty} shares`;
    plTotal.hidden = false;
  } else {
    plTotal.hidden = true;
  }

  /* ── Timestamp ────────────────────────────────────────── */
  footerUpdated.textContent = 'Updated: ' + new Date().toLocaleTimeString('en-GB', {
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });

  showResult();
}

/* ══════════════════════════════════════════════════════════
   UI STATE HELPERS
═══════════════════════════════════════════════════════════ */

/** Hide all dynamic panels */
function hideAll() {
  stateLoading.hidden = true;
  stateError.hidden   = true;
  stateEmpty.hidden   = true;
  resultCard.hidden   = true;
}

function showLoading() {
  hideAll();
  stateLoading.hidden = false;
}

function showEmpty() {
  hideAll();
  stateEmpty.hidden = false;
}

function showError(title, sub) {
  hideAll();
  errorTitle.textContent = title;
  errorSub.textContent   = sub || '';
  stateError.hidden      = false;
}

function showResult() {
  hideAll();
  resultCard.hidden = false;
}

/* ══════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════ */

/**
 * Format a number to 2 decimal places with comma grouping.
 * e.g. 1234.5 → "1,234.50"
 *
 * @param {number} n
 * @returns {string}
 */
function fmt(n) {
  return Math.abs(n).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
