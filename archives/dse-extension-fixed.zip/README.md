# DSE Live Price Checker — Chrome Extension

A lightweight Chrome extension to check live DSE stock prices and instantly calculate profit/loss.

---

## 📁 Folder Structure

```
dse-extension/
├── manifest.json        ← Chrome Extension config (Manifest V3)
├── popup.html           ← Extension popup UI
├── popup.css            ← All styling (Figma-accurate)
├── popup.js             ← Fetch, parse, calculate, render logic
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## 🚀 Setup Instructions

### 1. Load the Extension in Chrome

1. Open Chrome and navigate to: `chrome://extensions`
2. Enable **Developer Mode** (toggle in top-right corner)
3. Click **"Load unpacked"**
4. Select the `dse-extension/` folder
5. The extension icon appears in your Chrome toolbar ✅

### 2. Using the Extension

1. Click the DSE Tracker icon in the toolbar
2. Enter a **Stock Symbol** (e.g., `GP`, `BEXIMCO`, `SQURPHARMA`)
3. Enter your **Buy Price** in BDT
4. Optionally enter **Quantity** of shares
5. Click **Check Price** or press `Enter`

---

## ⚙️ How It Works

```
User Input → Fetch quotes.txt → Parse CSV/Pipe data → Calculate P&L → Display
```

**Data Source:** `https://www.dsebd.org/datafile/quotes.txt`

**Formula:**
- `Profit/Loss = LTP − Buy Price`
- `% Change = (Profit/Loss / Buy Price) × 100`
- `Total P&L = Profit/Loss × Quantity` *(if qty provided)*

---

## ✨ Features

| Feature | Status |
|---|---|
| Live price from DSE | ✅ |
| Profit/Loss in BDT | ✅ |
| Percentage change | ✅ |
| Green/Red colour coding | ✅ |
| Auto-uppercase symbol | ✅ |
| Save last inputs | ✅ |
| Refresh button | ✅ |
| Loading / Error states | ✅ |
| Quantity × total P&L | ✅ |
| 8-second timeout handling | ✅ |

---

## ⚠️ Known Constraints

- **CORS**: Chrome extensions with `host_permissions` bypass CORS — the extension handles this correctly. If you load the HTML directly in a browser tab (not as extension), fetch will be blocked.
- **DSE Format Changes**: quotes.txt is parsed by auto-detecting `|` or `,` as delimiter. If DSE changes the format, update `parseQuotes()` in `popup.js`.
- **Market Hours**: Prices update only during DSE trading hours (Sun–Thu, 10AM–2:30PM BST).

---

## 🔧 Customisation

| What | Where |
|---|---|
| Auto-refresh interval | Add `setInterval(handleCheck, 10000)` in `popup.js` |
| Colour theme | Edit CSS variables in `popup.css` `:root` block |
| Additional data fields | Extend `parseQuotes()` to return more columns |
| Phase 2 alerts | Add Chrome `notifications` permission + background.js |
