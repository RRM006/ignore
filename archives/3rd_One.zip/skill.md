# 🧠 skill.md — Skills Tracker

> **Purpose**: Track every skill you are learning. Update this every 2 weeks.  
> **Why this file exists**: So you always know what you've learned, what's in progress, and what's next. Also great for your resume.  
> **Rating scale**: ⬜ Not started · 🟨 Heard of it · 🟧 Learning · 🟩 Can do it · ✅ Confident

---

## WHY SKILL.MD MATTERS

When you apply for jobs:
- You'll know exactly what to write on your resume
- You can answer "tell me about your skills" with confidence
- You know what gaps you still need to fill

When you're coding:
- You know which skills you need to ask AI to explain more
- You know which skills you can use without help

---

## 🛠️ CORE TECH SKILLS

### 1. HTML & CSS (Foundation)
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| HTML structure (tags, semantic HTML) | ⬜ | — | — |
| CSS basics (selectors, box model) | ⬜ | — | — |
| Flexbox | ⬜ | — | — |
| CSS Grid | ⬜ | — | — |
| Responsive design (mobile-friendly) | ⬜ | — | — |
| **Tailwind CSS** | ⬜ | — | Our main styling tool |

### 2. JavaScript & TypeScript
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| Variables, functions, loops | ⬜ | — | — |
| Arrays and objects | ⬜ | — | — |
| `async/await` and Promises | ⬜ | — | Used in every API call |
| `fetch()` — calling APIs | ⬜ | — | — |
| Error handling (`try/catch`) | ⬜ | — | — |
| ES6+ syntax (arrow functions, destructuring) | ⬜ | — | — |
| **TypeScript basics** (types, interfaces) | ⬜ | — | Our main language |
| TypeScript with React | ⬜ | — | — |

### 3. React (Frontend)
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| Components | ⬜ | — | Building blocks of UI |
| Props | ⬜ | — | Passing data between components |
| State (`useState`) | ⬜ | — | — |
| `useEffect` hook | ⬜ | — | — |
| Forms in React | ⬜ | — | — |
| Conditional rendering | ⬜ | — | — |
| Lists and mapping data | ⬜ | — | — |

### 4. Next.js (Full-Stack Framework)
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| What Next.js is and why we use it | ⬜ | — | — |
| App Router (pages, layouts) | ⬜ | — | Our routing system |
| Server vs Client components | ⬜ | — | Important concept |
| API Routes (backend in Next.js) | ⬜ | — | How we write backend code |
| Dynamic routes (`[id]`) | ⬜ | — | — |
| `loading.tsx` and `error.tsx` | ⬜ | — | — |
| Environment variables (`.env`) | ⬜ | — | For secrets/passwords |
| Deployment to Vercel | ⬜ | — | — |

### 5. Database & Prisma
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| What a database is | ⬜ | — | — |
| What SQL is | ⬜ | — | — |
| What PostgreSQL is | ⬜ | — | Our database |
| Tables, rows, columns | ⬜ | — | — |
| Relations (one-to-many, etc.) | ⬜ | — | — |
| **Prisma schema** | ⬜ | — | How we define our DB structure |
| Prisma queries (create, find, update, delete) | ⬜ | — | — |
| Migrations | ⬜ | — | How we change DB structure safely |
| Connecting to Neon (cloud DB) | ⬜ | — | — |

### 6. Authentication
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| What auth is and why we need it | ⬜ | — | — |
| Sessions vs JWT tokens | ⬜ | — | — |
| Cookies | ⬜ | — | — |
| NextAuth.js setup | ⬜ | Project 02 | — |
| Protected routes (middleware) | ⬜ | Project 02 | — |
| Password hashing (bcrypt) | ⬜ | Project 02 | — |

### 7. Real-Time (WebSockets)
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| What real-time means | ⬜ | — | — |
| HTTP vs WebSocket | ⬜ | — | — |
| Pusher (real-time service) | ⬜ | Project 03 | — |
| Events (emit, listen) | ⬜ | Project 03 | — |

### 8. Payments (Stripe)
| Skill | Status | Used In | Notes |
|-------|--------|---------|-------|
| What Stripe is | ⬜ | — | — |
| Stripe test mode | ⬜ | Project 05 | — |
| Creating a checkout session | ⬜ | Project 05 | — |
| Webhooks (what happens after payment) | ⬜ | Project 05 | — |

---

## 🔧 DEVELOPER TOOLS SKILLS

| Skill | Status | Used Since | Notes |
|-------|--------|-----------|-------|
| Terminal / Command Line basics | ⬜ | — | cd, ls, mkdir, etc. |
| Git (add, commit, push, pull) | ⬜ | — | Daily use |
| GitHub (repos, README) | ⬜ | — | — |
| Branches (`git checkout -b`) | ⬜ | — | — |
| Pull Requests (PRs) | ⬜ | — | — |
| Resolving merge conflicts | ⬜ | — | — |
| `.gitignore` | ⬜ | — | — |
| `.env` files for secrets | ⬜ | — | — |
| Reading error messages / Stack traces | ⬜ | — | — |
| Using browser DevTools | ⬜ | — | — |
| Using AI to debug (effective prompting) | ⬜ | — | — |

---

## 🌍 OPEN SOURCE SKILLS

| Skill | Status | Notes |
|-------|--------|-------|
| Forking a repository | ⬜ | — |
| Cloning a fork | ⬜ | — |
| Creating a branch for your fix | ⬜ | — |
| Reading an issue and understanding it | ⬜ | — |
| Writing a good PR description | ⬜ | — |
| Responding to code review feedback | ⬜ | — |
| Having a PR merged | ⬜ | — |

---

## 💼 SOFT / PROFESSIONAL SKILLS

| Skill | Status | Notes |
|-------|--------|-------|
| Can explain a project in 2 minutes | ⬜ | Interview skill |
| Can read someone else's code and understand it | ⬜ | — |
| Can find and read official documentation | ⬜ | — |
| Can use Stack Overflow effectively | ⬜ | — |
| Can estimate how long a task will take | ⬜ | — |
| Can break a feature into small steps before coding | ⬜ | — |

---

## 📊 SKILL PROGRESS SNAPSHOT

> Update this every 2 weeks to see your growth.

| Date | ⬜ Not started | 🟨 Heard of | 🟧 Learning | 🟩 Can do | ✅ Confident |
|------|---------------|------------|------------|----------|------------|
| Start | — | — | — | — | — |
| Week 4 | — | — | — | — | — |
| Week 8 | — | — | — | — | — |
| Week 12 | — | — | — | — | — |
| Week 16 | — | — | — | — | — |
| Week 20 | — | — | — | — | — |
| Week 26 | — | — | — | — | — |

---

## 🏷️ RESUME SKILLS LIST (fill as you gain confidence)

> When a skill reaches ✅ Confident, add it here. This becomes your resume skills section.

**Languages**: TypeScript, JavaScript  
**Frameworks**: (add when ✅)  
**Tools**: Git, GitHub  
**Databases**: (add when ✅)  
**Other**: (add when ✅)  

---

*Last updated: [Date] | Total skills tracked: 60+*
