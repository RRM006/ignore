# 📋 plan.md — My Full-Stack Developer Roadmap
> **Goal**: Get a Full-Stack Developer job  
> **Stack**: Next.js · TypeScript · Tailwind CSS · PostgreSQL · Prisma · Vercel  
> **Time**: 2–3 hours/day · 6 months  
> **Method**: Vibe Coding — AI-assisted building with full understanding  
> **Updated**: [Fill your start date here]

---

## 🗺️ THE BIG PICTURE

```
Month 1     → Setup + First Project (URL Shortener)
Month 2     → Task Manager with Login/Signup
Month 3     → Real-Time Chat App
Month 4     → Blog / CMS Platform  ← Open Source contributions START here
Month 5     → E-Commerce Store
Month 6     → Capstone Project + Job Prep + Open Source active
```

**By the end you will have**:
- 6 deployed, live projects on GitHub (portfolio-ready)
- 1+ open-source contribution (PR merged or issue raised)
- Real Git workflow experience (branches, commits, PRs)
- Confidence to build any app from scratch
- A resume with real project links

---

## ⚙️ PHASE 0 — ONE-TIME SETUP (Week 1, ~3 days)

**Goal**: Set up your entire workspace so you never waste time on setup again.

### Tools to Install (in this order)
- [ ] **Node.js** (v20+) — download from nodejs.org
- [ ] **VS Code** or **Cursor** — your code editor (Cursor is better for vibe coding)
- [ ] **Git** — download from git-scm.com
- [ ] **GitHub account** — create at github.com if you don't have one
- [ ] **Vercel account** — create at vercel.com (free, link to GitHub)
- [ ] **Neon or Supabase account** — free PostgreSQL database in the cloud

### One-Time Folder Setup
Run these commands in your terminal once:
```bash
mkdir my-dev-journey
cd my-dev-journey
mkdir projects notes open-source
touch plan.md skill.md chatlog.md historychat.md
```

### Git Global Setup (run once)
```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

### What to Learn in Week 1 (Git basics with AI)
Ask your AI assistant to explain these one at a time:
- What is Git? What is GitHub? What is the difference?
- What does `git init`, `git add`, `git commit`, `git push` mean?
- What is a branch? What is a pull request?
- How to create a GitHub repo and link it to a local folder

**Mini practice**: Create a test folder, init a git repo, make a README.md, push it to GitHub.

---

## 📦 PHASE 1 — PROJECT 01: URL Shortener (Weeks 2–4)

**Real-world example**: bit.ly, tinyurl.com  
**What you'll learn**: Next.js basics, API routes, database (Prisma + PostgreSQL), routing, forms

### What This App Does
- User enters a long URL (e.g., `https://www.example.com/some/long/url`)
- App creates a short code (e.g., `myapp.com/abc123`)
- When anyone visits the short URL, they get redirected to the original

### Why This Project
- Small enough to finish in 2 weeks
- Covers the full stack: frontend form → API → database → redirect
- Real feature used by millions of apps

### Week 2 — Frontend + Structure
- [ ] Create Next.js app with TypeScript + Tailwind
- [ ] Build the UI: input box + shorten button + results display
- [ ] Understand: what is a component, what is a page, what is routing

### Week 3 — Backend + Database
- [ ] Set up PostgreSQL on Neon (free cloud DB)
- [ ] Set up Prisma, define your first schema (URL table)
- [ ] Write the API route: receive URL → generate short code → save to DB
- [ ] Understand: what is an API route, what is a database schema, what is Prisma

### Week 4 — Connect + Deploy
- [ ] Connect frontend to backend (form submits → API → DB → show result)
- [ ] Add redirect: visiting `/abc123` fetches original URL from DB and redirects
- [ ] Deploy to Vercel (live link!)
- [ ] Write a proper README.md
- [ ] Push all code to GitHub with clean commit history

### Git Habit for This Project
```
Good commit message examples:
✅ "feat: add URL shortening form UI"
✅ "feat: set up Prisma schema for URLs table"
✅ "fix: redirect not working for unknown short codes"
✅ "deploy: add vercel config and environment variables"

❌ "update"
❌ "fix stuff"
❌ "asdfgh"
```

---

## 🗂️ PHASE 2 — PROJECT 02: Task Manager with Auth (Weeks 5–8)

**Real-world example**: Todoist, Notion tasks, Trello  
**What you'll learn**: User authentication, sessions, protected routes, CRUD operations, user-specific data

### What This App Does
- User can sign up / log in
- Each user has their own private task list
- Tasks can be: created, marked done, deleted, edited
- Logged-out users cannot see other users' data

### Why This Project
- Auth is in EVERY real app — you must know this
- Teaches you: "who is this user?" which is fundamental
- CRUD (Create, Read, Update, Delete) is the foundation of all apps

### Week 5 — Auth Setup
- [ ] Add NextAuth.js to your project
- [ ] Email + password login OR Google OAuth (pick one with AI help)
- [ ] Understand: what is a session, what is a JWT token, what is a cookie

### Week 6 — Tasks Feature (Database)
- [ ] Add Task model to Prisma schema (linked to User)
- [ ] Build API routes: GET tasks, POST task, DELETE task, PATCH task
- [ ] Understand: what is a foreign key, what is a relation in a database

### Week 7 — Connect Frontend
- [ ] Build task list UI, add task form, delete button, complete checkbox
- [ ] Protect routes: if not logged in, redirect to login page
- [ ] Understand: what is middleware, what is a protected route

### Week 8 — Polish + Deploy
- [ ] Add loading states, error messages
- [ ] Deploy to Vercel with environment variables (.env)
- [ ] Write README, push to GitHub, share live link

---

## 💬 PHASE 3 — PROJECT 03: Real-Time Chat App (Weeks 9–12)

**Real-world example**: WhatsApp Web, Slack, Discord  
**What you'll learn**: WebSockets, real-time updates, rooms, Pusher or Socket.io

### What This App Does
- Users join a chat room with a name
- Messages appear instantly for everyone in the room (no page refresh)
- Simple, clean UI with message bubbles

### Why This Project
- Real-time is a key skill for senior roles
- Teaches you: events, listeners, push vs pull architecture
- Very impressive in a portfolio

### Steps (Ask AI each week for detailed breakdown)
- Week 9: Set up Pusher (real-time service, free tier) + understand WebSockets
- Week 10: Build chat UI + message input
- Week 11: Connect real-time events (send message → everyone sees it instantly)
- Week 12: Add rooms, user names, timestamps + deploy

---

## 📝 PHASE 4 — PROJECT 04: Blog / CMS Platform (Weeks 13–16)

**Real-world example**: Medium, dev.to, Hashnode  
**What you'll learn**: Rich text editing, file uploads, SEO basics, admin vs public views

### What This App Does
- Admin can write and publish blog posts (rich text)
- Public users can read posts, no login needed
- Posts have title, content, cover image, date

### Why This Project
- Content management is in every company
- Teaches you: file uploads, SEO meta tags, image optimization
- ⭐ Open source contributions START in this phase (see below)

### Open Source Starts Here (Week 13+)
Begin spending **30 minutes per day** on open source work:
- Find a beginner-friendly repo on GitHub (search: `good first issue`)
- Suggested repos: `facebook/docusaurus`, `vercel/next.js` (docs), `t3-oss/create-t3-app`
- Start with: fixing typos in docs, improving README files
- Learn the fork → clone → branch → PR workflow

---

## 🛒 PHASE 5 — PROJECT 05: E-Commerce Store (Weeks 17–20)

**Real-world example**: Shopify store, small business site  
**What you'll learn**: Stripe payments, cart state, product catalog, order management

### What This App Does
- Browse products with images, prices, descriptions
- Add to cart, update quantities
- Checkout with Stripe (test mode, no real money)
- Order confirmation

### Why This Project
- Payments + cart = most common business requirement
- Stripe integration is a highly valued skill
- Most complex project so far → shows growth

---

## 🏆 PHASE 6 — PROJECT 06: Capstone + Job Prep (Weeks 21–26)

### Week 21–23: Capstone Project
Pick ONE of these (AI will help you scope it):
- **Developer Portfolio Site** — your own personal website showing all 5 projects
- **Job Board** — post jobs, apply, filter by stack/location
- **Finance Tracker** — track income, expenses, visualize with charts
- **Recipe App with AI** — generate recipes using Claude API

This project should use everything you've learned.

### Week 24: Portfolio Polish
- [ ] All 6 projects deployed with live links
- [ ] Each GitHub repo has a proper README with screenshots
- [ ] Pin your best 4 projects on your GitHub profile
- [ ] Update your GitHub profile README (about me, skills, links)

### Week 25: Open Source Active
- [ ] Aim for at least 1 meaningful PR merged (not just a typo fix)
- [ ] Document your open source journey in a file: `open-source/log.md`
- [ ] Add your contribution to your resume

### Week 26: Job Prep
- [ ] Update resume with all projects + skills
- [ ] LinkedIn profile: add projects, update skills section
- [ ] Prepare for interviews: explain each project (what it does, how you built it, what was hard)
- [ ] Practice the question: "Walk me through this project from scratch"

---

## 📅 DAILY SCHEDULE TEMPLATE (2–3 hrs/day)

```
Day Session (2.5 hrs example):
├── 0:00 – 0:15  Review yesterday's notes / chatlog
├── 0:15 – 1:45  Build with AI (focused coding, 1 small task)
├── 1:45 – 2:00  Review what you built, ask AI to explain any unclear parts
├── 2:00 – 2:15  Git commit + push
└── 2:15 – 2:30  Update chatlog.md + historychat.md
```

---

## 🔄 OPEN SOURCE WORKFLOW (Start Week 13)

```
Your Flow for Every Contribution:

1. Find repo with "good first issue" label
2. Fork the repo (copy to your GitHub)
3. Clone your fork locally: git clone [your-fork-url]
4. Create a branch: git checkout -b fix/your-issue-name
5. Make your change
6. Commit: git commit -m "fix: describe what you fixed"
7. Push: git push origin fix/your-issue-name
8. Open Pull Request on GitHub
9. Respond to reviewer comments
10. Get it merged! 🎉
```

---

## ✅ PROGRESS TRACKER

### Projects
| # | Project | Started | Deployed | GitHub Link | Live Link |
|---|---------|---------|----------|-------------|-----------|
| 1 | URL Shortener | [ ] | [ ] | — | — |
| 2 | Task Manager | [ ] | [ ] | — | — |
| 3 | Chat App | [ ] | [ ] | — | — |
| 4 | Blog / CMS | [ ] | [ ] | — | — |
| 5 | E-Commerce | [ ] | [ ] | — | — |
| 6 | Capstone | [ ] | [ ] | — | — |

### Open Source
| Date | Repo | Issue/PR | Status |
|------|------|----------|--------|
| — | — | — | — |

---

## 📌 RULES I FOLLOW (Never Break These)

1. **Never copy code I don't understand** — Ask AI to explain it first
2. **Always git push before ending a session** — No exceptions
3. **One project at a time** — Finish before starting the next
4. **Small commits** — Commit after every feature, not once a week
5. **Update my logs** — chatlog.md and historychat.md after every session
6. **Ask when stuck** — Don't stare at an error for more than 15 minutes. Ask AI.

---

*Plan created: [Date] | Next review: [Date + 1 month]*
