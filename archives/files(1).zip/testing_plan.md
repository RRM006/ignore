# NSU Audit Core - Testing Plan

## Document Information
- **Version:** 1.0
- **Date:** February 2026
- **Purpose:** Comprehensive testing strategy for NSU Audit Core System
- **Scope:** All three implementation levels + edge cases

---

## Table of Contents
1. [Testing Overview](#testing-overview)
2. [Test Environment](#test-environment)
3. [Level 1 Tests](#level-1-tests-credit-tally-engine)
4. [Level 2 Tests](#level-2-tests-cgpa-calculator)
5. [Level 3 Tests](#level-3-tests-audit-engine)
6. [Mixed Scenario Tests](#mixed-scenario-tests)
7. [Test Execution](#test-execution)
8. [Expected Results](#expected-results)
9. [Validation Criteria](#validation-criteria)

---

## Testing Overview

### Testing Goals
1. Verify accurate credit calculation
2. Validate CGPA computation with NSU grading scale
3. Confirm retake handling (best grade selection)
4. Test waiver processing
5. Validate graduation audit logic
6. Ensure edge cases are handled correctly

### Test Coverage
- **Total Test Cases:** 24
- **Level 1:** 4 cases (credit calculation)
- **Level 2:** 4 cases (CGPA + waivers)
- **Level 3:** 4 cases (graduation audit)
- **Mixed Scenarios:** 12 cases (complex edge cases)

### Testing Approach
- **Unit Testing:** Individual functions tested in isolation
- **Integration Testing:** End-to-end workflows tested
- **Edge Case Testing:** Boundary conditions and unusual scenarios
- **Regression Testing:** Ensure changes don't break existing functionality

---

## Test Environment

### Prerequisites
- Python 3.7+
- Project files in `/nsu_audit_core/`
- All test CSV files in `tests/` directory
- Program knowledge files in `data/` directory

### Setup Instructions
```bash
cd nsu_audit_core
ls tests/level1/*.csv  # Verify test files exist
ls tests/level2/*.csv
ls tests/level3/*.csv
ls tests/mixed_scenarios/*.csv
ls data/*.md  # Verify program knowledge files
```

---

## Level 1 Tests: Credit Tally Engine

### Test Case L1-1: Standard Successful Student

**File:** `tests/level1/test_L1_1.csv`

**Description:** Student who completed all 130 credits with valid grades (A-D)

**Test Data:**
- 52 courses total
- All grades between A and D
- Mix of 3-credit and 4-credit courses
- Includes 0-credit labs (CSE225L, CSE231L, CSE311L, CSE331L)

**Expected Results:**
- Total Earned Credits: **130**
- Valid Courses: 49
- Excluded Courses: 0
- Zero-Credit Labs: 3

**Validation:**
- Credit total must equal exactly 130
- All 0-credit labs must be counted as completed but not toward credit total
- No courses should be excluded

**Command:**
```bash
python -m src.level1_credit_tally tests/level1/test_L1_1.csv
```

---

### Test Case L1-2: Mixed Grades with Failures

**File:** `tests/level1/test_L1_2.csv`

**Description:** Student with some F and W grades that should not count

**Test Data:**
- 140 credits attempted
- 130 valid credits (A-D)
- 10 credits with F/W grades

**Expected Results:**
- Total Earned Credits: **130**
- Excluded Courses: 3
  - CSE401 (F) - 3 credits
  - CSE402 (F) - 3 credits
  - CSE403 (W) - 4 credits

**Validation:**
- F and W grades must be excluded from earned credits
- Excluded courses must be listed in report

**Command:**
```bash
python -m src.level1_credit_tally tests/level1/test_L1_2.csv
```

---

### Test Case L1-3: Incomplete and Withdrawn Courses

**File:** `tests/level1/test_L1_3.csv`

**Description:** Student with I (Incomplete) and X grades

**Test Data:**
- Includes courses with I, X, and W grades
- Total attempted: ~135 credits

**Expected Results:**
- Earned Credits: **~128**
- Excluded: I, X, W grades
- Exclusion reasons properly labeled

**Validation:**
- All I, X, W grades must be excluded
- Each excluded course must show reason

**Command:**
```bash
python -m src.level1_credit_tally tests/level1/test_L1_3.csv
```

---

### Test Case L1-4: Zero-Credit Labs Edge Case

**File:** `tests/level1/test_L1_4.csv`

**Description:** Multiple 0-credit labs should not affect total

**Test Data:**
- 130 credits regular courses
- 3+ zero-credit labs

**Expected Results:**
- Total Earned Credits: **130**
- Zero-Credit Labs: 3+
- Labs listed separately from credit total

**Validation:**
- 0-credit courses must not add to total
- All 0-credit labs must be listed as completed

**Command:**
```bash
python -m src.level1_credit_tally tests/level1/test_L1_4.csv
```

---

## Level 2 Tests: CGPA Calculator

### Test Case L2-1: Standard CGPA Calculation

**File:** `tests/level2/test_L2_1.csv`

**Description:** Known grade distribution for predictable CGPA

**Test Data:**
- 50 credits at A (4.0)
- 40 credits at B+ (3.3)
- 30 credits at B (3.0)
- 10 credits at C (2.0)

**Calculation:**
```
Total Grade Points = (50×4.0) + (40×3.3) + (30×3.0) + (10×2.0)
                   = 200 + 132 + 90 + 20
                   = 442

Total Credits = 130

CGPA = 442 / 130 = 3.40
```

**Expected Results:**
- CGPA: **3.40**
- Academic Standing: **First Class**
- Total Grade Points: 442.00
- Total Credits Counted: 130

**Validation:**
- CGPA must be exactly 3.40
- Academic standing must be "First Class" (3.00-3.49)

**Command:**
```bash
python -m src.level2_cgpa_calculator tests/level2/test_L2_1.csv
```

---

### Test Case L2-2: Retake Scenarios

**File:** `tests/level2/test_L2_2.csv`

**Description:** Student who retook courses and improved grades

**Test Data:**
- CSE115: D (1.0) → A (4.0) - 4 credits
- MAT120: C (2.0) → B+ (3.3) - 3 credits
- CSE225: F (0.0) → A- (3.7) - 3 credits

**Expected Results:**
- Only best grades counted (A, B+, A-)
- Lower grades show 0.0 points in excluded list
- Retake improvement displayed

**Validation:**
- System must identify duplicate course codes
- Only highest grade must be used in CGPA
- Both attempts must appear in report

**Command:**
```bash
python -m src.level2_cgpa_calculator tests/level2/test_L2_2.csv
```

---

### Test Case L2-3: Course Waivers

**File:** `tests/level2/test_L2_3.csv`

**Description:** Student with ENG102 and MAT116 waivers

**Test Data:**
- Missing ENG102 (3 credits) and MAT116 (0 credits) from transcript
- Admin input: Waivers = ENG102, MAT116

**Expected Results:**
- ENG102 excluded from CGPA calculation
- Total Credits Counted = 127 (130 - 3)
- Waivers listed in report

**Validation:**
- Waived credits must not affect CGPA
- Waivers must be listed in output

**Command:**
```bash
python -m src.level2_cgpa_calculator tests/level2/test_L2_3.csv --waivers ENG102,MAT116
```

---

### Test Case L2-4: Complex Scenario

**File:** `tests/level2/test_L2_4.csv`

**Description:** Combination of retakes, waivers, F, W, and I grades

**Test Data:**
- 3 retaken courses
- 2 waivers (ENG102, MAT116)
- 1 current F grade
- 2 W grades
- 1 I grade

**Expected Results:**
- Best retake grades used
- Waivers excluded
- F, W, I grades excluded
- Accurate CGPA from remaining valid courses

**Validation:**
- All conditions must be handled simultaneously
- CGPA must be calculated correctly

**Command:**
```bash
python -m src.level2_cgpa_calculator tests/level2/test_L2_4.csv --waivers ENG102,MAT116
```

---

## Level 3 Tests: Audit Engine

### Test Case L3-1: Graduation Ready Student

**File:** `tests/level3/test_L3_1.csv`

**Description:** Perfect student meeting all graduation requirements

**Test Data:**
- All 130 credits completed
- CGPA: 3.55 (Cum Laude)
- All mandatory courses completed
- All category requirements met
- Electives: 3 from AI trail (meets concentration rule)
- All capstone projects done

**Expected Results:**
- **GRADUATION STATUS: ELIGIBLE**
- No deficiencies
- Academic Standing: **Cum Laude** (3.50-3.64)
- All categories complete

**Validation:**
- System must declare ELIGIBLE
- Zero deficiencies must be shown
- Honors must be displayed

**Command:**
```bash
python -m src.level3_audit_engine tests/level3/test_L3_1.csv BSCSE data/program_knowledge_BSCSE.md
```

---

### Test Case L3-2: Missing Core Courses

**File:** `tests/level3/test_L3_2.csv`

**Description:** Student missing mandatory courses from multiple categories

**Test Data:**
- 120 credits completed (missing 10)
- CGPA: 3.20
- Missing:
  - CSE373 (Major Core, 3 credits)
  - MAT350 (SEPS Core, 3 credits)
  - HIS103 (University Core, 3 credits)

**Expected Results:**
- **GRADUATION STATUS: NOT ELIGIBLE**
- Missing Courses: 3
- Total Deficiency: 9 credits
- Clear list of missing courses by category

**Validation:**
- System must identify all missing courses
- Must categorize missing courses correctly
- Must calculate total deficiency

**Command:**
```bash
python -m src.level3_audit_engine tests/level3/test_L3_2.csv BSCSE data/program_knowledge_BSCSE.md
```

---

### Test Case L3-3: Probation Status (Low CGPA)

**File:** `tests/level3/test_L3_3.csv`

**Description:** Student with CGPA below 2.0

**Test Data:**
- All 130 credits completed
- CGPA: 1.85 (Below minimum)
- All courses completed

**Expected Results:**
- **GRADUATION STATUS: NOT ELIGIBLE - ACADEMIC PROBATION**
- Reason: CGPA below 2.0 minimum
- All courses complete but CGPA insufficient

**Validation:**
- System must flag probation when CGPA < 2.0
- Must show this even if all courses are complete

**Command:**
```bash
python -m src.level3_audit_engine tests/level3/test_L3_3.csv BSCSE data/program_knowledge_BSCSE.md
```

---

### Test Case L3-4: Elective Trail Violation

**File:** `tests/level3/test_L3_4.csv`

**Description:** 9 elective credits but not 2 from same trail

**Test Data:**
- 130 credits completed
- CGPA: 3.40
- Electives:
  - CSE401 (Algorithms trail)
  - CSE411 (Software trail)
  - CSE422 (Networks trail)
  - (One from each of 3 different trails)

**Expected Results:**
- **GRADUATION STATUS: NOT ELIGIBLE**
- **Elective Trail Requirement Violation**
- Message: Must take minimum 2 courses from ONE trail
- Action: Take 1 more course from any existing trail

**Validation:**
- System must enforce concentration rule
- Must identify trail violation

**Command:**
```bash
python -m src.level3_audit_engine tests/level3/test_L3_4.csv BSCSE data/program_knowledge_BSCSE.md
```

---

## Mixed Scenario Tests

### Test Case MS-1: Multiple Retakes

**File:** `tests/mixed_scenarios/test_multiple_retakes.csv`

**Description:** Same course retaken 3 times

**Expected Result:** Best grade (A) used, other two excluded

---

### Test Case MS-2: Withdrawal Scenarios

**File:** `tests/mixed_scenarios/test_withdrawal_scenarios.csv`

**Description:** Multiple courses with W grade

**Expected Result:** All W grades excluded from credits and CGPA

---

### Test Case MS-3: Zero Credit Variations

**File:** `tests/mixed_scenarios/test_zero_credit_variations.csv`

**Description:** Various 0-credit lab combinations

**Expected Result:** Labs counted as complete, not toward credit total

---

### Test Case MS-4: Mixed Grades

**File:** `tests/mixed_scenarios/test_mixed_grades.csv`

**Description:** Full spectrum of grades (A through F, plus I/W/X)

**Expected Result:** Proper handling of all grade types

---

### Test Case MS-5: Perfect Student

**File:** `tests/mixed_scenarios/test_perfect_student.csv`

**Description:** All A grades (4.0 CGPA)

**Expected Result:** CGPA = 4.00, Summa Cum Laude

---

### Test Case MS-6: Failing Student

**File:** `tests/mixed_scenarios/test_failing_student.csv`

**Description:** All F grades

**Expected Result:** 0 earned credits, 0.00 CGPA

---

### Test Case MS-7: Partial Completion

**File:** `tests/mixed_scenarios/test_partial_completion.csv`

**Description:** Only ~40 credits completed

**Expected Result:** Missing 90 credits, not eligible

---

### Test Case MS-8: All Incomplete

**File:** `tests/mixed_scenarios/test_all_incomplete.csv`

**Description:** All courses have I (Incomplete) grade

**Expected Result:** 0 earned credits, 0.00 CGPA

---

### Test Case MS-9: Edge CGPA

**File:** `tests/mixed_scenarios/test_edge_cgpa.csv`

**Description:** Exactly 2.0 CGPA (boundary case)

**Expected Result:** CGPA = 2.00, Third Class (not probation)

---

### Test Case MS-10: High Honors

**File:** `tests/mixed_scenarios/test_high_honors.csv`

**Description:** CGPA 3.85+

**Expected Result:** CGPA ≥ 3.80, Summa Cum Laude

---

### Test Case MS-11: Transfer Student

**File:** `tests/mixed_scenarios/test_transfer_student.csv`

**Description:** Multiple waivers (transfer credits)

**Expected Result:** Waivers properly excluded from CGPA

---

### Test Case MS-12: Complex Electives

**File:** `tests/mixed_scenarios/test_complex_electives.csv`

**Description:** Electives from multiple trails

**Expected Result:** Proper trail validation

---

## Test Execution

### Automated Test Runner

Create a script to run all tests:

```bash
#!/bin/bash
# run_all_tests.sh

echo "======================================"
echo "NSU AUDIT CORE - COMPREHENSIVE TESTING"
echo "======================================"

# Level 1 Tests
echo "\n=== LEVEL 1 TESTS ==="
for file in tests/level1/*.csv; do
    echo "\n--- Testing: $(basename $file) ---"
    python -m src.level1_credit_tally "$file"
    echo "Status: $?"
done

# Level 2 Tests
echo "\n=== LEVEL 2 TESTS ==="
python -m src.level2_cgpa_calculator tests/level2/test_L2_1.csv
python -m src.level2_cgpa_calculator tests/level2/test_L2_2.csv
python -m src.level2_cgpa_calculator tests/level2/test_L2_3.csv --waivers ENG102,MAT116
python -m src.level2_cgpa_calculator tests/level2/test_L2_4.csv --waivers ENG102,MAT116

# Level 3 Tests
echo "\n=== LEVEL 3 TESTS ==="
for file in tests/level3/*.csv; do
    echo "\n--- Testing: $(basename $file) ---"
    python -m src.level3_audit_engine "$file" BSCSE data/program_knowledge_BSCSE.md
done

# Mixed Scenarios
echo "\n=== MIXED SCENARIO TESTS ==="
for file in tests/mixed_scenarios/*.csv; do
    echo "\n--- Testing: $(basename $file) ---"
    python -m src.level1_credit_tally "$file"
done

echo "\n======================================"
echo "ALL TESTS COMPLETED"
echo "======================================"
```

---

## Expected Results

### Summary Table

| Test ID | Description | Expected Credits | Expected CGPA | Expected Status |
|---------|-------------|------------------|---------------|-----------------|
| L1-1 | Standard student | 130 | N/A | N/A |
| L1-2 | With failures | 130 | N/A | N/A |
| L1-3 | Incompletes | 128 | N/A | N/A |
| L1-4 | Zero-credit labs | 130 | N/A | N/A |
| L2-1 | Standard CGPA | 130 | 3.40 | First Class |
| L2-2 | Retakes | ~130 | Variable | Variable |
| L2-3 | Waivers | 127 | Variable | Variable |
| L2-4 | Complex | ~125 | Variable | Variable |
| L3-1 | Grad ready | 130 | 3.55 | ELIGIBLE |
| L3-2 | Missing courses | 120 | 3.20 | NOT ELIGIBLE |
| L3-3 | Probation | 130 | 1.85 | NOT ELIGIBLE |
| L3-4 | Trail violation | 130 | 3.40 | NOT ELIGIBLE |

---

## Validation Criteria

### Level 1 Validation
- ✅ Correct credit total
- ✅ Proper exclusion of F/I/W/X
- ✅ Zero-credit labs tracked separately
- ✅ All courses accounted for

### Level 2 Validation
- ✅ Accurate CGPA calculation
- ✅ Best grade used for retakes
- ✅ Waivers excluded from CGPA
- ✅ Correct academic standing
- ✅ Probation flagged if CGPA < 2.0

### Level 3 Validation
- ✅ All missing courses identified
- ✅ Category deficiencies calculated
- ✅ Elective trail rules enforced
- ✅ Correct eligibility determination
- ✅ Clear action items provided

### Edge Case Validation
- ✅ Boundary conditions handled
- ✅ No crashes or errors
- ✅ Graceful handling of malformed data
- ✅ Clear error messages

---

## Test Checklist

### Pre-Test Checklist
- [ ] Python 3.7+ installed
- [ ] All source files present in `src/`
- [ ] All test files present in `tests/`
- [ ] Program knowledge files present in `data/`
- [ ] No syntax errors in code

### During Testing
- [ ] Run each test case
- [ ] Verify expected output
- [ ] Check for error messages
- [ ] Validate calculations
- [ ] Review edge cases

### Post-Test Checklist
- [ ] All 24 test cases passed
- [ ] No unexpected errors
- [ ] Output matches expected results
- [ ] Edge cases handled correctly
- [ ] Documentation updated

---

## Bug Reporting Template

If issues are found during testing:

```
Bug ID: [Sequential number]
Test Case: [Which test case failed]
Expected Result: [What should happen]
Actual Result: [What actually happened]
Steps to Reproduce:
1. [Step 1]
2. [Step 2]
Severity: [Critical/High/Medium/Low]
Status: [Open/In Progress/Fixed]
```

---

## Success Metrics

### Test Pass Criteria
- **100% of test cases pass** without errors
- **All calculations match** expected values
- **Edge cases handled** gracefully
- **No crashes** or unhandled exceptions

### Performance Metrics
- Processing time < 5 seconds per transcript
- Memory usage reasonable
- No memory leaks

---

**End of Testing Plan**

For questions or clarifications, refer to README.md or contact the development team.
