# NSU Audit Core System

A command-line tool for automating graduation eligibility verification for North South University students. This system validates student transcripts against program requirements, calculates CGPA, handles waivers and retakes, and generates comprehensive deficiency reports.

## 📋 Overview

The NSU Audit Core implements **three levels** of functionality:

1. **Level 1: Credit Tally Engine** - Calculates earned credits
2. **Level 2: CGPA Calculator** - Computes CGPA with retakes and waivers
3. **Level 3: Audit Engine** - Complete graduation audit with deficiency detection

## 🎯 Features

- ✅ **Accurate Credit Calculation** - Properly handles 0-credit labs, F/I/W/X grades
- ✅ **CGPA Calculation** - Implements NSU grading scale (A=4.0 to D=1.0)
- ✅ **Retake Handling** - Automatically uses best grade for retaken courses
- ✅ **Waiver Support** - Processes course waivers (ENG102, MAT116, etc.)
- ✅ **Graduation Audit** - Identifies missing courses and deficiencies
- ✅ **Elective Trail Validation** - Ensures minimum 2 courses from one trail
- ✅ **Academic Standing** - Determines honors and probation status
- ✅ **Comprehensive Reports** - Clear, actionable audit outputs

## 🏗️ Project Structure

```
nsu_audit_core/
├── src/
│   ├── __init__.py
│   ├── utils.py                        # Grade mapping utilities
│   ├── csv_parser.py                   # Transcript CSV parser
│   ├── program_knowledge.py            # Program requirements parser
│   ├── level1_credit_tally.py          # Level 1: Credit calculation
│   ├── level2_cgpa_calculator.py       # Level 2: CGPA calculation
│   └── level3_audit_engine.py          # Level 3: Complete audit
├── data/
│   ├── program_knowledge_BSCSE.md      # BSCSE requirements
│   ├── program_knowledge_BSEEE.md      # BSEEE requirements
│   └── transcript_template.csv         # CSV template
├── tests/
│   ├── level1/                         # Level 1 test cases (4 files)
│   ├── level2/                         # Level 2 test cases (4 files)
│   ├── level3/                         # Level 3 test cases (4 files)
│   └── mixed_scenarios/                # Complex test cases (12 files)
├── docs/
│   └── testing_plan.md                 # Comprehensive testing plan
├── generate_test_cases.py              # Test case generator script
└── README.md                           # This file
```

## 🚀 Installation

### Prerequisites

- Python 3.7 or higher
- No external dependencies required (uses only Python standard library)

### Setup

```bash
# Clone or download the project
cd nsu_audit_core

# No installation needed - ready to use!
```

## 📖 Usage

### Level 1: Credit Tally Engine

Calculate total earned credits from a transcript:

```bash
python -m src.level1_credit_tally tests/level1/test_L1_1.csv
```

**Example Output:**
```
=============================================================
NSU AUDIT CORE - LEVEL 1: CREDIT TALLY ENGINE
=============================================================

Total Courses Processed: 52
Total Attempted Credits: 133

                   EARNED CREDITS SUMMARY                    
-------------------------------------------------------------
Total Earned Credits: 130
Valid Courses (A-D): 49
Excluded Courses (F/I/W/X): 0
Zero-Credit Labs Completed: 3

=============================================================
RESULT: ✓ 130 CREDITS EARNED
=============================================================
```

### Level 2: CGPA Calculator & Waiver Handler

Calculate CGPA with retakes and waivers:

```bash
# With interactive waiver prompt
python -m src.level2_cgpa_calculator tests/level2/test_L2_1.csv

# With command-line waivers
python -m src.level2_cgpa_calculator tests/level2/test_L2_3.csv --waivers ENG102,MAT116
```

**Example Output:**
```
=============================================================
NSU AUDIT CORE - LEVEL 2: CGPA CALCULATOR
=============================================================

                     CGPA CALCULATION                        
-------------------------------------------------------------
Total Grade Points: 442.80
Total Credits Counted: 127.0
CGPA: 3.49
Academic Standing: First Class

                     RETAKEN COURSES                         
-------------------------------------------------------------
Total Retakes: 3

  • CSE115: Programming Language I
    Attempts: 2
    Grade: D → A (✓ Using best: A)
    Credits: 4 | Grade Points: 4.0

=============================================================
FINAL CGPA: 3.49 (First Class)
=============================================================
```

### Level 3: Audit Engine & Deficiency Reporter

Complete graduation audit:

```bash
python -m src.level3_audit_engine \
    tests/level3/test_L3_1.csv \
    BSCSE \
    data/program_knowledge_BSCSE.md

# With waivers
python -m src.level3_audit_engine \
    tests/level3/test_L3_2.csv \
    BSCSE \
    data/program_knowledge_BSCSE.md \
    --waivers ENG102,MAT116
```

**Example Output:**
```
======================================================================
NSU AUDIT CORE - LEVEL 3: GRADUATION AUDIT REPORT
======================================================================
Program: BSCSE

                        GRADUATION STATUS                             
----------------------------------------------------------------------
✓ ELIGIBLE FOR GRADUATION

                            SUMMARY                                   
----------------------------------------------------------------------
CGPA: 3.55
Academic Standing: Cum Laude
Total Credits: 130 / 130 required
Completed Courses: 52

                   CATEGORY-WISE REQUIREMENTS                        
----------------------------------------------------------------------
✓ University Core:
   Completed: 34 / 34 credits
✓ SEPS Core:
   Completed: 38 / 38 credits
✓ Major Core:
   Completed: 42 / 42 credits
✓ Capstone:
   Completed: 4 / 4 credits

                     ELECTIVE REQUIREMENTS                            
----------------------------------------------------------------------
✓ Elective requirements met

Electives Taken: 3 / 3 required

Trail Distribution:
  ✓ Artificial Intelligence Trail: 3 courses
      - CSE440
      - CSE445
      - CSE419

======================================================================
RESULT: ✓ GRADUATION APPROVED
HONORS: Cum Laude
======================================================================
```

## 📊 NSU Grading Scale

| Numerical Score | Letter Grade | Grade Points | Status |
|----------------|--------------|--------------|---------|
| 93 and above | A | 4.0 | Excellent |
| 90 - 92 | A- | 3.7 | |
| 87 - 89 | B+ | 3.3 | |
| 83 - 86 | B | 3.0 | Good |
| 80 - 82 | B- | 2.7 | |
| 77 - 79 | C+ | 2.3 | |
| 73 - 76 | C | 2.0 | Average |
| 70 - 72 | C- | 1.7 | |
| 67 - 69 | D+ | 1.3 | |
| 60 - 66 | D | 1.0 | Poor |
| Below 60 | F | 0.0 | Failure* |
| - | I | 0.0 | Incomplete** |
| - | W | 0.0 | Withdrawal** |
| - | X | 0.0 | Marked** |

*Credits with F grade do not count toward graduation  
**I, W, X grades excluded from CGPA calculation

## 🎓 Academic Standing

| CGPA Range | Standing |
|------------|----------|
| 3.80 - 4.00 | Summa Cum Laude |
| 3.65 - 3.79 | Magna Cum Laude |
| 3.50 - 3.64 | Cum Laude |
| 3.00 - 3.49 | First Class |
| 2.50 - 2.99 | Second Class |
| 2.00 - 2.49 | Third Class |
| **Below 2.00** | **PROBATION** |

## 📝 Business Rules

### Credit Calculation
- Only grades A through D count toward earned credits
- F, I, W, X grades are excluded
- 0-credit labs are tracked separately

### CGPA Calculation
- Formula: `Total Grade Points / Total Credits Counted`
- Excludes: F, I, W, X grades
- Excludes: Waived courses
- Retakes: Only best grade counted

### Retake Policy
- Students may retake courses with grade B or lower
- Both attempts appear on transcript
- Lower grade shows 0.0 grade points
- F grades must be cleared by retaking

### Elective Requirements
- Total: 9 credits (3 courses)
- Minimum 2 courses from ONE trail
- Remaining 1 course from any trail

## 🧪 Testing

The project includes **24 comprehensive test cases**:

### Level 1 Tests (4 cases)
- `test_L1_1.csv` - Standard successful student (130 credits)
- `test_L1_2.csv` - Mixed grades with failures
- `test_L1_3.csv` - Incomplete and withdrawn courses
- `test_L1_4.csv` - Zero-credit labs edge case

### Level 2 Tests (4 cases)
- `test_L2_1.csv` - Standard CGPA calculation
- `test_L2_2.csv` - Retake scenarios
- `test_L2_3.csv` - Course waivers
- `test_L2_4.csv` - Complex (retakes + waivers + F/W/I)

### Level 3 Tests (4 cases)
- `test_L3_1.csv` - Graduation ready student
- `test_L3_2.csv` - Missing core courses
- `test_L3_3.csv` - Probation status (low CGPA)
- `test_L3_4.csv` - Elective trail violation

### Mixed Scenarios (12 cases)
- `test_multiple_retakes.csv` - Same course retaken 3 times
- `test_withdrawal_scenarios.csv` - Multiple withdrawals
- `test_zero_credit_variations.csv` - Various 0-credit labs
- `test_mixed_grades.csv` - Full grade spectrum
- `test_perfect_student.csv` - All A grades
- `test_failing_student.csv` - All F grades
- `test_partial_completion.csv` - Incomplete program
- `test_all_incomplete.csv` - All I grades
- `test_edge_cgpa.csv` - Exactly 2.0 CGPA
- `test_high_honors.csv` - High honors (3.85+ CGPA)
- `test_transfer_student.csv` - Transfer credits/waivers
- `test_complex_electives.csv` - Multiple trail combinations

### Running All Tests

```bash
# Test Level 1
for file in tests/level1/*.csv; do
    echo "Testing: $file"
    python -m src.level1_credit_tally "$file"
done

# Test Level 2 (with waivers)
python -m src.level2_cgpa_calculator tests/level2/test_L2_3.csv --waivers ENG102,MAT116

# Test Level 3
python -m src.level3_audit_engine tests/level3/test_L3_1.csv BSCSE data/program_knowledge_BSCSE.md
```

See `docs/testing_plan.md` for detailed testing procedures.

## 📂 Data Files

### Transcript CSV Format

```csv
course_code,course_name,credits,grade,semester
CSE115,Programming Language I,3,A,Spring2022
MAT120,Calculus I,3,B+,Spring2022
CSE225L,Data Structures Lab,0,A,Fall2022
```

**Required Columns:**
- `course_code` - Course identifier (e.g., CSE115, MAT120)
- `course_name` - Full course name
- `credits` - Credit value (0, 1, 3, or 4)
- `grade` - Letter grade (A, A-, B+, ..., F, I, W, X)
- `semester` - Semester taken (e.g., Spring2022, Fall2023)

### Program Knowledge Format

Program requirements are defined in markdown files:
- `data/program_knowledge_BSCSE.md` - BSCSE program
- `data/program_knowledge_BSEEE.md` - BSEEE program

Structure:
```markdown
# BSCSE Program Requirements

Total Credits Required: 130

## University Core (34 Credits)
- ENG102: Introduction to Composition (3 credits) - Waivable
- ENG103: Intermediate Composition (3 credits) - Prerequisite: ENG102

## SEPS Core (38 Credits)
...

## CSE Major Core (42 Credits)
...

## Elective Trails
### Artificial Intelligence Trail
- CSE440: Artificial Intelligence
...
```

## ⚙️ Key Components

### `utils.py`
- Grade point mapping (A=4.0 to D=1.0)
- Grade validation functions
- Academic standing calculation
- Probation checking

### `csv_parser.py`
- Reads and validates transcript CSV
- Error detection and reporting
- Data normalization

### `program_knowledge.py`
- Parses markdown requirements
- Extracts course lists by category
- Handles prerequisites and waivers
- Elective trail definitions

### `level1_credit_tally.py`
- Earned credit calculation
- Exclusion handling (F/I/W/X)
- 0-credit lab tracking
- Detailed reporting

### `level2_cgpa_calculator.py`
- Weighted CGPA calculation
- Retake detection and best-grade selection
- Waiver processing
- Comprehensive CGPA report

### `level3_audit_engine.py`
- Complete graduation audit
- Category-wise requirement checking
- Elective trail validation
- Prerequisite verification
- Deficiency identification
- Graduation eligibility determination

## 🐛 Troubleshooting

### Common Issues

**Issue: "File not found" error**
```
Solution: Check file path is correct and file exists
```

**Issue: "Invalid grade" in transcript**
```
Solution: Ensure grades are: A, A-, B+, B, B-, C+, C, C-, D+, D, F, I, W, X
```

**Issue: CGPA doesn't match manual calculation**
```
Solution: Remember that F, I, W, X grades are excluded from CGPA calculation
```

**Issue: Elective requirement not met despite 3 courses**
```
Solution: Check if at least 2 courses are from the SAME trail
```

## 📚 Documentation

- `README.md` - This file (usage and overview)
- `docs/testing_plan.md` - Comprehensive testing strategy
- `data/program_knowledge_BSCSE.md` - BSCSE program details
- `data/program_knowledge_BSEEE.md` - BSEEE program details

## 🎯 Future Enhancements

- [ ] Web-based interface
- [ ] PDF report generation
- [ ] Batch processing multiple students
- [ ] Transfer credit handling
- [ ] Semester-by-semester progress tracking
- [ ] What-if analysis ("What if I retake X?")
- [ ] Export to Excel/Google Sheets

## 👥 Contributors

**NSU CSE Department**  
Project developed for CSE226 - Spring 2026

## 📄 License

This project is developed for educational purposes at North South University.

## 📞 Support

For questions or issues:
- Review this README
- Check `docs/testing_plan.md`
- Consult NSU official curriculum documents
- Contact course instructor during office hours

---

**Version:** 1.0.0  
**Last Updated:** February 2026  
**Status:** Production Ready ✅
