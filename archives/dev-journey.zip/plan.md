# 📅 My 6-Month Developer Roadmap
> Goal: Get job-ready as a Full-Stack Developer + AI/ML Engineer
> Time: 2–3 hours/day | 6 days/week | 6 months
> Method: Build real projects. Understand every line. Push to GitHub always.

---

## 🗺️ THE BIG PICTURE

```
Month 1 → Foundation (Git + Web basics + First project)
Month 2 → Full-Stack basics (React + API + Database)
Month 3 → Real features (Auth + File uploads + External APIs)
Month 4 → AI Integration (OpenAI + LangChain + AI-powered apps)
Month 5 → Advanced projects + Open Source contributions
Month 6 → Portfolio polish + Job prep + Final push
```

---

## 📌 MONTH 1 — Foundation & Git Mastery
**Theme:** "Set up properly. Build your first real thing."

### Week 1 — Environment & Git Workflow (not skipping this, it matters forever)
- [ ] Set up VS Code with extensions: Prettier, ESLint, GitLens, GitHub Copilot
- [ ] Understand what Git actually is (why developers use it)
- [ ] Learn: `git init`, `git add`, `git commit`, `git push`, `git pull`
- [ ] Learn: branches — `git checkout -b feature/my-feature`
- [ ] Learn: what a Pull Request (PR) is and how to open one
- [ ] Create your `dev-journey` repo on GitHub and push this folder

**Mini task:** Create a repo called `dev-journey`, push all your .md files, make your first PR.

### Week 2 — HTML + CSS Refresh (fast, not deep)
- [ ] HTML: structure, tags, semantic HTML (header, main, footer, article)
- [ ] CSS: box model, flexbox, grid, responsive design
- [ ] Tailwind CSS: utility classes, how it's different from plain CSS
- [ ] Build: A static "About Me" page using Tailwind

**Why it matters:** Every frontend app is HTML + CSS underneath. React renders to HTML.

### Week 3 — JavaScript That Actually Matters
- [ ] Variables, functions, arrays, objects (quick review)
- [ ] Arrow functions, destructuring, spread operator
- [ ] Promises, async/await — THIS IS CRITICAL (most beginners skip it)
- [ ] fetch() — how to call an API from browser
- [ ] DOM manipulation basics

**Why async/await matters:** Every real app talks to a server. That's always async.

### Week 4 — React Basics + Project 1 Starts
- [ ] What is React and why does it exist (component model)
- [ ] JSX — what it is, why it looks like HTML in JavaScript
- [ ] useState, useEffect — the two hooks you use in 90% of apps
- [ ] Props — passing data between components
- [ ] Start Project 1: Personal Portfolio Website

---
### 🚀 PROJECT 1: Personal Portfolio Website
**Stack:** React + Tailwind CSS
**GitHub repo:** `portfolio-website`
**What it has:**
- Home page (your name, title, short bio)
- Projects section (cards with project name, description, GitHub link)
- Skills section
- Contact section

**What you learn:**
- React component structure
- Responsive layout with Tailwind
- Deploying to Vercel (free, one command)
- Git workflow: branches, commits, PRs

**Real-life connection:** Every developer has a portfolio. This is YOUR first product.

---

## 📌 MONTH 2 — Full-Stack Basics
**Theme:** "Make the frontend talk to a backend. Store real data."

### Week 5 — TypeScript Basics
- [ ] What TypeScript is and why developers use it (fewer bugs, better autocomplete)
- [ ] Types: string, number, boolean, array, object
- [ ] Interfaces and types
- [ ] How to add TypeScript to a React project
- [ ] Convert your portfolio to TypeScript

### Week 6 — Backend with FastAPI (Python)
- [ ] What a backend is — it's just a program that listens for requests
- [ ] REST API concepts: GET, POST, PUT, DELETE
- [ ] FastAPI: install, create first endpoint, run locally
- [ ] What JSON is and how frontend/backend talk to each other
- [ ] Test APIs with Thunder Client (VS Code extension)

**Why FastAPI and not Node.js first:** FastAPI is Python (great for AI later), very readable, auto-generates docs.

### Week 7 — Database Basics
- [ ] What a database is — just a place to store data that doesn't disappear
- [ ] SQL basics: SELECT, INSERT, UPDATE, DELETE
- [ ] SQLite (simple, no setup) → connect to FastAPI
- [ ] SQLAlchemy ORM: what it is, why we use it (write Python, not SQL)
- [ ] CRUD operations: Create, Read, Update, Delete

### Week 8 — Connect Frontend to Backend + Project 2
- [ ] CORS — what it is and why it blocks your requests (every beginner hits this)
- [ ] Fetch data from FastAPI in React using useEffect
- [ ] Loading states, error states
- [ ] Start Project 2: Task Manager App

---
### 🚀 PROJECT 2: Task Manager (Full-Stack)
**Stack:** React + TypeScript (frontend) + FastAPI + SQLite (backend)
**GitHub repo:** `task-manager-app`
**What it has:**
- Add a task (title, description, due date)
- See all tasks (list view)
- Mark task as complete
- Delete a task
- Data saved in database (persists after refresh)

**What you learn:**
- Full-stack data flow: browser → API → database → back to browser
- REST API design
- State management in React
- Connecting frontend and backend

**Real-life connection:** Trello, Asana, Notion — they are all task managers with a lot more features.

---

## 📌 MONTH 3 — Real Features
**Theme:** "Add features that real apps have."

### Week 9 — Authentication (Login / Register)
- [ ] What authentication is and why it's hard to get right
- [ ] JWT (JSON Web Token) — what it is, how it works
- [ ] Hash passwords with bcrypt (NEVER store plain passwords)
- [ ] Protect routes — only logged-in users can see their tasks
- [ ] Store JWT in localStorage vs cookies (trade-offs)

### Week 10 — File Uploads + Cloud Storage
- [ ] How file uploads work (multipart form data)
- [ ] Upload images in FastAPI
- [ ] Store images in Cloudinary (free tier, no server storage needed)
- [ ] Display uploaded images in React

### Week 11 — External APIs + Webhooks
- [ ] What an external API is — using other people's services
- [ ] Call a free API (weather, news, etc.) from your backend
- [ ] What environment variables are and why secrets go in .env (NOT in GitHub)
- [ ] .gitignore — what it is and why .env must be in it

### Week 12 — Project 3
---
### 🚀 PROJECT 3: AI-Ready Full-Stack App (your choice of idea)
**Stack:** React + TypeScript + FastAPI + PostgreSQL + Auth
**Suggested ideas:**
- Expense Tracker with categories and charts
- Job Application Tracker (track where you applied)
- Recipe Book (add, search, filter recipes)
- Book Notes App

**What you learn:**
- Full authentication flow
- Real database (PostgreSQL)
- Deployment: frontend on Vercel, backend on Render (both free)
- Environment variables and secrets management

---

## 📌 MONTH 4 — AI Integration
**Theme:** "Add AI features. This is where Full-Stack meets AI/ML."

### Week 13 — OpenAI API Basics
- [ ] What an LLM is in simple terms
- [ ] OpenAI API: get API key, make first call in Python
- [ ] Prompt engineering basics — how to write good prompts
- [ ] System prompts vs user prompts
- [ ] Handle API responses and errors

### Week 14 — LangChain Basics
- [ ] What LangChain is — a framework to build AI apps
- [ ] Chains: connecting prompts together
- [ ] Memory: making AI remember context
- [ ] Build a simple chatbot with memory

### Week 15 — RAG (Retrieval Augmented Generation)
- [ ] What RAG is — AI that answers from YOUR documents
- [ ] Embeddings — turning text into numbers (vectors)
- [ ] Vector database basics: Chroma (simple, local)
- [ ] Build: upload a PDF → ask questions about it

### Week 16 — Project 4
---
### 🚀 PROJECT 4: AI-Powered Application
**Stack:** React + FastAPI + OpenAI + LangChain
**Suggested ideas:**
- AI Study Assistant (upload notes, ask questions)
- AI Resume Reviewer (paste resume, get feedback)
- AI Code Explainer (paste code, get explanation)
- AI Chat with your Task Manager (natural language: "show me tasks due this week")

**What you learn:**
- Integrating AI into a real product
- Streaming responses (like ChatGPT typewriter effect)
- Prompt engineering in production
- Cost management with AI APIs

---

## 📌 MONTH 5 — Advanced Projects + Open Source
**Theme:** "Contribute to the real world. Your code goes into other people's projects."

### Week 17–18 — Open Source Contribution Basics
- [ ] How to find beginner-friendly issues: search `good first issue` on GitHub
- [ ] How to fork a repo, clone it, make changes, open a PR
- [ ] How to write a good PR description
- [ ] How to respond to code review feedback
- [ ] How to open issues — bug reports, feature requests
- [ ] Recommended repos to start: freeCodeCamp, public-apis, awesome-python, any project you use

### Week 19–20 — Project 5 + Docker Basics
- [ ] What Docker is — packaging your app so it runs anywhere
- [ ] Dockerfile basics, docker-compose basics
- [ ] Dockerize your FastAPI app
- [ ] Learn: what CI/CD is (GitHub Actions basics)

---
### 🚀 PROJECT 5: Your Flagship Project
**This is your most impressive portfolio project.**
**Stack:** Full choice — use everything you've learned
**Suggested ideas:**
- AI-powered SaaS tool (something people would pay for)
- Developer tool (something developers need)
- Anything you personally wish existed

**Requirements:**
- Full authentication
- AI integration
- Deployed and live on the internet
- Clean README with screenshots
- At least 10 meaningful commits showing progress

---

## 📌 MONTH 6 — Portfolio Polish + Job Prep
**Theme:** "Present what you built. Get the job."

### Week 21–22 — Portfolio Polish
- [ ] Update portfolio website with all 5 projects
- [ ] Write a strong README for every project (what it does, how to run it, screenshots)
- [ ] Clean up code — remove console.logs, add comments
- [ ] Record a 2-minute demo video for your flagship project
- [ ] Write case studies: problem → solution → what you learned

### Week 23–24 — Job Prep
- [ ] Update GitHub profile: profile README, pinned repos, contribution graph
- [ ] LinkedIn profile: add projects, skills, GitHub link
- [ ] Resume: list projects with IMPACT (not just "built a task manager" → "built a full-stack task manager with JWT auth, deployed on Vercel/Render, 15 GitHub stars")
- [ ] System design basics: what happens when you type a URL
- [ ] Practice: explain your projects out loud as if in an interview

---

## 📊 PROGRESS TRACKER

| Month | Phase | Project | Status |
|-------|-------|---------|--------|
| 1 | Foundation | Portfolio Website | ⬜ Not started |
| 2 | Full-Stack | Task Manager | ⬜ Not started |
| 3 | Real Features | Full-Stack App | ⬜ Not started |
| 4 | AI Integration | AI-Powered App | ⬜ Not started |
| 5 | Advanced | Flagship Project | ⬜ Not started |
| 6 | Job Prep | Portfolio Polish | ⬜ Not started |

**Status key:** ⬜ Not started | 🔄 In progress | ✅ Done

---

## 🔄 WEEKLY ROUTINE (2–3 hrs/day)

| Day | Focus |
|-----|-------|
| Mon | Learn new concept (watch/read + take notes) |
| Tue | Apply concept (code it yourself, ask AI to explain each line) |
| Wed | Continue building project |
| Thu | Continue building project + git push |
| Fri | Review what you built, fix bugs, refactor |
| Sat | Open source: find an issue or review someone's PR |
| Sun | Rest (or catch up if behind) |

---

## 💡 THE VIBE CODING RULES

When using AI to help you code:
1. **Never paste code without reading it** — ask the AI to explain every line first
2. **Ask "why" before "what"** — why this approach, not just what it does
3. **Ask for alternatives** — "is there another way to do this?"
4. **Try to break it** — what happens if I change this? Ask AI to predict, then test
5. **Teach it back** — after AI explains, close the chat and explain it to yourself in plain words

---

*Last updated: [DATE]*
*Current phase: Month 1, Week 1*
