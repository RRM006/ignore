# 🛠️ Skill Tracker
> WHY THIS FILE EXISTS: 
> When you're learning for 6 months, you forget what you know. This file tracks every skill 
> you've built, at what level, and PROVES it with a real project link. 
> In a job interview, you can look here and confidently say "I built X with Y."

---

## HOW TO USE THIS FILE

1. When you START learning a skill → add it with status: 🌱 Learning
2. When you've USED it in a project → update to: 🔄 Practiced
3. When you can EXPLAIN it to someone else without help → update to: ✅ Confident
4. Always add a proof link (GitHub repo or file)

---

## 🔵 FRONTEND SKILLS

| Skill | Status | Proof (GitHub link) | Notes |
|-------|--------|---------------------|-------|
| HTML semantics | ⬜ | — | — |
| CSS Flexbox | ⬜ | — | — |
| CSS Grid | ⬜ | — | — |
| Tailwind CSS | ⬜ | — | — |
| JavaScript basics | ⬜ | — | — |
| JS async/await | ⬜ | — | — |
| JS fetch() API | ⬜ | — | — |
| React components | ⬜ | — | — |
| React useState | ⬜ | — | — |
| React useEffect | ⬜ | — | — |
| React props | ⬜ | — | — |
| React Router | ⬜ | — | — |
| TypeScript basics | ⬜ | — | — |
| TypeScript with React | ⬜ | — | — |

**Status key:** ⬜ Not started | 🌱 Learning | 🔄 Practiced | ✅ Confident

---

## 🟡 BACKEND SKILLS

| Skill | Status | Proof (GitHub link) | Notes |
|-------|--------|---------------------|-------|
| REST API concepts | ⬜ | — | — |
| FastAPI setup | ⬜ | — | — |
| FastAPI routes (GET/POST/PUT/DELETE) | ⬜ | — | — |
| Pydantic models | ⬜ | — | — |
| SQLite + SQLAlchemy | ⬜ | — | — |
| PostgreSQL basics | ⬜ | — | — |
| CORS handling | ⬜ | — | — |
| JWT Authentication | ⬜ | — | — |
| Password hashing (bcrypt) | ⬜ | — | — |
| File uploads | ⬜ | — | — |
| Environment variables (.env) | ⬜ | — | — |
| Node.js + Express (basics) | ⬜ | — | — |

---

## 🟣 AI / ML SKILLS

| Skill | Status | Proof (GitHub link) | Notes |
|-------|--------|---------------------|-------|
| OpenAI API basics | ⬜ | — | — |
| Prompt engineering | ⬜ | — | — |
| LangChain basics | ⬜ | — | — |
| LangChain memory | ⬜ | — | — |
| RAG (basic) | ⬜ | — | — |
| Embeddings concept | ⬜ | — | — |
| Chroma vector DB | ⬜ | — | — |
| Streaming AI responses | ⬜ | — | — |

---

## 🟢 DEVOPS / TOOLS SKILLS

| Skill | Status | Proof (GitHub link) | Notes |
|-------|--------|---------------------|-------|
| Git: add, commit, push | ⬜ | — | — |
| Git: branches | ⬜ | — | — |
| Git: merge + rebase | ⬜ | — | — |
| GitHub: PR workflow | ⬜ | — | — |
| GitHub: issues | ⬜ | — | — |
| GitHub: code review | ⬜ | — | — |
| Deploy to Vercel | ⬜ | — | — |
| Deploy to Render | ⬜ | — | — |
| Docker basics | ⬜ | — | — |
| GitHub Actions (CI/CD) | ⬜ | — | — |
| Cloudinary (file storage) | ⬜ | — | — |

---

## 🔴 OPEN SOURCE CONTRIBUTIONS

| Repo | Type | PR/Issue link | Status | Date |
|------|------|--------------|--------|------|
| — | — | — | — | — |

**Types:** Bug fix | Feature | Documentation | Code review | Issue opened

---

## 📦 PROJECTS COMPLETED

| # | Project Name | Stack | GitHub Link | Live Link | Key Skills Demonstrated |
|---|-------------|-------|-------------|-----------|------------------------|
| 1 | Portfolio Website | React + Tailwind | — | — | React, Tailwind, Deploy |
| 2 | Task Manager | React + FastAPI + SQLite | — | — | Full-stack, REST API, DB |
| 3 | [Your choice] | React + FastAPI + Auth | — | — | Auth, PostgreSQL |
| 4 | AI App | React + FastAPI + OpenAI | — | — | LLM integration |
| 5 | Flagship Project | Full stack | — | — | Everything |

---

## 💡 WHY THIS SKILL FILE HELPS IN INTERVIEWS

When an interviewer asks:
- "Do you know React?" → You say: "Yes, I used it in 4 projects — here's the GitHub link"
- "Have you worked with APIs?" → "Yes, I built REST APIs with FastAPI, here's an example"
- "What's your experience with AI?" → "I integrated OpenAI API into a product, let me show you"

**The file = your evidence.** Not just words. Proof.

---

*Last updated: [DATE]*
