# 🚀 dev-journey — My Developer Learning System
> Full-Stack + AI/ML | 6 months | 2–3 hrs/day | Learn by building

---

## 📁 WHAT'S IN THIS FOLDER

| File | Purpose | When to use |
|------|---------|-------------|
| `context_engineering_prompt.md` | Master prompt for any AI | Paste at start of EVERY AI chat session |
| `plan.md` | 6-month roadmap with projects | Check at start of each week |
| `chatlog.md` | Detailed log of each session | Fill in DURING and AFTER each session |
| `historychat.md` | One-line summary of all sessions | Add one row AFTER each session |
| `skill.md` | Skills tracker with proof links | Update when you learn or master something |
| `projects/` | All your project code goes here | One folder per project |
| `notes/` | Quick notes, code snippets | Anytime |

---

## ⚡ QUICK START — What to do right now

### Step 1: Make this folder a Git repo and push to GitHub
```bash
# Open terminal in this folder (dev-journey/)
git init
git add .
git commit -m "Initial commit: add dev-journey learning system"
```

Then go to GitHub.com:
1. Click "New repository"
2. Name it: `dev-journey`
3. Keep it public (shows employers you're active)
4. Copy the remote URL
5. Run:
```bash
git remote add origin https://github.com/YOUR-USERNAME/dev-journey.git
git branch -M main
git push -u origin main
```

### Step 2: Open plan.md and read Month 1, Week 1 tasks

### Step 3: Before every AI session, open context_engineering_prompt.md and copy the prompt block

### Step 4: After every session, update chatlog.md and historychat.md

---

## 🔄 DAILY WORKFLOW

```
START SESSION
    ↓
Open chatlog.md → create new session block
    ↓
Copy context_engineering_prompt.md → paste to AI
    ↓
Work on your task (code, learn, build)
    ↓
git add . && git commit -m "what you did and why"
    ↓
git push
    ↓
Fill in chatlog.md (what you did, learned, blocked on)
    ↓
Add one-line summary to historychat.md
    ↓
Update skill.md if you learned something new
    ↓
END SESSION
```

---

## 🎯 CURRENT FOCUS

**Phase:** Month 1, Week 1 — Foundation & Git Setup
**Immediate task:** Push this folder to GitHub (see Step 1 above)

---

*Started: [DATE]*
